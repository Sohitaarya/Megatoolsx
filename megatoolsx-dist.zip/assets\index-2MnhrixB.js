import{r as l,j as e,g as ks,R as I,c as ir}from"./vendor-BiHfrq0e.js";import{S as $,a as Q,C as lr,b as Oe,M as vt,G as L,c as Ha,A as wt,m as k,X as Be,d as cr,H as me,e as Wa,f as Pt,g as Lt,T as Ge,h as Se,B as ye,i as A,U as xe,Z as de,j as Ua,k as D,P as Va,Q as za,l as G,n as qa,E as Z,I as Qa,D as q,o as nt,p as Ne,q as Ts,r as As,s as $e,t as ue,L as ns,u as J,v as Y,w as dr,x as ur,F as O,K as hr,y as Xs,z as Mt,J as _a,N as rt,O as rs,R as mr,V as Re,W as xr,Y as Ka,_ as Et,$ as ce,a0 as pr,a1 as os,a2 as St,a3 as gr,a4 as Ze,a5 as is,a6 as He,a7 as We,a8 as et,a9 as Rs,aa as Ps,ab as pe,ac as U,ad as Ue,ae as Ya,af as Ja,ag as fr,ah as br,ai as yr,aj as jr,ak as Xa,al as ke,am as Za,an as ot,ao as Zs,ap as Te,aq as je,ar as vr,as as Pe,at as ze,au as Ft,av as wr,aw as it,ax as Mr,ay as Sr,az as ls,aA as ve,aB as Cr,aC as en,aD as Ls,aE as ge,aF as Nr,aG as we,aH as Ae,aI as cs,aJ as ea,aK as $r,aL as kr,aM as Ct,aN as Tr,aO as It,aP as ds,aQ as tn,aR as us,aS as sn,aT as hs,aU as an,aV as Ar,aW as Rr,aX as ms,aY as ta,aZ as nn,a_ as sa,a$ as rn,b0 as Pr,b1 as Lr,b2 as Er,b3 as Nt,b4 as Fr,b5 as Ir,b6 as Dr,b7 as on,b8 as aa,b9 as Or}from"./ui-BjR8SJcU.js";import{P as Br}from"./csv-parser-DfZJ9AzF.js";import{c as Gr}from"./data-B1nUQG6E.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))n(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const r of i.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function a(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(o){if(o.ep)return;o.ep=!0;const i=a(o);fetch(o.href,i)}})();var Es=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,ln=/^[\\/]{2}/;function Hr(t,s){return s+t.replace(/\\/g,"/")}var na="popstate";function ra(t){return typeof t=="object"&&t!=null&&"pathname"in t&&"search"in t&&"hash"in t&&"state"in t&&"key"in t}function Wr(t={}){function s(n,o){let i=o.state?.masked,{pathname:r,search:c,hash:d}=i||n.location;return xs("",{pathname:r,search:c,hash:d},o.state&&o.state.usr||null,o.state&&o.state.key||"default",i?{pathname:n.location.pathname,search:n.location.search,hash:n.location.hash}:void 0)}function a(n,o){return typeof o=="string"?o:tt(o)}return Vr(s,a,null,t)}function B(t,s){if(t===!1||t===null||typeof t>"u")throw new Error(s)}function he(t,s){if(!t){typeof console<"u"&&console.warn(s);try{throw new Error(s)}catch{}}}function Ur(){return Math.random().toString(36).substring(2,10)}function oa(t,s){return{usr:t.state,key:t.key,idx:s,masked:t.mask?{pathname:t.pathname,search:t.search,hash:t.hash}:void 0}}function xs(t,s,a=null,n,o){return{pathname:typeof t=="string"?t:t.pathname,search:"",hash:"",...typeof s=="string"?qe(s):s,state:a,key:s&&s.key||n||Ur(),mask:o}}function tt({pathname:t="/",search:s="",hash:a=""}){return s&&s!=="?"&&(t+=s.charAt(0)==="?"?s:"?"+s),a&&a!=="#"&&(t+=a.charAt(0)==="#"?a:"#"+a),t}function qe(t){let s={};if(t){let a=t.indexOf("#");a>=0&&(s.hash=t.substring(a),t=t.substring(0,a));let n=t.indexOf("?");n>=0&&(s.search=t.substring(n),t=t.substring(0,n)),t&&(s.pathname=t)}return s}function Vr(t,s,a,n={}){let{window:o=document.defaultView,v5Compat:i=!1}=n,r=o.history,c="POP",d=null,h=u();h==null&&(h=0,r.replaceState({...r.state,idx:h},""));function u(){return(r.state||{idx:null}).idx}function f(){c="POP";let y=u(),C=y==null?null:y-h;h=y,d&&d({action:c,location:M.location,delta:C})}function v(y,C){c="PUSH";let N=ra(y)?y:xs(M.location,y,C);h=u()+1;let T=oa(N,h),P=M.createHref(N.mask||N);try{r.pushState(T,"",P)}catch(E){if(E instanceof DOMException&&E.name==="DataCloneError")throw E;o.location.assign(P)}i&&d&&d({action:c,location:M.location,delta:1})}function j(y,C){c="REPLACE";let N=ra(y)?y:xs(M.location,y,C);h=u();let T=oa(N,h),P=M.createHref(N.mask||N);r.replaceState(T,"",P),i&&d&&d({action:c,location:M.location,delta:0})}function w(y){return zr(o,y)}let M={get action(){return c},get location(){return t(o,r)},listen(y){if(d)throw new Error("A history only accepts one active listener");return o.addEventListener(na,f),d=y,()=>{o.removeEventListener(na,f),d=null}},createHref(y){return s(o,y)},createURL:w,encodeLocation(y){let C=w(y);return{pathname:C.pathname,search:C.search,hash:C.hash}},push:v,replace:j,go(y){return r.go(y)}};return M}function zr(t,s,a=!1){let n="http://localhost";t&&(n=t.location.origin!=="null"?t.location.origin:t.location.href),B(n,"No window.location.(origin|href) available to create URL");let o=typeof s=="string"?s:tt(s);return o=o.replace(/ $/,"%20"),!a&&ln.test(o)&&(o=n+o),new URL(o,n)}function cn(t,s,a="/"){return qr(t,s,a,!1)}function qr(t,s,a,n,o){let i=typeof s=="string"?qe(s):s,r=fe(i.pathname||"/",a);if(r==null)return null;let c=Qr(t),d=null,h=no(r);for(let u=0;d==null&&u<c.length;++u)d=ao(c[u],h,n);return d}function Qr(t){let s=dn(t);return _r(s),s}function dn(t,s=[],a=[],n="",o=!1){let i=(r,c,d=o,h)=>{let u={relativePath:h===void 0?r.path||"":h,caseSensitive:r.caseSensitive===!0,childrenIndex:c,route:r};if(u.relativePath.startsWith("/")){if(!u.relativePath.startsWith(n)&&d)return;B(u.relativePath.startsWith(n),`Absolute route path "${u.relativePath}" nested under path "${n}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),u.relativePath=u.relativePath.slice(n.length)}let f=re([n,u.relativePath]),v=a.concat(u);r.children&&r.children.length>0&&(B(r.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${f}".`),dn(r.children,s,v,f,d)),!(r.path==null&&!r.index)&&s.push({path:f,score:to(f,r.index),routesMeta:v.map((j,w)=>{let[M,y]=mn(j.relativePath,j.caseSensitive,w===v.length-1);return{...j,matcher:M,compiledParams:y}})})};return t.forEach((r,c)=>{if(r.path===""||!r.path?.includes("?"))i(r,c);else for(let d of un(r.path))i(r,c,!0,d)}),s}function un(t){let s=t.split("/");if(s.length===0)return[];let[a,...n]=s,o=a.endsWith("?"),i=a.replace(/\?$/,"");if(n.length===0)return o?[i,""]:[i];let r=un(n.join("/")),c=[];return c.push(...r.map(d=>d===""?i:[i,d].join("/"))),o&&c.push(...r),c.map(d=>t.startsWith("/")&&d===""?"/":d)}function _r(t){t.sort((s,a)=>s.score!==a.score?a.score-s.score:so(s.routesMeta.map(n=>n.childrenIndex),a.routesMeta.map(n=>n.childrenIndex)))}var Kr=/^:[\w-]+$/,Yr=3,Jr=2,Xr=1,Zr=10,eo=-2,ia=t=>t==="*";function to(t,s){let a=t.split("/"),n=a.length;return a.some(ia)&&(n+=eo),s&&(n+=Jr),a.filter(o=>!ia(o)).reduce((o,i)=>o+(Kr.test(i)?Yr:i===""?Xr:Zr),n)}function so(t,s){return t.length===s.length&&t.slice(0,-1).every((n,o)=>n===s[o])?t[t.length-1]-s[s.length-1]:0}function ao(t,s,a=!1){let{routesMeta:n}=t,o={},i="/",r=[];for(let c=0;c<n.length;++c){let d=n[c],h=c===n.length-1,u=i==="/"?s:s.slice(i.length)||"/",f={path:d.relativePath,caseSensitive:d.caseSensitive,end:h},v=d.matcher&&d.compiledParams?hn(f,u,d.matcher,d.compiledParams):$t(f,u),j=d.route;if(!v&&h&&a&&!n[n.length-1].route.index&&(v=$t({path:d.relativePath,caseSensitive:d.caseSensitive,end:!1},u)),!v)return null;Object.assign(o,v.params),r.push({params:o,pathname:re([i,v.pathname]),pathnameBase:io(re([i,v.pathnameBase])),route:j}),v.pathnameBase!=="/"&&(i=re([i,v.pathnameBase]))}return r}function $t(t,s){typeof t=="string"&&(t={path:t,caseSensitive:!1,end:!0});let[a,n]=mn(t.path,t.caseSensitive,t.end);return hn(t,s,a,n)}function hn(t,s,a,n){let o=s.match(a);if(!o)return null;let i=o[0],r=i.replace(/(.)\/+$/,"$1"),c=o.slice(1);return{params:n.reduce((h,{paramName:u,isOptional:f},v)=>{if(u==="*"){let w=c[v]||"";r=i.slice(0,i.length-w.length).replace(/(.)\/+$/,"$1")}const j=c[v];return f&&!j?h[u]=void 0:h[u]=(j||"").replace(/%2F/g,"/"),h},{}),pathname:i,pathnameBase:r,pattern:t}}function mn(t,s=!1,a=!0){he(t==="*"||!t.endsWith("*")||t.endsWith("/*"),`Route path "${t}" will be treated as if it were "${t.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${t.replace(/\*$/,"/*")}".`);let n=[],o="^"+t.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(r,c,d,h,u)=>{if(n.push({paramName:c,isOptional:d!=null}),d){let f=u.charAt(h+r.length);return f&&f!=="/"?"/([^\\/]*)":"(?:/([^\\/]*))?"}return"/([^\\/]+)"}).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return t.endsWith("*")?(n.push({paramName:"*"}),o+=t==="*"||t==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):a?o+="\\/*$":t!==""&&t!=="/"&&(o+="(?:(?=\\/|$))"),[new RegExp(o,s?void 0:"i"),n]}function no(t){try{return t.split("/").map(s=>decodeURIComponent(s).replace(/\//g,"%2F")).join("/")}catch(s){return he(!1,`The URL path "${t}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${s}).`),t}}function fe(t,s){if(s==="/")return t;if(!t.toLowerCase().startsWith(s.toLowerCase()))return null;let a=s.endsWith("/")?s.length-1:s.length,n=t.charAt(a);return n&&n!=="/"?null:t.slice(a)||"/"}function ro(t,s="/"){let{pathname:a,search:n="",hash:o=""}=typeof t=="string"?qe(t):t,i;return a?(a=pn(a),a.startsWith("/")?i=la(a.substring(1),"/"):i=la(a,s)):i=s,{pathname:i,search:lo(n),hash:co(o)}}function la(t,s){let a=kt(s).split("/");return t.split("/").forEach(o=>{o===".."?a.length>1&&a.pop():o!=="."&&a.push(o)}),a.length>1?a.join("/"):"/"}function Qt(t,s,a,n){return`Cannot include a '${t}' character in a manually specified \`to.${s}\` field [${JSON.stringify(n)}].  Please separate it out to the \`to.${a}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function oo(t){return t.filter((s,a)=>a===0||s.route.path&&s.route.path.length>0)}function xn(t){let s=oo(t);return s.map((a,n)=>n===s.length-1?a.pathname:a.pathnameBase)}function Fs(t,s,a,n=!1){let o;typeof t=="string"?o=qe(t):(o={...t},B(!o.pathname||!o.pathname.includes("?"),Qt("?","pathname","search",o)),B(!o.pathname||!o.pathname.includes("#"),Qt("#","pathname","hash",o)),B(!o.search||!o.search.includes("#"),Qt("#","search","hash",o)));let i=t===""||o.pathname==="",r=i?"/":o.pathname,c;if(r==null)c=a;else{let f=s.length-1;if(!n&&r.startsWith("..")){let v=r.split("/");for(;v[0]==="..";)v.shift(),f-=1;o.pathname=v.join("/")}c=f>=0?s[f]:"/"}let d=ro(o,c),h=r&&r!=="/"&&r.endsWith("/"),u=(i||r===".")&&a.endsWith("/");return!d.pathname.endsWith("/")&&(h||u)&&(d.pathname+="/"),d}var pn=t=>t.replace(/[\\/]{2,}/g,"/"),re=t=>pn(t.join("/")),kt=t=>t.replace(/\/+$/,""),io=t=>kt(t).replace(/^\/*/,"/"),lo=t=>!t||t==="?"?"":t.startsWith("?")?t:"?"+t,co=t=>!t||t==="#"?"":t.startsWith("#")?t:"#"+t,uo=class{constructor(t,s,a,n=!1){this.status=t,this.statusText=s||"",this.internal=n,a instanceof Error?(this.data=a.toString(),this.error=a):this.data=a}};function ho(t){return t!=null&&typeof t.status=="number"&&typeof t.statusText=="string"&&typeof t.internal=="boolean"&&"data"in t}function mo(t){let s=t.map(a=>a.route.path).filter(Boolean);return re(s)||"/"}var gn=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function fn(t,s){let a=t;if(typeof a!="string"||!Es.test(a))return{absoluteURL:void 0,isExternal:!1,to:a};let n=a,o=!1;if(gn)try{let i=new URL(window.location.href),r=ln.test(a)?new URL(Hr(a,i.protocol)):new URL(a),c=fe(r.pathname,s);r.origin===i.origin&&c!=null?a=c+r.search+r.hash:o=!0}catch{he(!1,`<Link to="${a}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:n,isExternal:o,to:a}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var bn=["POST","PUT","PATCH","DELETE"];new Set(bn);var xo=["GET",...bn];new Set(xo);var po=["about:","blob:","chrome:","chrome-untrusted:","content:","data:","devtools:","file:","filesystem:","javascript:"];function go(t){try{return po.includes(new URL(t).protocol)}catch{return!1}}var Qe=l.createContext(null);Qe.displayName="DataRouter";var Dt=l.createContext(null);Dt.displayName="DataRouterState";var yn=l.createContext(!1);function fo(){return l.useContext(yn)}var jn=l.createContext({isTransitioning:!1});jn.displayName="ViewTransition";var bo=l.createContext(new Map);bo.displayName="Fetchers";var yo=l.createContext(null);yo.displayName="Await";var se=l.createContext(null);se.displayName="Navigation";var lt=l.createContext(null);lt.displayName="Location";var oe=l.createContext({outlet:null,matches:[],isDataRoute:!1});oe.displayName="Route";var Is=l.createContext(null);Is.displayName="RouteError";var vn="REACT_ROUTER_ERROR",jo="REDIRECT",vo="ROUTE_ERROR_RESPONSE";function wo(t){if(t.startsWith(`${vn}:${jo}:{`))try{let s=JSON.parse(t.slice(28));if(typeof s=="object"&&s&&typeof s.status=="number"&&typeof s.statusText=="string"&&typeof s.location=="string"&&typeof s.reloadDocument=="boolean"&&typeof s.replace=="boolean")return s}catch{}}function Mo(t){if(t.startsWith(`${vn}:${vo}:{`))try{let s=JSON.parse(t.slice(40));if(typeof s=="object"&&s&&typeof s.status=="number"&&typeof s.statusText=="string")return new uo(s.status,s.statusText,s.data)}catch{}}function So(t,{relative:s}={}){B(ct(),"useHref() may be used only in the context of a <Router> component.");let{basename:a,navigator:n}=l.useContext(se),{hash:o,pathname:i,search:r}=dt(t,{relative:s}),c=i;return a!=="/"&&(c=i==="/"?a:re([a,i])),n.createHref({pathname:c,search:r,hash:o})}function ct(){return l.useContext(lt)!=null}function ie(){return B(ct(),"useLocation() may be used only in the context of a <Router> component."),l.useContext(lt).location}var wn="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function Mn(t){l.useContext(se).static||l.useLayoutEffect(t)}function Ds(){let{isDataRoute:t}=l.useContext(oe);return t?Oo():Co()}function Co(){B(ct(),"useNavigate() may be used only in the context of a <Router> component.");let t=l.useContext(Qe),{basename:s,navigator:a}=l.useContext(se),{matches:n}=l.useContext(oe),{pathname:o}=ie(),i=JSON.stringify(xn(n)),r=l.useRef(!1);return Mn(()=>{r.current=!0}),l.useCallback((d,h={})=>{if(he(r.current,wn),!r.current)return;if(typeof d=="number"){a.go(d);return}let u=Fs(d,JSON.parse(i),o,h.relative==="path");t==null&&s!=="/"&&(u.pathname=u.pathname==="/"?s:re([s,u.pathname])),(h.replace?a.replace:a.push)(u,h.state,h)},[s,a,i,o,t])}var Sn=l.createContext(null);function Ot(){return l.useContext(Sn)}function No(t){let s=l.useContext(oe).outlet;return l.useMemo(()=>s&&l.createElement(Sn.Provider,{value:t},s),[s,t])}function _e(){let{matches:t}=l.useContext(oe);return t[t.length-1]?.params??{}}function dt(t,{relative:s}={}){let{matches:a}=l.useContext(oe),{pathname:n}=ie(),o=JSON.stringify(xn(a));return l.useMemo(()=>Fs(t,JSON.parse(o),n,s==="path"),[t,o,n,s])}function $o(t,s){return Cn(t,s)}function Cn(t,s,a){B(ct(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:n}=l.useContext(se),{matches:o}=l.useContext(oe),i=o[o.length-1],r=i?i.params:{},c=i?i.pathname:"/",d=i?i.pathnameBase:"/",h=i&&i.route;{let y=h&&h.path||"";$n(c,!h||y.endsWith("*")||y.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${c}" (under <Route path="${y}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${y}"> to <Route path="${y==="/"?"*":`${y}/*`}">.`)}let u=ie(),f;if(s){let y=typeof s=="string"?qe(s):s;B(d==="/"||y.pathname?.startsWith(d),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${d}" but pathname "${y.pathname}" was given in the \`location\` prop.`),f=y}else f=u;let v=f.pathname||"/",j=v;if(d!=="/"){let y=d.replace(/^\//,"").split("/");j="/"+v.replace(/^\//,"").split("/").slice(y.length).join("/")}let w=a&&a.state.matches.length?a.state.matches.map(y=>Object.assign(y,{route:a.manifest[y.route.id]||y.route})):cn(t,{pathname:j});he(h||w!=null,`No routes matched location "${f.pathname}${f.search}${f.hash}" `),he(w==null||w[w.length-1].route.element!==void 0||w[w.length-1].route.Component!==void 0||w[w.length-1].route.lazy!==void 0,`Matched leaf route at location "${f.pathname}${f.search}${f.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let M=Po(w&&w.map(y=>Object.assign({},y,{params:Object.assign({},r,y.params),pathname:re([d,n.encodeLocation?n.encodeLocation(y.pathname.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathname]),pathnameBase:y.pathnameBase==="/"?d:re([d,n.encodeLocation?n.encodeLocation(y.pathnameBase.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathnameBase])})),o,a);return s&&M?l.createElement(lt.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",mask:void 0,...f},navigationType:"POP"}},M):M}function ko(){let t=Do(),s=ho(t)?`${t.status} ${t.statusText}`:t instanceof Error?t.message:JSON.stringify(t),a=t instanceof Error?t.stack:null,n="rgba(200,200,200, 0.5)",o={padding:"0.5rem",backgroundColor:n},i={padding:"2px 4px",backgroundColor:n},r=null;return console.error("Error handled by React Router default ErrorBoundary:",t),r=l.createElement(l.Fragment,null,l.createElement("p",null,"💿 Hey developer 👋"),l.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",l.createElement("code",{style:i},"ErrorBoundary")," or"," ",l.createElement("code",{style:i},"errorElement")," prop on your route.")),l.createElement(l.Fragment,null,l.createElement("h2",null,"Unexpected Application Error!"),l.createElement("h3",{style:{fontStyle:"italic"}},s),a?l.createElement("pre",{style:o},a):null,r)}var To=l.createElement(ko,null),Nn=class extends l.Component{constructor(t){super(t),this.state={location:t.location,revalidation:t.revalidation,error:t.error}}static getDerivedStateFromError(t){return{error:t}}static getDerivedStateFromProps(t,s){return s.location!==t.location||s.revalidation!=="idle"&&t.revalidation==="idle"?{error:t.error,location:t.location,revalidation:t.revalidation}:{error:t.error!==void 0?t.error:s.error,location:s.location,revalidation:t.revalidation||s.revalidation}}componentDidCatch(t,s){this.props.onError?this.props.onError(t,s):console.error("React Router caught the following error during render",t)}render(){let t=this.state.error;if(this.context&&typeof t=="object"&&t&&"digest"in t&&typeof t.digest=="string"){const a=Mo(t.digest);a&&(t=a)}let s=t!==void 0?l.createElement(oe.Provider,{value:this.props.routeContext},l.createElement(Is.Provider,{value:t,children:this.props.component})):this.props.children;return this.context?l.createElement(Ao,{error:t},s):s}};Nn.contextType=yn;var _t=new WeakMap;function Ao({children:t,error:s}){let{basename:a}=l.useContext(se);if(typeof s=="object"&&s&&"digest"in s&&typeof s.digest=="string"){let n=wo(s.digest);if(n){let o=_t.get(s);if(o)throw o;let i=fn(n.location,a),r=i.absoluteURL||i.to;if(go(r))throw new Error("Invalid redirect location");if(gn&&!_t.get(s))if(i.isExternal||n.reloadDocument)window.location.href=r;else{const c=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(i.to,{replace:n.replace}));throw _t.set(s,c),c}return l.createElement("meta",{httpEquiv:"refresh",content:`0;url=${r}`})}}return t}function Ro({routeContext:t,match:s,children:a}){let n=l.useContext(Qe);return n&&n.static&&n.staticContext&&(s.route.errorElement||s.route.ErrorBoundary)&&(n.staticContext._deepestRenderedBoundaryId=s.route.id),l.createElement(oe.Provider,{value:t},a)}function Po(t,s=[],a){let n=a?.state;if(t==null){if(!n)return null;if(n.errors)t=n.matches;else if(s.length===0&&!n.initialized&&n.matches.length>0)t=n.matches;else return null}let o=t,i=n?.errors;if(i!=null){let u=o.findIndex(f=>f.route.id&&i?.[f.route.id]!==void 0);B(u>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(i).join(",")}`),o=o.slice(0,Math.min(o.length,u+1))}let r=!1,c=-1;if(a&&n){r=n.renderFallback;for(let u=0;u<o.length;u++){let f=o[u];if((f.route.HydrateFallback||f.route.hydrateFallbackElement)&&(c=u),f.route.id){let{loaderData:v,errors:j}=n,w=f.route.loader&&!v.hasOwnProperty(f.route.id)&&(!j||j[f.route.id]===void 0);if(f.route.lazy||w){a.isStatic&&(r=!0),c>=0?o=o.slice(0,c+1):o=[o[0]];break}}}}let d=a?.onError,h=n&&d?(u,f)=>{d(u,{location:n.location,params:n.matches?.[0]?.params??{},pattern:mo(n.matches),errorInfo:f})}:void 0;return o.reduceRight((u,f,v)=>{let j,w=!1,M=null,y=null;n&&(j=i&&f.route.id?i[f.route.id]:void 0,M=f.route.errorElement||To,r&&(c<0&&v===0?($n("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),w=!0,y=null):c===v&&(w=!0,y=f.route.hydrateFallbackElement||null)));let C=s.concat(o.slice(0,v+1)),N=()=>{let T;return j?T=M:w?T=y:f.route.Component?T=l.createElement(f.route.Component,null):f.route.element?T=f.route.element:T=u,l.createElement(Ro,{match:f,routeContext:{outlet:u,matches:C,isDataRoute:n!=null},children:T})};return n&&(f.route.ErrorBoundary||f.route.errorElement||v===0)?l.createElement(Nn,{location:n.location,revalidation:n.revalidation,component:M,error:j,children:N(),routeContext:{outlet:null,matches:C,isDataRoute:!0},onError:h}):N()},null)}function Os(t){return`${t} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Lo(t){let s=l.useContext(Qe);return B(s,Os(t)),s}function Eo(t){let s=l.useContext(Dt);return B(s,Os(t)),s}function Fo(t){let s=l.useContext(oe);return B(s,Os(t)),s}function Bs(t){let s=Fo(t),a=s.matches[s.matches.length-1];return B(a.route.id,`${t} can only be used on routes that contain a unique "id"`),a.route.id}function Io(){return Bs("useRouteId")}function Do(){let t=l.useContext(Is),s=Eo("useRouteError"),a=Bs("useRouteError");return t!==void 0?t:s.errors?.[a]}function Oo(){let{router:t}=Lo("useNavigate"),s=Bs("useNavigate"),a=l.useRef(!1);return Mn(()=>{a.current=!0}),l.useCallback(async(o,i={})=>{he(a.current,wn),a.current&&(typeof o=="number"?await t.navigate(o):await t.navigate(o,{fromRouteId:s,...i}))},[t,s])}var ca={};function $n(t,s,a){!s&&!ca[t]&&(ca[t]=!0,he(!1,a))}l.memo(Bo);function Bo({routes:t,manifest:s,future:a,state:n,isStatic:o,onError:i}){return Cn(t,void 0,{manifest:s,state:n,isStatic:o,onError:i})}function Gs(t){return No(t.context)}function F(t){B(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function Go({basename:t="/",children:s=null,location:a,navigationType:n="POP",navigator:o,static:i=!1,useTransitions:r}){B(!ct(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let c=t.replace(/^\/*/,"/"),d=l.useMemo(()=>({basename:c,navigator:o,static:i,useTransitions:r,future:{}}),[c,o,i,r]);typeof a=="string"&&(a=qe(a));let{pathname:h="/",search:u="",hash:f="",state:v=null,key:j="default",mask:w}=a,M=l.useMemo(()=>{let y=fe(h,c);return y==null?null:{location:{pathname:y,search:u,hash:f,state:v,key:j,mask:w},navigationType:n}},[c,h,u,f,v,j,n,w]);return he(M!=null,`<Router basename="${c}"> is not able to match the URL "${h}${u}${f}" because it does not start with the basename, so the <Router> won't render anything.`),M==null?null:l.createElement(se.Provider,{value:d},l.createElement(lt.Provider,{children:s,value:M}))}function Ho({children:t,location:s}){return $o(ps(t),s)}function ps(t,s=[]){let a=[];return l.Children.forEach(t,(n,o)=>{if(!l.isValidElement(n))return;let i=[...s,o];if(n.type===l.Fragment){a.push.apply(a,ps(n.props.children,i));return}B(n.type===F,`[${typeof n.type=="string"?n.type:n.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),B(!n.props.index||!n.props.children,"An index route cannot have child routes.");let r={id:n.props.id||i.join("-"),caseSensitive:n.props.caseSensitive,element:n.props.element,Component:n.props.Component,index:n.props.index,path:n.props.path,middleware:n.props.middleware,loader:n.props.loader,action:n.props.action,hydrateFallbackElement:n.props.hydrateFallbackElement,HydrateFallback:n.props.HydrateFallback,errorElement:n.props.errorElement,ErrorBoundary:n.props.ErrorBoundary,hasErrorBoundary:n.props.hasErrorBoundary===!0||n.props.ErrorBoundary!=null||n.props.errorElement!=null,shouldRevalidate:n.props.shouldRevalidate,handle:n.props.handle,lazy:n.props.lazy};n.props.children&&(r.children=ps(n.props.children,i)),a.push(r)}),a}var ft="get",bt="application/x-www-form-urlencoded";function Bt(t){return typeof HTMLElement<"u"&&t instanceof HTMLElement}function Wo(t){return Bt(t)&&t.tagName.toLowerCase()==="button"}function Uo(t){return Bt(t)&&t.tagName.toLowerCase()==="form"}function Vo(t){return Bt(t)&&t.tagName.toLowerCase()==="input"}function zo(t){return!!(t.metaKey||t.altKey||t.ctrlKey||t.shiftKey)}function qo(t,s){return t.button===0&&(!s||s==="_self")&&!zo(t)}var ut=null;function Qo(){if(ut===null)try{new FormData(document.createElement("form"),0),ut=!1}catch{ut=!0}return ut}var _o=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function Kt(t){return t!=null&&!_o.has(t)?(he(!1,`"${t}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${bt}"`),null):t}function Ko(t,s){let a,n,o,i,r;if(Uo(t)){let c=t.getAttribute("action");n=c?fe(c,s):null,a=t.getAttribute("method")||ft,o=Kt(t.getAttribute("enctype"))||bt,i=new FormData(t)}else if(Wo(t)||Vo(t)&&(t.type==="submit"||t.type==="image")){let c=t.form;if(c==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let d=t.getAttribute("formaction")||c.getAttribute("action");if(n=d?fe(d,s):null,a=t.getAttribute("formmethod")||c.getAttribute("method")||ft,o=Kt(t.getAttribute("formenctype"))||Kt(c.getAttribute("enctype"))||bt,i=new FormData(c,t),!Qo()){let{name:h,type:u,value:f}=t;if(u==="image"){let v=h?`${h}.`:"";i.append(`${v}x`,"0"),i.append(`${v}y`,"0")}else h&&i.append(h,f)}}else{if(Bt(t))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');a=ft,n=null,o=bt,r=t}return i&&o==="text/plain"&&(r=i,i=void 0),{action:n,method:a.toLowerCase(),encType:o,formData:i,body:r}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function Hs(t,s){if(t===!1||t===null||typeof t>"u")throw new Error(s)}function kn(t,s,a,n){let o=typeof t=="string"?new URL(t,typeof window>"u"?"server://singlefetch/":window.location.origin):t;return a?o.pathname.endsWith("/")?o.pathname=`${o.pathname}_.${n}`:o.pathname=`${o.pathname}.${n}`:o.pathname==="/"?o.pathname=`_root.${n}`:s&&fe(o.pathname,s)==="/"?o.pathname=`${kt(s)}/_root.${n}`:o.pathname=`${kt(o.pathname)}.${n}`,o}async function Yo(t,s){if(t.id in s)return s[t.id];try{let a=await import(t.module);return s[t.id]=a,a}catch(a){return console.error(`Error loading route module \`${t.module}\`, reloading page...`),console.error(a),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function Jo(t){return t==null?!1:t.href==null?t.rel==="preload"&&typeof t.imageSrcSet=="string"&&typeof t.imageSizes=="string":typeof t.rel=="string"&&typeof t.href=="string"}async function Xo(t,s,a){let n=await Promise.all(t.map(async o=>{let i=s.routes[o.route.id];if(i){let r=await Yo(i,a);return r.links?r.links():[]}return[]}));return si(n.flat(1).filter(Jo).filter(o=>o.rel==="stylesheet"||o.rel==="preload").map(o=>o.rel==="stylesheet"?{...o,rel:"prefetch",as:"style"}:{...o,rel:"prefetch"}))}function da(t,s,a,n,o,i){let r=(d,h)=>a[h]?d.route.id!==a[h].route.id:!0,c=(d,h)=>a[h].pathname!==d.pathname||a[h].route.path?.endsWith("*")&&a[h].params["*"]!==d.params["*"];return i==="assets"?s.filter((d,h)=>r(d,h)||c(d,h)):i==="data"?s.filter((d,h)=>{let u=n.routes[d.route.id];if(!u||!u.hasLoader)return!1;if(r(d,h)||c(d,h))return!0;if(d.route.shouldRevalidate){let f=d.route.shouldRevalidate({currentUrl:new URL(o.pathname+o.search+o.hash,window.origin),currentParams:a[0]?.params||{},nextUrl:new URL(t,window.origin),nextParams:d.params,defaultShouldRevalidate:!0});if(typeof f=="boolean")return f}return!0}):[]}function Zo(t,s,{includeHydrateFallback:a}={}){return ei(t.map(n=>{let o=s.routes[n.route.id];if(!o)return[];let i=[o.module];return o.clientActionModule&&(i=i.concat(o.clientActionModule)),o.clientLoaderModule&&(i=i.concat(o.clientLoaderModule)),a&&o.hydrateFallbackModule&&(i=i.concat(o.hydrateFallbackModule)),o.imports&&(i=i.concat(o.imports)),i}).flat(1))}function ei(t){return[...new Set(t)]}function ti(t){let s={},a=Object.keys(t).sort();for(let n of a)s[n]=t[n];return s}function si(t,s){let a=new Set;return new Set(s),t.reduce((n,o)=>{let i=JSON.stringify(ti(o));return a.has(i)||(a.add(i),n.push({key:i,link:o})),n},[])}function Ws(){let t=l.useContext(Qe);return Hs(t,"You must render this element inside a <DataRouterContext.Provider> element"),t}function ai(){let t=l.useContext(Dt);return Hs(t,"You must render this element inside a <DataRouterStateContext.Provider> element"),t}var Us=l.createContext(void 0);Us.displayName="FrameworkContext";function Gt(){let t=l.useContext(Us);return Hs(t,"You must render this element inside a <HydratedRouter> element"),t}function ni(t,s){let a=l.useContext(Us),[n,o]=l.useState(!1),[i,r]=l.useState(!1),{onFocus:c,onBlur:d,onMouseEnter:h,onMouseLeave:u,onTouchStart:f}=s,v=l.useRef(null);l.useEffect(()=>{if(t==="render"&&r(!0),t==="viewport"){let M=C=>{C.forEach(N=>{r(N.isIntersecting)})},y=new IntersectionObserver(M,{threshold:.5});return v.current&&y.observe(v.current),()=>{y.disconnect()}}},[t]),l.useEffect(()=>{if(n){let M=setTimeout(()=>{r(!0)},100);return()=>{clearTimeout(M)}}},[n]);let j=()=>{o(!0)},w=()=>{o(!1),r(!1)};return a?t!=="intent"?[i,v,{}]:[i,v,{onFocus:Ye(c,j),onBlur:Ye(d,w),onMouseEnter:Ye(h,j),onMouseLeave:Ye(u,w),onTouchStart:Ye(f,j)}]:[!1,v,{}]}function Ye(t,s){return a=>{t&&t(a),a.defaultPrevented||s(a)}}function ri({page:t,...s}){let a=fo(),{nonce:n}=Gt(),{router:o}=Ws(),i=l.useMemo(()=>cn(o.routes,t,o.basename),[o.routes,t,o.basename]);return i?(s.nonce==null&&n&&(s={...s,nonce:n}),a?l.createElement(ii,{page:t,matches:i,...s}):l.createElement(li,{page:t,matches:i,...s})):null}function oi(t){let{manifest:s,routeModules:a}=Gt(),[n,o]=l.useState([]);return l.useEffect(()=>{let i=!1;return Xo(t,s,a).then(r=>{i||o(r)}),()=>{i=!0}},[t,s,a]),n}function ii({page:t,matches:s,...a}){let n=ie(),{future:o}=Gt(),{basename:i}=Ws(),r=l.useMemo(()=>{if(t===n.pathname+n.search+n.hash)return[];let c=kn(t,i,o.v8_trailingSlashAwareDataRequests,"rsc"),d=!1,h=[];for(let u of s)typeof u.route.shouldRevalidate=="function"?d=!0:h.push(u.route.id);return d&&h.length>0&&c.searchParams.set("_routes",h.join(",")),[c.pathname+c.search]},[i,o.v8_trailingSlashAwareDataRequests,t,n,s]);return l.createElement(l.Fragment,null,r.map(c=>l.createElement("link",{key:c,rel:"prefetch",as:"fetch",href:c,...a})))}function li({page:t,matches:s,...a}){let n=ie(),{future:o,manifest:i,routeModules:r}=Gt(),{basename:c}=Ws(),{loaderData:d,matches:h}=ai(),u=l.useMemo(()=>da(t,s,h,i,n,"data"),[t,s,h,i,n]),f=l.useMemo(()=>da(t,s,h,i,n,"assets"),[t,s,h,i,n]),v=l.useMemo(()=>{if(t===n.pathname+n.search+n.hash)return[];let M=new Set,y=!1;if(s.forEach(N=>{let T=i.routes[N.route.id];!T||!T.hasLoader||(!u.some(P=>P.route.id===N.route.id)&&N.route.id in d&&r[N.route.id]?.shouldRevalidate||T.hasClientLoader?y=!0:M.add(N.route.id))}),M.size===0)return[];let C=kn(t,c,o.v8_trailingSlashAwareDataRequests,"data");return y&&M.size>0&&C.searchParams.set("_routes",s.filter(N=>M.has(N.route.id)).map(N=>N.route.id).join(",")),[C.pathname+C.search]},[c,o.v8_trailingSlashAwareDataRequests,d,n,i,u,s,t,r]),j=l.useMemo(()=>Zo(f,i),[f,i]),w=oi(f);return l.createElement(l.Fragment,null,v.map(M=>l.createElement("link",{key:M,rel:"prefetch",as:"fetch",href:M,...a})),j.map(M=>l.createElement("link",{key:M,rel:"modulepreload",href:M,...a})),w.map(({key:M,link:y})=>l.createElement("link",{key:M,nonce:a.nonce,...y,crossOrigin:y.crossOrigin??a.crossOrigin})))}function ci(...t){return s=>{t.forEach(a=>{typeof a=="function"?a(s):a!=null&&(a.current=s)})}}var di=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{di&&(window.__reactRouterVersion="7.18.1")}catch{}function ui({basename:t,children:s,useTransitions:a,window:n}){let o=l.useRef();o.current==null&&(o.current=Wr({window:n,v5Compat:!0}));let i=o.current,[r,c]=l.useState({action:i.action,location:i.location}),d=l.useCallback(h=>{a===!1?c(h):l.startTransition(()=>c(h))},[a]);return l.useLayoutEffect(()=>i.listen(d),[i,d]),l.createElement(Go,{basename:t,children:s,location:r.location,navigationType:r.action,navigator:i,useTransitions:a})}var S=l.forwardRef(function({onClick:s,discover:a="render",prefetch:n="none",relative:o,reloadDocument:i,replace:r,mask:c,state:d,target:h,to:u,preventScrollReset:f,viewTransition:v,defaultShouldRevalidate:j,...w},M){let{basename:y,navigator:C,useTransitions:N}=l.useContext(se),T=typeof u=="string"&&Es.test(u),P=fn(u,y);u=P.to;let E=So(u,{relative:o}),V=ie(),le=null;if(c){let be=Fs(c,[],V.mask?V.mask.pathname:"/",!0);y!=="/"&&(be.pathname=be.pathname==="/"?y:re([y,be.pathname])),le=C.createHref(be)}let[Le,Ke,qt]=ni(n,w),rr=pi(u,{replace:r,mask:c,state:d,target:h,preventScrollReset:f,relative:o,viewTransition:v,defaultShouldRevalidate:j,useTransitions:N});function or(be){s&&s(be),be.defaultPrevented||rr(be)}let Ys=!(P.isExternal||i),Js=l.createElement("a",{...w,...qt,href:(Ys?le:void 0)||P.absoluteURL||E,onClick:Ys?or:s,ref:ci(M,Ke),target:h,"data-discover":!T&&a==="render"?"true":void 0});return Le&&!T?l.createElement(l.Fragment,null,Js,l.createElement(ri,{page:E})):Js});S.displayName="Link";var hi=l.forwardRef(function({"aria-current":s="page",caseSensitive:a=!1,className:n="",end:o=!1,style:i,to:r,viewTransition:c,children:d,...h},u){let f=dt(r,{relative:h.relative}),v=ie(),j=l.useContext(Dt),{navigator:w,basename:M}=l.useContext(se),y=j!=null&&ji(f)&&c===!0,C=w.encodeLocation?w.encodeLocation(f).pathname:f.pathname,N=v.pathname,T=j&&j.navigation&&j.navigation.location?j.navigation.location.pathname:null;a||(N=N.toLowerCase(),T=T?T.toLowerCase():null,C=C.toLowerCase()),T&&M&&(T=fe(T,M)||T);const P=C!=="/"&&C.endsWith("/")?C.length-1:C.length;let E=N===C||!o&&N.startsWith(C)&&N.charAt(P)==="/",V=T!=null&&(T===C||!o&&T.startsWith(C)&&T.charAt(C.length)==="/"),le={isActive:E,isPending:V,isTransitioning:y},Le=E?s:void 0,Ke;typeof n=="function"?Ke=n(le):Ke=[n,E?"active":null,V?"pending":null,y?"transitioning":null].filter(Boolean).join(" ");let qt=typeof i=="function"?i(le):i;return l.createElement(S,{...h,"aria-current":Le,className:Ke,ref:u,style:qt,to:r,viewTransition:c},typeof d=="function"?d(le):d)});hi.displayName="NavLink";var mi=l.forwardRef(({discover:t="render",fetcherKey:s,navigate:a,reloadDocument:n,replace:o,state:i,method:r=ft,action:c,onSubmit:d,relative:h,preventScrollReset:u,viewTransition:f,defaultShouldRevalidate:v,...j},w)=>{let{useTransitions:M}=l.useContext(se),y=bi(),C=yi(c,{relative:h}),N=r.toLowerCase()==="get"?"get":"post",T=typeof c=="string"&&Es.test(c),P=E=>{if(d&&d(E),E.defaultPrevented)return;E.preventDefault();let V=E.nativeEvent.submitter,le=V?.getAttribute("formmethod")||r,Le=()=>y(V||E.currentTarget,{fetcherKey:s,method:le,navigate:a,replace:o,state:i,relative:h,preventScrollReset:u,viewTransition:f,defaultShouldRevalidate:v});M&&a!==!1?l.startTransition(()=>Le()):Le()};return l.createElement("form",{ref:w,method:N,action:C,onSubmit:n?d:P,...j,"data-discover":!T&&t==="render"?"true":void 0})});mi.displayName="Form";function xi(t){return`${t} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Tn(t){let s=l.useContext(Qe);return B(s,xi(t)),s}function pi(t,{target:s,replace:a,mask:n,state:o,preventScrollReset:i,relative:r,viewTransition:c,defaultShouldRevalidate:d,useTransitions:h}={}){let u=Ds(),f=ie(),v=dt(t,{relative:r});return l.useCallback(j=>{if(qo(j,s)){j.preventDefault();let w=a!==void 0?a:tt(f)===tt(v),M=()=>u(t,{replace:w,mask:n,state:o,preventScrollReset:i,relative:r,viewTransition:c,defaultShouldRevalidate:d});h?l.startTransition(()=>M()):M()}},[f,u,v,a,n,o,s,t,i,r,c,d,h])}var gi=0,fi=()=>`__${String(++gi)}__`;function bi(){let{router:t}=Tn("useSubmit"),{basename:s}=l.useContext(se),a=Io(),n=t.fetch,o=t.navigate;return l.useCallback(async(i,r={})=>{let{action:c,method:d,encType:h,formData:u,body:f}=Ko(i,s);if(r.navigate===!1){let v=r.fetcherKey||fi();await n(v,a,r.action||c,{defaultShouldRevalidate:r.defaultShouldRevalidate,preventScrollReset:r.preventScrollReset,formData:u,body:f,formMethod:r.method||d,formEncType:r.encType||h,flushSync:r.flushSync})}else await o(r.action||c,{defaultShouldRevalidate:r.defaultShouldRevalidate,preventScrollReset:r.preventScrollReset,formData:u,body:f,formMethod:r.method||d,formEncType:r.encType||h,replace:r.replace,state:r.state,fromRouteId:a,flushSync:r.flushSync,viewTransition:r.viewTransition})},[n,o,s,a])}function yi(t,{relative:s}={}){let{basename:a}=l.useContext(se),n=l.useContext(oe);B(n,"useFormAction must be used inside a RouteContext");let[o]=n.matches.slice(-1),i={...dt(t||".",{relative:s})},r=ie();if(t==null){i.search=r.search;let c=new URLSearchParams(i.search),d=c.getAll("index");if(d.some(u=>u==="")){c.delete("index"),d.filter(f=>f).forEach(f=>c.append("index",f));let u=c.toString();i.search=u?`?${u}`:""}}return(!t||t===".")&&o.route.index&&(i.search=i.search?i.search.replace(/^\?/,"?index&"):"?index"),a!=="/"&&(i.pathname=i.pathname==="/"?a:re([a,i.pathname])),tt(i)}function ji(t,{relative:s}={}){let a=l.useContext(jn);B(a!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:n}=Tn("useViewTransitionState"),o=dt(t,{relative:s});if(!a.isTransitioning)return!1;let i=fe(a.currentLocation.pathname,n)||a.currentLocation.pathname,r=fe(a.nextLocation.pathname,n)||a.nextLocation.pathname;return $t(o.pathname,r)!=null||$t(o.pathname,i)!=null}var Ht=class{constructor(){this.listeners=new Set,this.subscribe=this.subscribe.bind(this)}subscribe(t){return this.listeners.add(t),this.onSubscribe(),()=>{this.listeners.delete(t),this.onUnsubscribe()}}hasListeners(){return this.listeners.size>0}onSubscribe(){}onUnsubscribe(){}},vi=class extends Ht{#e;#t;#s;constructor(){super(),this.#s=t=>{if(typeof window<"u"&&window.addEventListener){const s=()=>t();return window.addEventListener("visibilitychange",s,!1),()=>{window.removeEventListener("visibilitychange",s)}}}}onSubscribe(){this.#t||this.setEventListener(this.#s)}onUnsubscribe(){this.hasListeners()||(this.#t?.(),this.#t=void 0)}setEventListener(t){this.#s=t,this.#t?.(),this.#t=t(s=>{typeof s=="boolean"?this.setFocused(s):this.onFocus()})}setFocused(t){this.#e!==t&&(this.#e=t,this.onFocus())}onFocus(){const t=this.isFocused();this.listeners.forEach(s=>{s(t)})}isFocused(){return typeof this.#e=="boolean"?this.#e:globalThis.document?.visibilityState!=="hidden"}},An=new vi,wi={setTimeout:(t,s)=>setTimeout(t,s),clearTimeout:t=>clearTimeout(t),setInterval:(t,s)=>setInterval(t,s),clearInterval:t=>clearInterval(t)},Mi=class{#e=wi;#t=!1;setTimeoutProvider(t){this.#e=t}setTimeout(t,s){return this.#e.setTimeout(t,s)}clearTimeout(t){this.#e.clearTimeout(t)}setInterval(t,s){return this.#e.setInterval(t,s)}clearInterval(t){this.#e.clearInterval(t)}},gs=new Mi;function Si(t){setTimeout(t,0)}var Ci=typeof window>"u"||"Deno"in globalThis;function ae(){}function Ni(t,s){return typeof t=="function"?t(s):t}function $i(t){return typeof t=="number"&&t>=0&&t!==1/0}function ki(t,s){return Math.max(t+(s||0)-Date.now(),0)}function fs(t,s){return typeof t=="function"?t(s):t}function Ti(t,s){return typeof t=="function"?t(s):t}function ua(t,s){const{type:a="all",exact:n,fetchStatus:o,predicate:i,queryKey:r,stale:c}=t;if(r){if(n){if(s.queryHash!==Vs(r,s.options))return!1}else if(!Ve(s.queryKey,r))return!1}if(a!=="all"){const d=s.isActive();if(a==="active"&&!d||a==="inactive"&&d)return!1}return!(typeof c=="boolean"&&s.isStale()!==c||o&&o!==s.state.fetchStatus||i&&!i(s))}function ha(t,s){const{exact:a,status:n,predicate:o,mutationKey:i}=t;if(i){if(!s.options.mutationKey)return!1;if(a){if(st(s.options.mutationKey)!==st(i))return!1}else if(!Ve(s.options.mutationKey,i))return!1}return!(n&&s.state.status!==n||o&&!o(s))}function Vs(t,s){return(s?.queryKeyHashFn||st)(t)}function st(t){return JSON.stringify(t,(s,a)=>bs(a)?Object.keys(a).sort().reduce((n,o)=>(n[o]=a[o],n),{}):a)}function Ve(t,s){if(t===s)return!0;if(typeof t!=typeof s)return!1;if(t&&s&&typeof t=="object"&&typeof s=="object"){if(Array.isArray(t)&&Array.isArray(s)){for(let n=0;n<s.length;n++)if(!Ve(t[n],s[n]))return!1;return!0}const a=Object.keys(s);for(const n of a)if(!Ve(t[n],s[n]))return!1;return!0}return!1}var Ai=Object.prototype.hasOwnProperty;function Rn(t,s,a=0){if(t===s)return t;if(a>500)return s;const n=ma(t)&&ma(s);if(!n&&!(bs(t)&&bs(s)))return s;const i=(n?t:Object.keys(t)).length,r=n?s:Object.keys(s),c=r.length,d=n?new Array(c):{};let h=0;for(let u=0;u<c;u++){const f=n?u:r[u],v=t[f],j=s[f];if(v===j){d[f]=v,(n?u<i:Ai.call(t,f))&&h++;continue}if(v===null||j===null||typeof v!="object"||typeof j!="object"){d[f]=j;continue}const w=Rn(v,j,a+1);d[f]=w,w===v&&h++}return i===c&&h===i?t:d}function ma(t){return Array.isArray(t)&&t.length===Object.keys(t).length}function bs(t){if(!xa(t))return!1;const s=t.constructor;if(s===void 0)return!0;const a=s.prototype;return!(!xa(a)||!a.hasOwnProperty("isPrototypeOf")||Object.getPrototypeOf(t)!==Object.prototype)}function xa(t){return Object.prototype.toString.call(t)==="[object Object]"}function Ri(t){return new Promise(s=>{gs.setTimeout(s,t)})}function Pi(t,s,a){return typeof a.structuralSharing=="function"?a.structuralSharing(t,s):a.structuralSharing!==!1?Rn(t,s):s}function Li(t,s,a=0){const n=[...t,s];return a&&n.length>a?n.slice(1):n}function Ei(t,s,a=0){const n=[s,...t];return a&&n.length>a?n.slice(0,-1):n}var zs=Symbol();function Pn(t,s){return!t.queryFn&&s?.initialPromise?()=>s.initialPromise:!t.queryFn||t.queryFn===zs?()=>Promise.reject(new Error(`Missing queryFn: '${t.queryHash}'`)):t.queryFn}function Fi(t,s,a){let n=!1,o;return Object.defineProperty(t,"signal",{enumerable:!0,get:()=>(o??=s(),n||(n=!0,o.aborted?a():o.addEventListener("abort",a,{once:!0})),o)}),t}var Ln=(()=>{let t=()=>Ci;return{isServer(){return t()},setIsServer(s){t=s}}})();function Ii(){let t,s;const a=new Promise((o,i)=>{t=o,s=i});a.status="pending",a.catch(()=>{});function n(o){Object.assign(a,o),delete a.resolve,delete a.reject}return a.resolve=o=>{n({status:"fulfilled",value:o}),t(o)},a.reject=o=>{n({status:"rejected",reason:o}),s(o)},a}var Di=Si;function Oi(){let t=[],s=0,a=c=>{c()},n=c=>{c()},o=Di;const i=c=>{s?t.push(c):o(()=>{a(c)})},r=()=>{const c=t;t=[],c.length&&o(()=>{n(()=>{c.forEach(d=>{a(d)})})})};return{batch:c=>{let d;s++;try{d=c()}finally{s--,s||r()}return d},batchCalls:c=>(...d)=>{i(()=>{c(...d)})},schedule:i,setNotifyFunction:c=>{a=c},setBatchNotifyFunction:c=>{n=c},setScheduler:c=>{o=c}}}var _=Oi(),Bi=class extends Ht{#e=!0;#t;#s;constructor(){super(),this.#s=t=>{if(typeof window<"u"&&window.addEventListener){const s=()=>t(!0),a=()=>t(!1);return window.addEventListener("online",s,!1),window.addEventListener("offline",a,!1),()=>{window.removeEventListener("online",s),window.removeEventListener("offline",a)}}}}onSubscribe(){this.#t||this.setEventListener(this.#s)}onUnsubscribe(){this.hasListeners()||(this.#t?.(),this.#t=void 0)}setEventListener(t){this.#s=t,this.#t?.(),this.#t=t(this.setOnline.bind(this))}setOnline(t){this.#e!==t&&(this.#e=t,this.listeners.forEach(a=>{a(t)}))}isOnline(){return this.#e}},Tt=new Bi;function Gi(t){return Math.min(1e3*2**t,3e4)}function En(t){return(t??"online")==="online"?Tt.isOnline():!0}var ys=class extends Error{constructor(t){super("CancelledError"),this.revert=t?.revert,this.silent=t?.silent}};function Fn(t){let s=!1,a=0,n;const o=Ii(),i=()=>o.status!=="pending",r=M=>{if(!i()){const y=new ys(M);v(y),t.onCancel?.(y)}},c=()=>{s=!0},d=()=>{s=!1},h=()=>An.isFocused()&&(t.networkMode==="always"||Tt.isOnline())&&t.canRun(),u=()=>En(t.networkMode)&&t.canRun(),f=M=>{i()||(n?.(),o.resolve(M))},v=M=>{i()||(n?.(),o.reject(M))},j=()=>new Promise(M=>{n=y=>{(i()||h())&&M(y)},t.onPause?.()}).then(()=>{n=void 0,i()||t.onContinue?.()}),w=()=>{if(i())return;let M;const y=a===0?t.initialPromise:void 0;try{M=y??t.fn()}catch(C){M=Promise.reject(C)}Promise.resolve(M).then(f).catch(C=>{if(i())return;const N=t.retry??(Ln.isServer()?0:3),T=t.retryDelay??Gi,P=typeof T=="function"?T(a,C):T,E=N===!0||typeof N=="number"&&a<N||typeof N=="function"&&N(a,C);if(s||!E){v(C);return}a++,t.onFail?.(a,C),Ri(P).then(()=>h()?void 0:j()).then(()=>{s?v(C):w()})})};return{promise:o,status:()=>o.status,cancel:r,continue:()=>(n?.(),o),cancelRetry:c,continueRetry:d,canStart:u,start:()=>(u()?w():j().then(w),o)}}var In=class{#e;destroy(){this.clearGcTimeout()}scheduleGc(){this.clearGcTimeout(),$i(this.gcTime)&&(this.#e=gs.setTimeout(()=>{this.optionalRemove()},this.gcTime))}updateGcTime(t){this.gcTime=Math.max(this.gcTime||0,t??(Ln.isServer()?1/0:300*1e3))}clearGcTimeout(){this.#e!==void 0&&(gs.clearTimeout(this.#e),this.#e=void 0)}};function Hi(t){return{onFetch:(s,a)=>{const n=s.options,o=s.fetchOptions?.meta?.fetchMore?.direction,i=s.state.data?.pages||[],r=s.state.data?.pageParams||[];let c={pages:[],pageParams:[]},d=0;const h=async()=>{let u=!1;const f=w=>{Fi(w,()=>s.signal,()=>u=!0)},v=Pn(s.options,s.fetchOptions),j=async(w,M,y)=>{if(u)return Promise.reject(s.signal.reason);if(M==null&&w.pages.length)return Promise.resolve(w);const N=(()=>{const V={client:s.client,queryKey:s.queryKey,pageParam:M,direction:y?"backward":"forward",meta:s.options.meta};return f(V),V})(),T=await v(N),{maxPages:P}=s.options,E=y?Ei:Li;return{pages:E(w.pages,T,P),pageParams:E(w.pageParams,M,P)}};if(o&&i.length){const w=o==="backward",M=w?Wi:pa,y={pages:i,pageParams:r},C=M(n,y);c=await j(y,C,w)}else{const w=t??i.length;do{const M=d===0?r[0]??n.initialPageParam:pa(n,c);if(d>0&&M==null)break;c=await j(c,M),d++}while(d<w)}return c};s.options.persister?s.fetchFn=()=>s.options.persister?.(h,{client:s.client,queryKey:s.queryKey,meta:s.options.meta,signal:s.signal},a):s.fetchFn=h}}}function pa(t,{pages:s,pageParams:a}){const n=s.length-1;return s.length>0?t.getNextPageParam(s[n],s,a[n],a):void 0}function Wi(t,{pages:s,pageParams:a}){return s.length>0?t.getPreviousPageParam?.(s[0],s,a[0],a):void 0}var Ui=class extends In{#e;#t;#s;#n;#r;#a;#l;#o;constructor(t){super(),this.#o=!1,this.#l=t.defaultOptions,this.setOptions(t.options),this.observers=[],this.#r=t.client,this.#n=this.#r.getQueryCache(),this.queryKey=t.queryKey,this.queryHash=t.queryHash,this.#t=fa(this.options),this.state=t.state??this.#t,this.scheduleGc()}get meta(){return this.options.meta}get queryType(){return this.#e}get promise(){return this.#a?.promise}setOptions(t){if(this.options={...this.#l,...t},t?._type&&(this.#e=t._type),this.updateGcTime(this.options.gcTime),this.state&&this.state.data===void 0){const s=fa(this.options);s.data!==void 0&&(this.setState(ga(s.data,s.dataUpdatedAt)),this.#t=s)}}optionalRemove(){!this.observers.length&&this.state.fetchStatus==="idle"&&this.#n.remove(this)}setData(t,s){const a=Pi(this.state.data,t,this.options);return this.#i({data:a,type:"success",dataUpdatedAt:s?.updatedAt,manual:s?.manual}),a}setState(t){this.#i({type:"setState",state:t})}cancel(t){const s=this.#a?.promise;return this.#a?.cancel(t),s?s.then(ae).catch(ae):Promise.resolve()}destroy(){super.destroy(),this.cancel({silent:!0})}get resetState(){return this.#t}reset(){this.destroy(),this.setState(this.resetState)}isActive(){return this.observers.some(t=>Ti(t.options.enabled,this)!==!1)}isDisabled(){return this.getObserversCount()>0?!this.isActive():this.options.queryFn===zs||!this.isFetched()}isFetched(){return this.state.dataUpdateCount+this.state.errorUpdateCount>0}isStatic(){return this.getObserversCount()>0?this.observers.some(t=>fs(t.options.staleTime,this)==="static"):!1}isStale(){return this.getObserversCount()>0?this.observers.some(t=>t.getCurrentResult().isStale):this.state.data===void 0||this.state.isInvalidated}isStaleByTime(t=0){return this.state.data===void 0?!0:t==="static"?!1:this.state.isInvalidated?!0:!ki(this.state.dataUpdatedAt,t)}onFocus(){this.observers.find(s=>s.shouldFetchOnWindowFocus())?.refetch({cancelRefetch:!1}),this.#a?.continue()}onOnline(){this.observers.find(s=>s.shouldFetchOnReconnect())?.refetch({cancelRefetch:!1}),this.#a?.continue()}addObserver(t){this.observers.includes(t)||(this.observers.push(t),this.clearGcTimeout(),this.#n.notify({type:"observerAdded",query:this,observer:t}))}removeObserver(t){this.observers.includes(t)&&(this.observers=this.observers.filter(s=>s!==t),this.observers.length||(this.#a&&(this.#o||this.#c()?this.#a.cancel({revert:!0}):this.#a.cancelRetry()),this.scheduleGc()),this.#n.notify({type:"observerRemoved",query:this,observer:t}))}getObserversCount(){return this.observers.length}#c(){return this.state.fetchStatus==="paused"&&this.state.status==="pending"}invalidate(){this.state.isInvalidated||this.#i({type:"invalidate"})}async fetch(t,s){if(this.state.fetchStatus!=="idle"&&this.#a?.status()!=="rejected"){if(this.state.data!==void 0&&s?.cancelRefetch)this.cancel({silent:!0});else if(this.#a)return this.#a.continueRetry(),this.#a.promise}if(t&&this.setOptions(t),!this.options.queryFn){const d=this.observers.find(h=>h.options.queryFn);d&&this.setOptions(d.options)}const a=new AbortController,n=d=>{Object.defineProperty(d,"signal",{enumerable:!0,get:()=>(this.#o=!0,a.signal)})},o=()=>{const d=Pn(this.options,s),u=(()=>{const f={client:this.#r,queryKey:this.queryKey,meta:this.meta};return n(f),f})();return this.#o=!1,this.options.persister?this.options.persister(d,u,this):d(u)},r=(()=>{const d={fetchOptions:s,options:this.options,queryKey:this.queryKey,client:this.#r,state:this.state,fetchFn:o};return n(d),d})();(this.#e==="infinite"?Hi(this.options.pages):this.options.behavior)?.onFetch(r,this),this.#s=this.state,(this.state.fetchStatus==="idle"||this.state.fetchMeta!==r.fetchOptions?.meta)&&this.#i({type:"fetch",meta:r.fetchOptions?.meta}),this.#a=Fn({initialPromise:s?.initialPromise,fn:r.fetchFn,onCancel:d=>{d instanceof ys&&d.revert&&this.setState({...this.#s,fetchStatus:"idle"}),a.abort()},onFail:(d,h)=>{this.#i({type:"failed",failureCount:d,error:h})},onPause:()=>{this.#i({type:"pause"})},onContinue:()=>{this.#i({type:"continue"})},retry:r.options.retry,retryDelay:r.options.retryDelay,networkMode:r.options.networkMode,canRun:()=>!0});try{const d=await this.#a.start();if(d===void 0)throw new Error(`${this.queryHash} data is undefined`);return this.setData(d),this.#n.config.onSuccess?.(d,this),this.#n.config.onSettled?.(d,this.state.error,this),d}catch(d){if(d instanceof ys){if(d.silent)return this.#a.promise;if(d.revert){if(this.state.data===void 0)throw d;return this.state.data}}throw this.#i({type:"error",error:d}),this.#n.config.onError?.(d,this),this.#n.config.onSettled?.(this.state.data,d,this),d}finally{this.scheduleGc()}}#i(t){const s=a=>{switch(t.type){case"failed":return{...a,fetchFailureCount:t.failureCount,fetchFailureReason:t.error};case"pause":return{...a,fetchStatus:"paused"};case"continue":return{...a,fetchStatus:"fetching"};case"fetch":return{...a,...Vi(a.data,this.options),fetchMeta:t.meta??null};case"success":const n={...a,...ga(t.data,t.dataUpdatedAt),dataUpdateCount:a.dataUpdateCount+1,...!t.manual&&{fetchStatus:"idle",fetchFailureCount:0,fetchFailureReason:null}};return this.#s=t.manual?n:void 0,n;case"error":const o=t.error;return{...a,error:o,errorUpdateCount:a.errorUpdateCount+1,errorUpdatedAt:Date.now(),fetchFailureCount:a.fetchFailureCount+1,fetchFailureReason:o,fetchStatus:"idle",status:"error",isInvalidated:!0};case"invalidate":return{...a,isInvalidated:!0};case"setState":return{...a,...t.state}}};this.state=s(this.state),_.batch(()=>{this.observers.forEach(a=>{a.onQueryUpdate()}),this.#n.notify({query:this,type:"updated",action:t})})}};function Vi(t,s){return{fetchFailureCount:0,fetchFailureReason:null,fetchStatus:En(s.networkMode)?"fetching":"paused",...t===void 0&&{error:null,status:"pending"}}}function ga(t,s){return{data:t,dataUpdatedAt:s??Date.now(),error:null,isInvalidated:!1,status:"success"}}function fa(t){const s=typeof t.initialData=="function"?t.initialData():t.initialData,a=s!==void 0,n=a?typeof t.initialDataUpdatedAt=="function"?t.initialDataUpdatedAt():t.initialDataUpdatedAt:0;return{data:s,dataUpdateCount:0,dataUpdatedAt:a?n??Date.now():0,error:null,errorUpdateCount:0,errorUpdatedAt:0,fetchFailureCount:0,fetchFailureReason:null,fetchMeta:null,isInvalidated:!1,status:a?"success":"pending",fetchStatus:"idle"}}var zi=class extends In{#e;#t;#s;#n;constructor(t){super(),this.#e=t.client,this.mutationId=t.mutationId,this.#s=t.mutationCache,this.#t=[],this.state=t.state||qi(),this.setOptions(t.options),this.scheduleGc()}setOptions(t){this.options=t,this.updateGcTime(this.options.gcTime)}get meta(){return this.options.meta}addObserver(t){this.#t.includes(t)||(this.#t.push(t),this.clearGcTimeout(),this.#s.notify({type:"observerAdded",mutation:this,observer:t}))}removeObserver(t){this.#t=this.#t.filter(s=>s!==t),this.scheduleGc(),this.#s.notify({type:"observerRemoved",mutation:this,observer:t})}optionalRemove(){this.#t.length||(this.state.status==="pending"?this.scheduleGc():this.#s.remove(this))}continue(){return this.#n?.continue()??this.execute(this.state.variables)}async execute(t){const s=()=>{this.#r({type:"continue"})},a={client:this.#e,meta:this.options.meta,mutationKey:this.options.mutationKey};this.#n=Fn({fn:()=>this.options.mutationFn?this.options.mutationFn(t,a):Promise.reject(new Error("No mutationFn found")),onFail:(i,r)=>{this.#r({type:"failed",failureCount:i,error:r})},onPause:()=>{this.#r({type:"pause"})},onContinue:s,retry:this.options.retry??0,retryDelay:this.options.retryDelay,networkMode:this.options.networkMode,canRun:()=>this.#s.canRun(this)});const n=this.state.status==="pending",o=!this.#n.canStart();try{if(n)s();else{this.#r({type:"pending",variables:t,isPaused:o}),this.#s.config.onMutate&&await this.#s.config.onMutate(t,this,a);const r=await this.options.onMutate?.(t,a);r!==this.state.context&&this.#r({type:"pending",context:r,variables:t,isPaused:o})}const i=await this.#n.start();return await this.#s.config.onSuccess?.(i,t,this.state.context,this,a),await this.options.onSuccess?.(i,t,this.state.context,a),await this.#s.config.onSettled?.(i,null,this.state.variables,this.state.context,this,a),await this.options.onSettled?.(i,null,t,this.state.context,a),this.#r({type:"success",data:i}),i}catch(i){try{await this.#s.config.onError?.(i,t,this.state.context,this,a)}catch(r){Promise.reject(r)}try{await this.options.onError?.(i,t,this.state.context,a)}catch(r){Promise.reject(r)}try{await this.#s.config.onSettled?.(void 0,i,this.state.variables,this.state.context,this,a)}catch(r){Promise.reject(r)}try{await this.options.onSettled?.(void 0,i,t,this.state.context,a)}catch(r){Promise.reject(r)}throw this.#r({type:"error",error:i}),i}finally{this.#s.runNext(this)}}#r(t){const s=a=>{switch(t.type){case"failed":return{...a,failureCount:t.failureCount,failureReason:t.error};case"pause":return{...a,isPaused:!0};case"continue":return{...a,isPaused:!1};case"pending":return{...a,context:t.context,data:void 0,failureCount:0,failureReason:null,error:null,isPaused:t.isPaused,status:"pending",variables:t.variables,submittedAt:Date.now()};case"success":return{...a,data:t.data,failureCount:0,failureReason:null,error:null,status:"success",isPaused:!1};case"error":return{...a,data:void 0,error:t.error,failureCount:a.failureCount+1,failureReason:t.error,isPaused:!1,status:"error"}}};this.state=s(this.state),_.batch(()=>{this.#t.forEach(a=>{a.onMutationUpdate(t)}),this.#s.notify({mutation:this,type:"updated",action:t})})}};function qi(){return{context:void 0,data:void 0,error:null,failureCount:0,failureReason:null,isPaused:!1,status:"idle",variables:void 0,submittedAt:0}}var Qi=class extends Ht{constructor(t={}){super(),this.config=t,this.#e=new Set,this.#t=new Map,this.#s=0}#e;#t;#s;build(t,s,a){const n=new zi({client:t,mutationCache:this,mutationId:++this.#s,options:t.defaultMutationOptions(s),state:a});return this.add(n),n}add(t){this.#e.add(t);const s=ht(t);if(typeof s=="string"){const a=this.#t.get(s);a?a.push(t):this.#t.set(s,[t])}this.notify({type:"added",mutation:t})}remove(t){if(this.#e.delete(t)){const s=ht(t);if(typeof s=="string"){const a=this.#t.get(s);if(a)if(a.length>1){const n=a.indexOf(t);n!==-1&&a.splice(n,1)}else a[0]===t&&this.#t.delete(s)}}this.notify({type:"removed",mutation:t})}canRun(t){const s=ht(t);if(typeof s=="string"){const n=this.#t.get(s)?.find(o=>o.state.status==="pending");return!n||n===t}else return!0}runNext(t){const s=ht(t);return typeof s=="string"?this.#t.get(s)?.find(n=>n!==t&&n.state.isPaused)?.continue()??Promise.resolve():Promise.resolve()}clear(){_.batch(()=>{this.#e.forEach(t=>{this.notify({type:"removed",mutation:t})}),this.#e.clear(),this.#t.clear()})}getAll(){return Array.from(this.#e)}find(t){const s={exact:!0,...t};return this.getAll().find(a=>ha(s,a))}findAll(t={}){return this.getAll().filter(s=>ha(t,s))}notify(t){_.batch(()=>{this.listeners.forEach(s=>{s(t)})})}resumePausedMutations(){const t=this.getAll().filter(s=>s.state.isPaused);return _.batch(()=>Promise.all(t.map(s=>s.continue().catch(ae))))}};function ht(t){return t.options.scope?.id}var _i=class extends Ht{constructor(t={}){super(),this.config=t,this.#e=new Map}#e;build(t,s,a){const n=s.queryKey,o=s.queryHash??Vs(n,s);let i=this.get(o);return i||(i=new Ui({client:t,queryKey:n,queryHash:o,options:t.defaultQueryOptions(s),state:a,defaultOptions:t.getQueryDefaults(n)}),this.add(i)),i}add(t){this.#e.has(t.queryHash)||(this.#e.set(t.queryHash,t),this.notify({type:"added",query:t}))}remove(t){const s=this.#e.get(t.queryHash);s&&(t.destroy(),s===t&&this.#e.delete(t.queryHash),this.notify({type:"removed",query:t}))}clear(){_.batch(()=>{this.getAll().forEach(t=>{this.remove(t)})})}get(t){return this.#e.get(t)}getAll(){return[...this.#e.values()]}find(t){const s={exact:!0,...t};return this.getAll().find(a=>ua(s,a))}findAll(t={}){const s=this.getAll();return Object.keys(t).length>0?s.filter(a=>ua(t,a)):s}notify(t){_.batch(()=>{this.listeners.forEach(s=>{s(t)})})}onFocus(){_.batch(()=>{this.getAll().forEach(t=>{t.onFocus()})})}onOnline(){_.batch(()=>{this.getAll().forEach(t=>{t.onOnline()})})}},Ki=class{#e;#t;#s;#n;#r;#a;#l;#o;constructor(t={}){this.#e=t.queryCache||new _i,this.#t=t.mutationCache||new Qi,this.#s=t.defaultOptions||{},this.#n=new Map,this.#r=new Map,this.#a=0}mount(){this.#a++,this.#a===1&&(this.#l=An.subscribe(async t=>{t&&(await this.resumePausedMutations(),this.#e.onFocus())}),this.#o=Tt.subscribe(async t=>{t&&(await this.resumePausedMutations(),this.#e.onOnline())}))}unmount(){this.#a--,this.#a===0&&(this.#l?.(),this.#l=void 0,this.#o?.(),this.#o=void 0)}isFetching(t){return this.#e.findAll({...t,fetchStatus:"fetching"}).length}isMutating(t){return this.#t.findAll({...t,status:"pending"}).length}getQueryData(t){const s=this.defaultQueryOptions({queryKey:t});return this.#e.get(s.queryHash)?.state.data}ensureQueryData(t){const s=this.defaultQueryOptions(t),a=this.#e.build(this,s),n=a.state.data;return n===void 0?this.fetchQuery(t):(t.revalidateIfStale&&a.isStaleByTime(fs(s.staleTime,a))&&this.prefetchQuery(s),Promise.resolve(n))}getQueriesData(t){return this.#e.findAll(t).map(({queryKey:s,state:a})=>{const n=a.data;return[s,n]})}setQueryData(t,s,a){const n=this.defaultQueryOptions({queryKey:t}),i=this.#e.get(n.queryHash)?.state.data,r=Ni(s,i);if(r!==void 0)return this.#e.build(this,n).setData(r,{...a,manual:!0})}setQueriesData(t,s,a){return _.batch(()=>this.#e.findAll(t).map(({queryKey:n})=>[n,this.setQueryData(n,s,a)]))}getQueryState(t){const s=this.defaultQueryOptions({queryKey:t});return this.#e.get(s.queryHash)?.state}removeQueries(t){const s=this.#e;_.batch(()=>{s.findAll(t).forEach(a=>{s.remove(a)})})}resetQueries(t,s){const a=this.#e;return _.batch(()=>(a.findAll(t).forEach(n=>{n.reset()}),this.refetchQueries({type:"active",...t},s)))}cancelQueries(t,s={}){const a={revert:!0,...s},n=_.batch(()=>this.#e.findAll(t).map(o=>o.cancel(a)));return Promise.all(n).then(ae).catch(ae)}invalidateQueries(t,s={}){return _.batch(()=>(this.#e.findAll(t).forEach(a=>{a.invalidate()}),t?.refetchType==="none"?Promise.resolve():this.refetchQueries({...t,type:t?.refetchType??t?.type??"active"},s)))}refetchQueries(t,s={}){const a={...s,cancelRefetch:s.cancelRefetch??!0},n=_.batch(()=>this.#e.findAll(t).filter(o=>!o.isDisabled()&&!o.isStatic()).map(o=>{let i=o.fetch(void 0,a);return a.throwOnError||(i=i.catch(ae)),o.state.fetchStatus==="paused"?Promise.resolve():i}));return Promise.all(n).then(ae)}fetchQuery(t){const s=this.defaultQueryOptions(t);s.retry===void 0&&(s.retry=!1);const a=this.#e.build(this,s);return a.isStaleByTime(fs(s.staleTime,a))?a.fetch(s):Promise.resolve(a.state.data)}prefetchQuery(t){return this.fetchQuery(t).then(ae).catch(ae)}fetchInfiniteQuery(t){return t._type="infinite",this.fetchQuery(t)}prefetchInfiniteQuery(t){return this.fetchInfiniteQuery(t).then(ae).catch(ae)}ensureInfiniteQueryData(t){return t._type="infinite",this.ensureQueryData(t)}resumePausedMutations(){return Tt.isOnline()?this.#t.resumePausedMutations():Promise.resolve()}getQueryCache(){return this.#e}getMutationCache(){return this.#t}getDefaultOptions(){return this.#s}setDefaultOptions(t){this.#s=t}setQueryDefaults(t,s){this.#n.set(st(t),{queryKey:t,defaultOptions:s})}getQueryDefaults(t){const s=[...this.#n.values()],a={};return s.forEach(n=>{Ve(t,n.queryKey)&&Object.assign(a,n.defaultOptions)}),a}setMutationDefaults(t,s){this.#r.set(st(t),{mutationKey:t,defaultOptions:s})}getMutationDefaults(t){const s=[...this.#r.values()],a={};return s.forEach(n=>{Ve(t,n.mutationKey)&&Object.assign(a,n.defaultOptions)}),a}defaultQueryOptions(t){if(t._defaulted)return t;const s={...this.#s.queries,...this.getQueryDefaults(t.queryKey),...t,_defaulted:!0};return s.queryHash||(s.queryHash=Vs(s.queryKey,s)),s.refetchOnReconnect===void 0&&(s.refetchOnReconnect=s.networkMode!=="always"),s.throwOnError===void 0&&(s.throwOnError=!!s.suspense),!s.networkMode&&s.persister&&(s.networkMode="offlineFirst"),s.queryFn===zs&&(s.enabled=!1),s}defaultMutationOptions(t){return t?._defaulted?t:{...this.#s.mutations,...t?.mutationKey&&this.getMutationDefaults(t.mutationKey),...t,_defaulted:!0}}clear(){this.#e.clear(),this.#t.clear()}},Yi=l.createContext(void 0),Ji=({client:t,children:s})=>(l.useEffect(()=>(t.mount(),()=>{t.unmount()}),[t]),e.jsx(Yi.Provider,{value:t,children:s})),Yt,ba;function Xi(){if(ba)return Yt;ba=1;var t=typeof Element<"u",s=typeof Map=="function",a=typeof Set=="function",n=typeof ArrayBuffer=="function"&&!!ArrayBuffer.isView;function o(i,r){if(i===r)return!0;if(i&&r&&typeof i=="object"&&typeof r=="object"){if(i.constructor!==r.constructor)return!1;var c,d,h;if(Array.isArray(i)){if(c=i.length,c!=r.length)return!1;for(d=c;d--!==0;)if(!o(i[d],r[d]))return!1;return!0}var u;if(s&&i instanceof Map&&r instanceof Map){if(i.size!==r.size)return!1;for(u=i.entries();!(d=u.next()).done;)if(!r.has(d.value[0]))return!1;for(u=i.entries();!(d=u.next()).done;)if(!o(d.value[1],r.get(d.value[0])))return!1;return!0}if(a&&i instanceof Set&&r instanceof Set){if(i.size!==r.size)return!1;for(u=i.entries();!(d=u.next()).done;)if(!r.has(d.value[0]))return!1;return!0}if(n&&ArrayBuffer.isView(i)&&ArrayBuffer.isView(r)){if(c=i.length,c!=r.length)return!1;for(d=c;d--!==0;)if(i[d]!==r[d])return!1;return!0}if(i.constructor===RegExp)return i.source===r.source&&i.flags===r.flags;if(i.valueOf!==Object.prototype.valueOf&&typeof i.valueOf=="function"&&typeof r.valueOf=="function")return i.valueOf()===r.valueOf();if(i.toString!==Object.prototype.toString&&typeof i.toString=="function"&&typeof r.toString=="function")return i.toString()===r.toString();if(h=Object.keys(i),c=h.length,c!==Object.keys(r).length)return!1;for(d=c;d--!==0;)if(!Object.prototype.hasOwnProperty.call(r,h[d]))return!1;if(t&&i instanceof Element)return!1;for(d=c;d--!==0;)if(!((h[d]==="_owner"||h[d]==="__v"||h[d]==="__o")&&i.$$typeof)&&!o(i[h[d]],r[h[d]]))return!1;return!0}return i!==i&&r!==r}return Yt=function(r,c){try{return o(r,c)}catch(d){if((d.message||"").match(/stack|recursion/i))return console.warn("react-fast-compare cannot handle circular refs"),!1;throw d}},Yt}var Zi=Xi();const el=ks(Zi);var Jt,ya;function tl(){if(ya)return Jt;ya=1;var t=function(s,a,n,o,i,r,c,d){if(!s){var h;if(a===void 0)h=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");else{var u=[n,o,i,r,c,d],f=0;h=new Error(a.replace(/%s/g,function(){return u[f++]})),h.name="Invariant Violation"}throw h.framesToPop=1,h}};return Jt=t,Jt}var sl=tl();const ja=ks(sl);var Xt,va;function al(){return va||(va=1,Xt=function(s,a,n,o){var i=n?n.call(o,s,a):void 0;if(i!==void 0)return!!i;if(s===a)return!0;if(typeof s!="object"||!s||typeof a!="object"||!a)return!1;var r=Object.keys(s),c=Object.keys(a);if(r.length!==c.length)return!1;for(var d=Object.prototype.hasOwnProperty.bind(a),h=0;h<r.length;h++){var u=r[h];if(!d(u))return!1;var f=s[u],v=a[u];if(i=n?n.call(o,f,v,u):void 0,i===!1||i===void 0&&f!==v)return!1}return!0}),Xt}var nl=al();const rl=ks(nl);var Dn=(t=>(t.BASE="base",t.BODY="body",t.HEAD="head",t.HTML="html",t.LINK="link",t.META="meta",t.NOSCRIPT="noscript",t.SCRIPT="script",t.STYLE="style",t.TITLE="title",t.FRAGMENT="Symbol(react.fragment)",t))(Dn||{}),Zt={link:{rel:["amphtml","canonical","alternate"]},script:{type:["application/ld+json"]},meta:{charset:"",name:["generator","robots","description"],property:["og:type","og:title","og:url","og:image","og:image:alt","og:description","twitter:url","twitter:title","twitter:description","twitter:image","twitter:image:alt","twitter:card","twitter:site"]}},wa=Object.values(Dn),Wt={accesskey:"accessKey",charset:"charSet",class:"className",contenteditable:"contentEditable",contextmenu:"contextMenu","http-equiv":"httpEquiv",itemprop:"itemProp",tabindex:"tabIndex"},On=Object.entries(Wt).reduce((t,[s,a])=>(t[a]=s,t),{}),ne="data-rh",Ie={DEFAULT_TITLE:"defaultTitle",DEFER:"defer",ENCODE_SPECIAL_CHARACTERS:"encodeSpecialCharacters",ON_CHANGE_CLIENT_STATE:"onChangeClientState",TITLE_TEMPLATE:"titleTemplate",PRIORITIZE_SEO_TAGS:"prioritizeSeoTags"},De=(t,s)=>{for(let a=t.length-1;a>=0;a-=1){const n=t[a];if(Object.prototype.hasOwnProperty.call(n,s))return n[s]}return null},ol=t=>{let s=De(t,"title");const a=De(t,Ie.TITLE_TEMPLATE);if(Array.isArray(s)&&(s=s.join("")),a&&s)return a.replace(/%s/g,()=>s);const n=De(t,Ie.DEFAULT_TITLE);return s||n||void 0},il=t=>De(t,Ie.ON_CHANGE_CLIENT_STATE)||(()=>{}),es=(t,s)=>s.filter(a=>typeof a[t]<"u").map(a=>a[t]).reduce((a,n)=>({...a,...n}),{}),ll=(t,s)=>s.filter(a=>typeof a.base<"u").map(a=>a.base).reverse().reduce((a,n)=>{if(!a.length){const o=Object.keys(n);for(let i=0;i<o.length;i+=1){const c=o[i].toLowerCase();if(t.indexOf(c)!==-1&&n[c])return a.concat(n)}}return a},[]),cl=t=>console&&typeof console.warn=="function"&&console.warn(t),Je=(t,s,a)=>{const n={};return a.filter(o=>Array.isArray(o[t])?!0:(typeof o[t]<"u"&&cl(`Helmet: ${t} should be of type "Array". Instead found type "${typeof o[t]}"`),!1)).map(o=>o[t]).reverse().reduce((o,i)=>{const r={};i.filter(d=>{let h;const u=Object.keys(d);for(let v=0;v<u.length;v+=1){const j=u[v],w=j.toLowerCase();s.indexOf(w)!==-1&&!(h==="rel"&&d[h].toLowerCase()==="canonical")&&!(w==="rel"&&d[w].toLowerCase()==="stylesheet")&&(h=w),s.indexOf(j)!==-1&&(j==="innerHTML"||j==="cssText"||j==="itemprop")&&(h=j)}if(!h||!d[h])return!1;const f=d[h].toLowerCase();return n[h]||(n[h]={}),r[h]||(r[h]={}),n[h][f]?!1:(r[h][f]=!0,!0)}).reverse().forEach(d=>o.push(d));const c=Object.keys(r);for(let d=0;d<c.length;d+=1){const h=c[d],u={...n[h],...r[h]};n[h]=u}return o},[]).reverse()},dl=(t,s)=>{if(Array.isArray(t)&&t.length){for(let a=0;a<t.length;a+=1)if(t[a][s])return!0}return!1},ul=t=>({baseTag:ll(["href"],t),bodyAttributes:es("bodyAttributes",t),defer:De(t,Ie.DEFER),encode:De(t,Ie.ENCODE_SPECIAL_CHARACTERS),htmlAttributes:es("htmlAttributes",t),linkTags:Je("link",["rel","href"],t),metaTags:Je("meta",["name","charset","http-equiv","property","itemprop"],t),noscriptTags:Je("noscript",["innerHTML"],t),onChangeClientState:il(t),scriptTags:Je("script",["src","innerHTML"],t),styleTags:Je("style",["cssText"],t),title:ol(t),titleAttributes:es("titleAttributes",t),prioritizeSeoTags:dl(t,Ie.PRIORITIZE_SEO_TAGS)}),Bn=t=>Array.isArray(t)?t.join(""):t,hl=(t,s)=>{const a=Object.keys(t);for(let n=0;n<a.length;n+=1)if(s[a[n]]&&s[a[n]].includes(t[a[n]]))return!0;return!1},ts=(t,s)=>Array.isArray(t)?t.reduce((a,n)=>(hl(n,s)?a.priority.push(n):a.default.push(n),a),{priority:[],default:[]}):{default:t,priority:[]},Ma=(t,s)=>({...t,[s]:void 0}),ml=["noscript","script","style"],js=(t,s=!0)=>s===!1?String(t):String(t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;"),Gn=t=>Object.keys(t).reduce((s,a)=>{const n=typeof t[a]<"u"?`${a}="${t[a]}"`:`${a}`;return s?`${s} ${n}`:n},""),xl=(t,s,a,n)=>{const o=Gn(a),i=Bn(s);return o?`<${t} ${ne}="true" ${o}>${js(i,n)}</${t}>`:`<${t} ${ne}="true">${js(i,n)}</${t}>`},pl=(t,s,a=!0)=>s.reduce((n,o)=>{const i=o,r=Object.keys(i).filter(h=>!(h==="innerHTML"||h==="cssText")).reduce((h,u)=>{const f=typeof i[u]>"u"?u:`${u}="${js(i[u],a)}"`;return h?`${h} ${f}`:f},""),c=i.innerHTML||i.cssText||"",d=ml.indexOf(t)===-1;return`${n}<${t} ${ne}="true" ${r}${d?"/>":`>${c}</${t}>`}`},""),Hn=(t,s={})=>Object.keys(t).reduce((a,n)=>{const o=Wt[n];return a[o||n]=t[n],a},s),gl=(t,s,a)=>{const n={key:s,[ne]:!0},o=Hn(a,n);return[I.createElement("title",o,s)]},yt=(t,s)=>s.map((a,n)=>{const o={key:n,[ne]:!0};return Object.keys(a).forEach(i=>{const c=Wt[i]||i;if(c==="innerHTML"||c==="cssText"){const d=a.innerHTML||a.cssText;o.dangerouslySetInnerHTML={__html:d}}else o[c]=a[i]}),I.createElement(t,o)}),ee=(t,s,a=!0)=>{switch(t){case"title":return{toComponent:()=>gl(t,s.title,s.titleAttributes),toString:()=>xl(t,s.title,s.titleAttributes,a)};case"bodyAttributes":case"htmlAttributes":return{toComponent:()=>Hn(s),toString:()=>Gn(s)};default:return{toComponent:()=>yt(t,s),toString:()=>pl(t,s,a)}}},fl=({metaTags:t,linkTags:s,scriptTags:a,encode:n})=>{const o=ts(t,Zt.meta),i=ts(s,Zt.link),r=ts(a,Zt.script);return{priorityMethods:{toComponent:()=>[...yt("meta",o.priority),...yt("link",i.priority),...yt("script",r.priority)],toString:()=>`${ee("meta",o.priority,n)} ${ee("link",i.priority,n)} ${ee("script",r.priority,n)}`},metaTags:o.default,linkTags:i.default,scriptTags:r.default}},bl=t=>{const{baseTag:s,bodyAttributes:a,encode:n=!0,htmlAttributes:o,noscriptTags:i,styleTags:r,title:c="",titleAttributes:d,prioritizeSeoTags:h}=t;let{linkTags:u,metaTags:f,scriptTags:v}=t,j={toComponent:()=>[],toString:()=>""};return h&&({priorityMethods:j,linkTags:u,metaTags:f,scriptTags:v}=fl(t)),{priority:j,base:ee("base",s,n),bodyAttributes:ee("bodyAttributes",a,n),htmlAttributes:ee("htmlAttributes",o,n),link:ee("link",u,n),meta:ee("meta",f,n),noscript:ee("noscript",i,n),script:ee("script",v,n),style:ee("style",r,n),title:ee("title",{title:c,titleAttributes:d},n)}},vs=bl,mt=[],qs=!!(typeof window<"u"&&window.document&&window.document.createElement),ws=class{instances=[];canUseDOM=qs;context;value={setHelmet:t=>{this.context.helmet=t},helmetInstances:{get:()=>this.canUseDOM?mt:this.instances,add:t=>{(this.canUseDOM?mt:this.instances).push(t)},remove:t=>{const s=(this.canUseDOM?mt:this.instances).indexOf(t);(this.canUseDOM?mt:this.instances).splice(s,1)}}};constructor(t,s){this.context=t,this.canUseDOM=s||!1,s||(t.helmet=vs({baseTag:[],bodyAttributes:{},htmlAttributes:{},linkTags:[],metaTags:[],noscriptTags:[],scriptTags:[],styleTags:[],title:"",titleAttributes:{}}))}},yl=parseInt(I.version.split(".")[0],10),Ms=yl>=19,jl={},Wn=I.createContext(jl),Un=class Vn extends l.Component{static canUseDOM=qs;helmetData;constructor(s){super(s),Ms?this.helmetData=null:this.helmetData=new ws(this.props.context||{},Vn.canUseDOM)}render(){return Ms?I.createElement(I.Fragment,null,this.props.children):I.createElement(Wn.Provider,{value:this.helmetData.value},this.props.children)}},Ee=(t,s)=>{const a=document.head||document.querySelector("head"),n=a.querySelectorAll(`${t}[${ne}]`),o=[].slice.call(n),i=[];let r;return s&&s.length&&s.forEach(c=>{const d=document.createElement(t);for(const h in c)if(Object.prototype.hasOwnProperty.call(c,h))if(h==="innerHTML")d.innerHTML=c.innerHTML;else if(h==="cssText"){const u=c.cssText;d.appendChild(document.createTextNode(u))}else{const u=h,f=typeof c[u]>"u"?"":c[u];d.setAttribute(h,f)}d.setAttribute(ne,"true"),o.some((h,u)=>(r=u,d.isEqualNode(h)))?o.splice(r,1):i.push(d)}),o.forEach(c=>c.parentNode?.removeChild(c)),i.forEach(c=>a.appendChild(c)),{oldTags:o,newTags:i}},Ss=(t,s)=>{const a=document.getElementsByTagName(t)[0];if(!a)return;const n=a.getAttribute(ne),o=n?n.split(","):[],i=[...o],r=Object.keys(s);for(const c of r){const d=s[c]||"";a.getAttribute(c)!==d&&a.setAttribute(c,d),o.indexOf(c)===-1&&o.push(c);const h=i.indexOf(c);h!==-1&&i.splice(h,1)}for(let c=i.length-1;c>=0;c-=1)a.removeAttribute(i[c]);o.length===i.length?a.removeAttribute(ne):a.getAttribute(ne)!==r.join(",")&&a.setAttribute(ne,r.join(","))},vl=(t,s)=>{typeof t<"u"&&document.title!==t&&(document.title=Bn(t)),Ss("title",s)},Sa=(t,s)=>{const{baseTag:a,bodyAttributes:n,htmlAttributes:o,linkTags:i,metaTags:r,noscriptTags:c,onChangeClientState:d,scriptTags:h,styleTags:u,title:f,titleAttributes:v}=t;Ss("body",n),Ss("html",o),vl(f,v);const j={baseTag:Ee("base",a),linkTags:Ee("link",i),metaTags:Ee("meta",r),noscriptTags:Ee("noscript",c),scriptTags:Ee("script",h),styleTags:Ee("style",u)},w={},M={};Object.keys(j).forEach(y=>{const{newTags:C,oldTags:N}=j[y];C.length&&(w[y]=C),N.length&&(M[y]=j[y].oldTags)}),s&&s(),d(t,w,M)},Xe=null,wl=t=>{Xe&&cancelAnimationFrame(Xe),t.defer?Xe=requestAnimationFrame(()=>{Sa(t,()=>{Xe=null})}):(Sa(t),Xe=null)},Ml=wl,Ca=class extends l.Component{rendered=!1;shouldComponentUpdate(t){return!rl(t,this.props)}componentDidUpdate(){this.emitChange()}componentWillUnmount(){const{helmetInstances:t}=this.props.context;t.remove(this),this.emitChange()}emitChange(){const{helmetInstances:t,setHelmet:s}=this.props.context;let a=null;const n=ul(t.get().map(o=>{const{context:i,...r}=o.props;return r}));Un.canUseDOM?Ml(n):vs&&(a=vs(n)),s(a)}init(){if(this.rendered)return;this.rendered=!0;const{helmetInstances:t}=this.props.context;t.add(this),this.emitChange()}render(){return this.init(),null}},jt=[],Na=t=>{const s={};for(const a of Object.keys(t))s[On[a]||a]=t[a];return s},Ce=t=>{const s={};for(const a of Object.keys(t)){const n=Wt[a];s[n||a]=t[a]}return s},$a=(t,s)=>{if(!qs)return;const a=document.getElementsByTagName(t)[0];if(!a)return;const n="data-rh-managed",o=a.getAttribute(n),i=o?o.split(","):[],r=Object.keys(s);for(const c of i)r.includes(c)||a.removeAttribute(c);for(const c of r){const d=s[c];d==null||d===!1?a.removeAttribute(c):d===!0?a.setAttribute(c,""):a.setAttribute(c,String(d))}r.length>0?a.setAttribute(n,r.join(",")):a.removeAttribute(n)},ss=()=>{const t={},s={};for(const a of jt){const{htmlAttributes:n,bodyAttributes:o}=a.props;n&&Object.assign(t,Na(n)),o&&Object.assign(s,Na(o))}$a("html",t),$a("body",s)},Sl=class extends l.Component{componentDidMount(){jt.push(this),ss()}componentDidUpdate(){ss()}componentWillUnmount(){const t=jt.indexOf(this);t!==-1&&jt.splice(t,1),ss()}resolveTitle(){const{title:t,titleTemplate:s,defaultTitle:a}=this.props;return t&&s?s.replace(/%s/g,()=>Array.isArray(t)?t.join(""):t):t||a||void 0}renderTitle(){const t=this.resolveTitle();if(t===void 0)return null;const s=this.props.titleAttributes||{};return I.createElement("title",Ce(s),t)}renderBase(){const{base:t}=this.props;return t?I.createElement("base",Ce(t)):null}renderMeta(){const{meta:t}=this.props;return!t||!Array.isArray(t)?null:t.map((s,a)=>I.createElement("meta",{key:a,...Ce(s)}))}renderLink(){const{link:t}=this.props;return!t||!Array.isArray(t)?null:t.map((s,a)=>I.createElement("link",{key:a,...Ce(s)}))}renderScript(){const{script:t}=this.props;return!t||!Array.isArray(t)?null:t.map((s,a)=>{const{innerHTML:n,...o}=s,i=Ce(o);return n&&(i.dangerouslySetInnerHTML={__html:n}),I.createElement("script",{key:a,...i})})}renderStyle(){const{style:t}=this.props;return!t||!Array.isArray(t)?null:t.map((s,a)=>{const{cssText:n,...o}=s,i=Ce(o);return n&&(i.dangerouslySetInnerHTML={__html:n}),I.createElement("style",{key:a,...i})})}renderNoscript(){const{noscript:t}=this.props;return!t||!Array.isArray(t)?null:t.map((s,a)=>{const{innerHTML:n,...o}=s,i=Ce(o);return n&&(i.dangerouslySetInnerHTML={__html:n}),I.createElement("noscript",{key:a,...i})})}render(){return I.createElement(I.Fragment,null,this.renderTitle(),this.renderBase(),this.renderMeta(),this.renderLink(),this.renderScript(),this.renderStyle(),this.renderNoscript())}},X=class extends l.Component{static defaultProps={defer:!0,encodeSpecialCharacters:!0,prioritizeSeoTags:!1};shouldComponentUpdate(t){return!el(Ma(this.props,"helmetData"),Ma(t,"helmetData"))}mapNestedChildrenToProps(t,s){if(!s)return null;switch(t.type){case"script":case"noscript":return{innerHTML:s};case"style":return{cssText:s};default:throw new Error(`<${t.type} /> elements are self-closing and can not contain children. Refer to our API for more information.`)}}flattenArrayTypeChildren(t,s,a,n){return{...s,[t.type]:[...s[t.type]||[],{...a,...this.mapNestedChildrenToProps(t,n)}]}}mapObjectTypeChildren(t,s,a,n){switch(t.type){case"title":return{...s,[t.type]:n,titleAttributes:{...a}};case"body":return{...s,bodyAttributes:{...a}};case"html":return{...s,htmlAttributes:{...a}};default:return{...s,[t.type]:{...a}}}}mapArrayTypeChildrenToProps(t,s){let a={...s};return Object.keys(t).forEach(n=>{a={...a,[n]:t[n]}}),a}warnOnInvalidChildren(t,s){return ja(wa.some(a=>t.type===a),typeof t.type=="function"?"You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information.":`Only elements types ${wa.join(", ")} are allowed. Helmet does not support rendering <${t.type}> elements. Refer to our API for more information.`),ja(!s||typeof s=="string"||Array.isArray(s)&&!s.some(a=>typeof a!="string"),`Helmet expects a string as a child of <${t.type}>. Did you forget to wrap your children in braces? ( <${t.type}>{\`\`}</${t.type}> ) Refer to our API for more information.`),!0}mapChildrenToProps(t,s){let a={};return I.Children.forEach(t,n=>{if(!n||!n.props)return;const{children:o,...i}=n.props,r=Object.keys(i).reduce((d,h)=>(d[On[h]||h]=i[h],d),{});let{type:c}=n;switch(typeof c=="symbol"?c=c.toString():this.warnOnInvalidChildren(n,o),c){case"Symbol(react.fragment)":s=this.mapChildrenToProps(o,s);break;case"link":case"meta":case"noscript":case"script":case"style":a=this.flattenArrayTypeChildren(n,a,r,o);break;default:s=this.mapObjectTypeChildren(n,s,r,o);break}}),this.mapArrayTypeChildrenToProps(a,s)}render(){const{children:t,...s}=this.props;let a={...s},{helmetData:n}=s;if(t&&(a=this.mapChildrenToProps(t,a)),n&&!(n instanceof ws)){const o=n;n=new ws(o.context,!0),delete a.helmetData}return Ms?I.createElement(Sl,{...a}):n?I.createElement(Ca,{...a,context:n.value}):I.createElement(Wn.Consumer,null,o=>I.createElement(Ca,{...a,context:o}))}};const zn=l.createContext(void 0);function Cl({children:t}){const[s,a]=l.useState(()=>localStorage.getItem("megatoolsx-theme")||"system"),[n,o]=l.useState(!1),[i,r]=l.useState(!1),[c,d]=l.useState(()=>{const v=localStorage.getItem("megatoolsx-font-scale");return v?Number(v):100}),[h,u]=l.useState(!1);l.useEffect(()=>{const v=document.documentElement,j=window.matchMedia("(prefers-color-scheme: dark)"),w=()=>{let M;s==="system"?M=j.matches:M=s==="dark",u(M),v.classList.toggle("dark",M)};return w(),j.addEventListener("change",w),()=>j.removeEventListener("change",w)},[s]),l.useEffect(()=>{localStorage.setItem("megatoolsx-font-scale",String(c)),document.documentElement.style.fontSize=`${c}%`},[c]);const f=v=>{a(v),localStorage.setItem("megatoolsx-theme",v)};return e.jsx(zn.Provider,{value:{theme:s,setTheme:f,isDarkMode:h,sidebarOpen:n,setSidebarOpen:o,searchOpen:i,setSearchOpen:r,fontScale:c,setFontScale:d},children:t})}function Nl(){const t=l.useContext(zn);if(!t)throw new Error("useApp must be used within AppProvider");return t}const ka=t=>{let s;const a=new Set,n=(h,u)=>{const f=typeof h=="function"?h(s):h;if(!Object.is(f,s)){const v=s;s=u??(typeof f!="object"||f===null)?f:Object.assign({},s,f),a.forEach(j=>j(s,v))}},o=()=>s,c={setState:n,getState:o,getInitialState:()=>d,subscribe:h=>(a.add(h),()=>a.delete(h))},d=s=t(n,o,c);return c},$l=(t=>t?ka(t):ka),kl=t=>t;function Tl(t,s=kl){const a=I.useSyncExternalStore(t.subscribe,I.useCallback(()=>s(t.getState()),[t,s]),I.useCallback(()=>s(t.getInitialState()),[t,s]));return I.useDebugValue(a),a}const Ta=t=>{const s=$l(t),a=n=>Tl(s,n);return Object.assign(a,s),a},Ut=(t=>t?Ta(t):Ta),At=Ut(t=>({isOpen:!1,query:"",open:()=>t({isOpen:!0}),close:()=>t({isOpen:!1,query:""}),setQuery:s=>t({query:s})})),Cs=[{code:"en",name:"English",native:"English"},{code:"hi",name:"Hindi",native:"हिन्दी"},{code:"es",name:"Spanish",native:"Español"},{code:"fr",name:"French",native:"Français"},{code:"de",name:"German",native:"Deutsch"},{code:"zh",name:"Chinese",native:"中文"},{code:"ar",name:"Arabic",native:"العربية"},{code:"pt",name:"Portuguese",native:"Português"},{code:"ru",name:"Russian",native:"Русский"},{code:"ja",name:"Japanese",native:"日本語"}],Aa=[{label:"Mega Tools",path:"/tools"},{label:"AI Tools",path:"/ai-tools"},{label:"Categories",path:"/categories"},{label:"Trending",path:"/trending"},{label:"New",path:"/new-tools"}],Ra=[{label:"Compare",path:"/compare",icon:"Scale"},{label:"My Tools",path:"/my-tools",icon:"Bookmark"}];function Al(){const{isDarkMode:t,setTheme:s}=Nl(),a=At(u=>u.open);Ds();const[n,o]=l.useState(!1),[i,r]=l.useState(!1),c=l.useRef(null),[d,h]=l.useState("en");return l.useEffect(()=>{const u=f=>{c.current&&!c.current.contains(f.target)&&r(!1)};return document.addEventListener("mousedown",u),()=>document.removeEventListener("mousedown",u)},[]),e.jsxs("header",{className:"fixed top-0 left-0 right-0 z-50",children:[e.jsx("div",{className:"absolute inset-0 bg-black/80 backdrop-blur-xl border-b border-white/5"}),e.jsx("div",{className:"relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"flex items-center justify-between h-16",children:[e.jsxs(S,{to:"/",className:"flex items-center gap-2.5 group",children:[e.jsx("div",{className:"w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/25",children:e.jsx($,{className:"w-5 h-5 text-white"})}),e.jsxs("span",{className:"text-xl font-bold text-white",children:["Megatools",e.jsx("span",{className:"text-indigo-400",children:"X"})]})]}),e.jsx("nav",{className:"hidden md:flex items-center gap-1",children:Aa.map(u=>e.jsx(S,{to:u.path,className:"px-3 py-2 text-sm text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all",children:u.label},u.path))}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("button",{onClick:a,className:"hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:bg-white/10 hover:text-white transition-all",children:[e.jsx(Q,{className:"w-4 h-4"}),e.jsx("span",{children:"Search 2500+ tools..."}),e.jsxs("kbd",{className:"hidden lg:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-white/10 text-[10px] text-gray-500 font-mono",children:[e.jsx(lr,{className:"w-2.5 h-2.5"}),"K"]})]}),e.jsx("button",{onClick:a,className:"sm:hidden p-2 text-gray-400 hover:text-white transition-colors",children:e.jsx(Q,{className:"w-5 h-5"})}),e.jsx("nav",{className:"hidden lg:flex items-center gap-1",children:Ra.map(u=>e.jsx(S,{to:u.path,className:"px-2.5 py-2 text-sm text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all",children:u.label},u.path))}),e.jsx("button",{onClick:()=>s(t?"light":"dark"),className:"p-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all",children:t?e.jsx(Oe,{className:"w-4 h-4"}):e.jsx(vt,{className:"w-4 h-4"})}),e.jsxs("div",{className:"relative hidden sm:block",ref:c,children:[e.jsxs("button",{onClick:()=>r(!i),className:"flex items-center gap-1 px-2 py-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all text-sm",children:[e.jsx(L,{className:"w-4 h-4"}),e.jsx("span",{className:"hidden lg:inline",children:Cs.find(u=>u.code===d)?.native}),e.jsx(Ha,{className:"w-3 h-3"})]}),e.jsx(wt,{children:i&&e.jsx(k.div,{initial:{opacity:0,y:-8,scale:.95},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:-8,scale:.95},className:"absolute right-0 mt-2 w-48 py-2 rounded-2xl bg-gray-900 border border-white/10 shadow-2xl shadow-black/50 z-50",children:Cs.map(u=>e.jsxs("button",{onClick:()=>{h(u.code),r(!1)},className:`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors ${d===u.code?"text-indigo-400 bg-indigo-500/10":"text-gray-400 hover:text-white hover:bg-white/5"}`,children:[e.jsx("span",{className:"w-6 text-center",children:u.native==="English"?"🇬🇧":u.native==="हिन्दी"?"🇮🇳":u.native==="Español"?"🇪🇸":u.native==="Français"?"🇫🇷":u.native==="Deutsch"?"🇩🇪":u.native==="中文"?"🇨🇳":u.native==="العربية"?"🇸🇦":u.native==="Português"?"🇧🇷":u.native==="Русский"?"🇷🇺":"🇯🇵"}),e.jsx("span",{children:u.native}),e.jsx("span",{className:"text-gray-600 text-xs ml-auto",children:u.name})]},u.code))})})]}),e.jsx("button",{onClick:()=>o(!n),className:"md:hidden p-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all",children:n?e.jsx(Be,{className:"w-5 h-5"}):e.jsx(cr,{className:"w-5 h-5"})})]})]})}),e.jsx(wt,{children:n&&e.jsx(k.div,{initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},className:"md:hidden border-t border-white/5 bg-black/95 backdrop-blur-xl",children:e.jsxs("div",{className:"px-4 py-4 space-y-1",children:[Aa.map(u=>e.jsx(S,{to:u.path,onClick:()=>o(!1),className:"block px-4 py-3 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-all",children:u.label},u.path)),e.jsx("div",{className:"border-t border-white/5 my-2"}),Ra.map(u=>e.jsx(S,{to:u.path,onClick:()=>o(!1),className:"block px-4 py-3 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-all",children:u.label},u.path))]})})})]})}const Rl={Platform:[{label:"All Tools",path:"/tools"},{label:"Categories",path:"/categories"},{label:"Trending",path:"/trending"},{label:"New Tools",path:"/new-tools"},{label:"Popular",path:"/popular"},{label:"Compare Tools",path:"/compare"},{label:"My Tools",path:"/my-tools"}],Categories:[{label:"AI Tools Collection",path:"/ai-tools"},{label:"Mega Tools",path:"/tools"},{label:"All Categories",path:"/categories"},{label:"Video/Audio Tools",path:"/category/video-audio-tools"},{label:"Content Writing",path:"/category/content-writing"}],Resources:[{label:"Blog",path:"/blog"},{label:"AI Tools",path:"/ai-tools"},{label:"All Tools",path:"/tools"},{label:"Categories",path:"/categories"},{label:"Trending Tools",path:"/trending"}],Company:[{label:"About",path:"/about"},{label:"Contact",path:"/contact"},{label:"Privacy Policy",path:"/privacy"},{label:"Terms of Service",path:"/terms"},{label:"Admin Dashboard",path:"/admin"}]};function Pl(){return e.jsx("footer",{className:"relative border-t border-white/5 bg-black/50 backdrop-blur-xl",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16",children:[e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-8 mb-12",children:Object.entries(Rl).map(([t,s])=>e.jsxs("div",{children:[e.jsx("h3",{className:"text-white font-semibold mb-4 text-sm uppercase tracking-wider",children:t}),e.jsx("ul",{className:"space-y-2.5",children:s.map(a=>e.jsx("li",{children:e.jsx(S,{to:a.path,className:"text-gray-500 hover:text-indigo-400 text-sm transition-colors",children:a.label})},a.path))})]},t))}),e.jsx("div",{className:"border-t border-white/5 pt-8",children:e.jsxs("div",{className:"flex flex-col md:flex-row items-center justify-between gap-6",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx($,{className:"w-5 h-5 text-indigo-500"}),e.jsxs("span",{className:"text-white font-bold",children:["Megatools",e.jsx("span",{className:"text-indigo-400",children:"X"})]}),e.jsxs("span",{className:"text-gray-600 text-sm ml-2",children:["© ",new Date().getFullYear()," — All rights reserved"]})]}),e.jsxs("p",{className:"text-gray-600 text-sm flex items-center gap-1",children:["Made with ",e.jsx(me,{className:"w-3.5 h-3.5 text-red-500"})," by MegatoolsX Team"]}),e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("a",{href:"https://x.com/megatoolsx",className:"text-gray-600 hover:text-indigo-400 transition-colors",target:"_blank",rel:"noopener noreferrer",children:e.jsx(L,{className:"w-5 h-5"})}),e.jsx("a",{href:"https://github.com/megatoolsx",className:"text-gray-600 hover:text-indigo-400 transition-colors",target:"_blank",rel:"noopener noreferrer",children:e.jsx(Wa,{className:"w-5 h-5"})}),e.jsx("a",{href:"mailto:hello@megatoolsx.com",className:"text-gray-600 hover:text-indigo-400 transition-colors",children:e.jsx(Pt,{className:"w-5 h-5"})})]})]})})]})})}const Ll=["Present","Generative","Future"],as={Present:{label:"Working Tool",emoji:"✅",color:"#10b981",badge:"bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"},Generative:{label:"New AI Tool",emoji:"🟣",color:"#a855f7",badge:"bg-purple-500/10 text-purple-400 border border-purple-500/20"},Future:{label:"Coming Soon",emoji:"🔮",color:"#f59e0b",badge:"bg-amber-500/10 text-amber-400 border border-amber-500/20"}};function qn(t){return t==="Present"?as.Present:t==="Generative"?as.Generative:t==="Future"?as.Future:{label:t,emoji:"🔹",color:"#64748b",badge:"bg-gray-500/10 text-gray-400 border border-gray-500/20"}}const El=[{name:"ChatGPT",slug:"chatgpt",category:"AI Chatbots",description:"AI-powered conversational assistant by OpenAI"},{name:"Claude",slug:"claude",category:"AI Chatbots",description:"Anthropic's advanced AI assistant for complex tasks"},{name:"Gemini",slug:"gemini",category:"AI Chatbots",description:"Google's multimodal AI model"},{name:"Copilot",slug:"copilot",category:"AI Coding",description:"AI pair programmer by GitHub and Microsoft"},{name:"Midjourney",slug:"midjourney",category:"AI Image Generation",description:"AI-powered image generation from text prompts"},{name:"DALL-E",slug:"dall-e",category:"AI Image Generation",description:"OpenAI's image generation model"},{name:"Stable Diffusion",slug:"stable-diffusion",category:"AI Image Generation",description:"Open-source AI image generation model"},{name:"Adobe Firefly",slug:"adobe-firefly",category:"AI Image Generation",description:"Adobe's generative AI for creatives"},{name:"Leonardo AI",slug:"leonardo-ai",category:"AI Image Generation",description:"AI-powered art and image generation platform"},{name:"Runway ML",slug:"runway-ml",category:"AI Video",description:"AI-powered video editing and generation"},{name:"Synthesia",slug:"synthesia",category:"AI Video",description:"AI video generation with virtual avatars"},{name:"ElevenLabs",slug:"elevenlabs",category:"AI Audio",description:"AI voice synthesis and cloning platform"},{name:"Murf AI",slug:"murf-ai",category:"AI Audio",description:"AI voiceover and text-to-speech platform"},{name:"Grammarly",slug:"grammarly",category:"AI Writing",description:"AI-powered writing assistant"},{name:"Jasper AI",slug:"jasper-ai",category:"AI Writing",description:"AI content generation for marketing"},{name:"Copy AI",slug:"copy-ai",category:"AI Writing",description:"AI copywriting and content generation"},{name:"Writesonic",slug:"writesonic",category:"AI Writing",description:"AI writing platform for marketing content"},{name:"Perplexity AI",slug:"perplexity-ai",category:"AI Search",description:"AI-powered search engine and research assistant"},{name:"You.com",slug:"you-com",category:"AI Search",description:"AI search engine with chat capabilities"},{name:"Notion AI",slug:"notion-ai",category:"AI Productivity",description:"AI-powered writing and productivity assistant"},{name:"Gamma AI",slug:"gamma-ai",category:"AI Presentations",description:"AI-powered presentation creation"},{name:"Beautiful AI",slug:"beautiful-ai",category:"AI Presentations",description:"AI-powered slide deck design"},{name:"Canva AI",slug:"canva-ai",category:"AI Design",description:"AI-powered design features in Canva"},{name:"HeyGen",slug:"heygen",category:"AI Video",description:"AI video generation platform with avatars"},{name:"Pictory",slug:"pictory",category:"AI Video",description:"AI video creation from long-form content"},{name:"Descript",slug:"descript",category:"AI Video/Audio",description:"AI-powered video and audio editing"},{name:"Otter AI",slug:"otter-ai",category:"AI Transcription",description:"AI meeting transcription and note-taking"},{name:"Sora",slug:"sora",category:"AI Video",description:"OpenAI's text-to-video generation model"},{name:"DeepSeek",slug:"deepseek",category:"AI Chatbots",description:"Advanced AI language model"},{name:"Grok",slug:"grok",category:"AI Chatbots",description:"xAI's conversational AI assistant"}];let xt=null;function Fl(){return xt||(xt=Br.parse(Gr,{header:!0,skipEmptyLines:!0,transformHeader:s=>({Category:"category","Tool Name":"name",Status:"status",Description:"description","SEO Keywords":"seoKeywords","Meta Description":"metaDescription",Slug:"slug"})[s]||s.trim()}).data.filter(s=>s.name&&s.slug&&Ll.includes(s.status)),xt)}function Il(t){const s=new Map;return t.forEach(a=>{const n=a.category;s.set(n,(s.get(n)||0)+1)}),Array.from(s.entries()).map(([a,n])=>({name:a,slug:a.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,""),count:n})).sort((a,n)=>n.count-a.count)}function Dl(t,s){return t.filter(a=>a.category===s)}function Ol(t,s){return t.find(a=>a.slug===s)}const K=Ut((t,s)=>{const a=Fl(),n=Il(a);return{csvTools:a,csvCategories:n,aiTools:El,latestTools:a.slice(0,24),popularTools:[...a].sort(()=>Math.random()-.5).slice(0,24),newestTools:a.slice(-24).reverse(),getToolBySlug:i=>Ol(s().csvTools,i),getAiToolBySlug:i=>s().aiTools.find(r=>r.slug===i),getToolsByCategory:i=>Dl(s().csvTools,i),searchAll:i=>{const r=i.toLowerCase().trim();if(!r)return[];const c=[];return s().aiTools.forEach(d=>{let h=0;const u=d.name.toLowerCase();u===r?h+=100:u.startsWith(r)?h+=80:u.includes(r)&&(h+=60),d.category.toLowerCase().includes(r)&&(h+=30),h>0&&c.push({tool:d,source:"ai",score:h})}),s().csvTools.forEach(d=>{let h=0;const u=d.name.toLowerCase();u===r?h+=100:u.startsWith(r)?h+=80:u.includes(r)&&(h+=60),d.category.toLowerCase().includes(r)&&(h+=30),d.description.toLowerCase().includes(r)&&(h+=20),h>0&&c.push({tool:d,source:"csv",score:h})}),c.sort((d,h)=>h.score-d.score).slice(0,20)},getCsvCategories:()=>s().csvCategories,filterCsvTools:i=>{let r=[...s().csvTools];return i.category&&i.category!=="all"&&(r=r.filter(c=>c.category.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")===i.category||c.category===i.category)),i.sort==="alphabetical"&&r.sort((c,d)=>c.name.localeCompare(d.name)),r},getRelatedTools:(i,r)=>s().csvTools.filter(c=>c.name!==i.name&&c.category===i.category).slice(0,r)}});function z(...t){return t.filter(Boolean).join(" ")}function Qn(t){return{"AI Tools":"#6366f1","AI Models":"#8b5cf6",Chatbots:"#a855f7","Image Generators":"#d946ef","Video Tools":"#ec4899","Audio Tools":"#f43f5e","Writing Tools":"#ef4444","Coding Tools":"#f97316","Design Tools":"#f59e0b","SEO Tools":"#10b981","Marketing Tools":"#14b8a6","Business Tools":"#06b6d4","Finance Tools":"#0ea5e9","Office Tools":"#3b82f6",Education:"#6366f1","Developer Tools":"#8b5cf6",Cloud:"#a855f7",Hosting:"#d946ef",WordPress:"#ec4899",Windows:"#f43f5e",Mac:"#ef4444",Linux:"#f97316",Android:"#84cc16",iPhone:"#22c55e",Google:"#10b981",Microsoft:"#14b8a6",Adobe:"#06b6d4",Meta:"#0ea5e9",OpenAI:"#3b82f6",GitHub:"#6366f1",Canva:"#8b5cf6",Figma:"#a855f7",Notion:"#d946ef",Slack:"#ec4899",Discord:"#f43f5e",Zoom:"#ef4444",Netflix:"#f97316",YouTube:"#f59e0b",Instagram:"#eab308",Facebook:"#84cc16",WhatsApp:"#22c55e",LinkedIn:"#10b981",Pinterest:"#14b8a6",Reddit:"#06b6d4","X (Twitter)":"#0ea5e9",Amazon:"#3b82f6","Google Maps":"#6366f1","Google Drive":"#8b5cf6","Google Docs":"#a855f7","Google Sheets":"#d946ef","Google Chrome":"#ec4899",Gmail:"#f43f5e","Google Photos":"#ef4444","Google Meet":"#f97316","Google Calendar":"#f59e0b"}[t]||"#6366f1"}function Me(t){return{"Video/Audio Tools":"#ec4899","Content Writing":"#ef4444","SEO/Digital Marketing":"#10b981","Design/Creative":"#a855f7","Developers/Coding":"#3b82f6","Business/Finance":"#06b6d4","Technology/Future":"#8b5cf6","Personal/Lifestyle":"#22c55e","Education/Learning":"#f97316","HealthTech/BioTech":"#14b8a6","Climate/Environment":"#0ea5e9","Space/Astronomy":"#6366f1","Gaming/ARVR":"#f59e0b","IoT/Robotics":"#64748b","Generative Science":"#d946ef","Entertainment/Culture":"#f43f5e"}[t]||"#6366f1"}function Bl(){const{isOpen:t,query:s,setQuery:a,close:n}=At(),{searchAll:o,csvTools:i,aiTools:r}=K(),c=Ds(),d=l.useRef(null),[h,u]=l.useState(0),f=o(s);l.useEffect(()=>{t&&setTimeout(()=>d.current?.focus(),100),u(0)},[t]),l.useEffect(()=>{const j=w=>{if((w.metaKey||w.ctrlKey)&&w.key==="k"&&(w.preventDefault(),t?n():At.getState().open()),!!t&&(w.key==="Escape"&&n(),w.key==="ArrowDown"&&(w.preventDefault(),u(M=>Math.min(M+1,f.length-1))),w.key==="ArrowUp"&&(w.preventDefault(),u(M=>Math.max(M-1,0))),w.key==="Enter"&&f[h])){const M=f[h],y=M.source==="ai"?`/ai-tools/${M.tool.slug}`:`/tools/${M.tool.slug}`;c(y),n()}};return window.addEventListener("keydown",j),()=>window.removeEventListener("keydown",j)},[t,f,h,c,n]);const v=(j,w)=>{c(w==="ai"?`/ai-tools/${j}`:`/tools/${j}`),n()};return e.jsx(wt,{children:t&&e.jsxs(k.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:"fixed inset-0 z-[100] flex items-start justify-center pt-[15vh]",children:[e.jsx("div",{className:"absolute inset-0 bg-black/80 backdrop-blur-sm",onClick:n}),e.jsx(k.div,{initial:{opacity:0,scale:.95,y:-20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.95,y:-20},className:"relative w-full max-w-2xl mx-4",children:e.jsxs("div",{className:"bg-gray-900 border border-white/10 rounded-2xl shadow-2xl shadow-black/50 overflow-hidden",children:[e.jsxs("div",{className:"flex items-center gap-3 px-5 py-4 border-b border-white/5",children:[e.jsx(Q,{className:"w-5 h-5 text-gray-500"}),e.jsx("input",{ref:d,type:"text",value:s,onChange:j=>a(j.target.value),placeholder:"Search AI tools + 2500+ Mega Tools...",className:"flex-1 bg-transparent text-white text-lg placeholder-gray-600 focus:outline-none"}),e.jsx("button",{onClick:n,className:"p-1 text-gray-600 hover:text-gray-400 transition-colors",children:e.jsx(Be,{className:"w-5 h-5"})})]}),e.jsx("div",{className:"max-h-[60vh] overflow-y-auto",children:s?f.length>0?e.jsx("div",{className:"p-2 space-y-0.5",children:f.map((j,w)=>e.jsxs("button",{onClick:()=>v(j.tool.slug,j.source),className:z("w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all",w===h?"bg-indigo-500/10 text-white":"text-gray-400 hover:bg-white/5"),children:[e.jsx("div",{className:z("w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs flex-shrink-0",j.source==="ai"?"bg-gradient-to-br from-purple-500 to-pink-600":"bg-gradient-to-br from-indigo-500 to-purple-600"),children:j.tool.name.charAt(0)}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("div",{className:"text-sm font-medium truncate",children:j.tool.name}),e.jsxs("div",{className:"text-xs text-gray-600 flex items-center gap-1",children:[j.source==="ai"?e.jsx($,{className:"w-3 h-3 text-purple-400"}):null,e.jsx("span",{children:j.source==="ai"?"AI Tool":j.tool.category})]})]}),e.jsx(Lt,{className:"w-4 h-4 text-gray-600 flex-shrink-0"})]},`${j.source}-${j.tool.slug}`))}):e.jsx("div",{className:"p-8 text-center",children:e.jsxs("p",{className:"text-gray-500",children:['No results found for "',s,'"']})}):e.jsxs("div",{className:"p-4",children:[e.jsxs("div",{className:"flex items-center gap-2 text-xs text-gray-600 uppercase tracking-wider mb-3 px-2",children:[e.jsx(Ge,{className:"w-3 h-3"}),"Quick Access"]}),e.jsx("div",{className:"grid grid-cols-2 gap-1",children:i.slice(0,12).map(j=>e.jsxs("button",{onClick:()=>v(j.slug,"csv"),className:"flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-all text-left",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0"}),e.jsx("span",{className:"truncate",children:j.name})]},j.slug))})]})}),e.jsxs("div",{className:"flex items-center justify-between px-5 py-3 border-t border-white/5 bg-black/20",children:[e.jsxs("div",{className:"flex items-center gap-3 text-xs text-gray-600",children:[e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 text-[10px] text-gray-500 font-mono",children:"↑↓"}),e.jsx("span",{children:"Navigate"})]}),e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 text-[10px] text-gray-500 font-mono",children:"Enter"}),e.jsx("span",{children:"Open"})]}),e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx("kbd",{className:"px-1.5 py-0.5 rounded bg-white/10 text-[10px] text-gray-500 font-mono",children:"Esc"}),e.jsx("span",{children:"Close"})]})]}),e.jsxs("div",{className:"flex items-center gap-2 text-xs text-gray-600",children:[e.jsx($,{className:"w-3 h-3 text-purple-500"}),e.jsx("span",{children:"Searching AI + Mega Tools"})]})]})]})})]})})}function Gl({title:t="MegatoolsX - World's Largest Tools Platform",description:s="Free online tools, AI tools, and utilities. Use 2500+ working tools online at MegatoolsX.",slug:a="",image:n="/og-image.png",type:o="website",publishedTime:i,modifiedTime:r,author:c="MegatoolsX",tool:d,lang:h="en",noIndex:u=!1}){const f="https://megatoolsx.com",v=h==="en"?"":`/${h}`,j=`${f}${v}${a?"/"+a:""}`,w={"@context":"https://schema.org","@type":"WebSite",name:"MegatoolsX",url:f,description:"Free online tools and AI tools platform with 2500+ working tools.",potentialAction:{"@type":"SearchAction",target:{"@type":"EntryPoint",urlTemplate:`${f}/search?q={search_term_string}`},"query-input":"required name=search_term_string"}},M=d?{"@context":"https://schema.org","@type":"SoftwareApplication",name:d.name,description:d.description,operatingSystem:"All",applicationCategory:d.category,offers:{"@type":"Offer",price:"0",priceCurrency:"USD"},author:{"@type":"Organization",name:"MegatoolsX"}}:null,y=d?{"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:[{"@type":"ListItem",position:1,name:"Home",item:f},{"@type":"ListItem",position:2,name:"Tools",item:`${f}/tools`},{"@type":"ListItem",position:3,name:d.name,item:`${f}/tools/${d.slug}`}]}:null,C=d?{"@context":"https://schema.org","@type":"FAQPage",mainEntity:[{"@type":"Question",name:`What is ${d.name}?`,acceptedAnswer:{"@type":"Answer",text:`${d.name} is a ${d.category.toLowerCase()} tool that helps users ${d.description.toLowerCase()}`}},{"@type":"Question",name:`How to use ${d.name}?`,acceptedAnswer:{"@type":"Answer",text:`You can use ${d.name} directly on MegatoolsX for free. Just visit the tool page and follow the instructions.`}}]}:null;return e.jsxs(X,{children:[e.jsx("title",{children:t}),e.jsx("meta",{name:"description",content:s}),e.jsx("link",{rel:"canonical",href:j}),u&&e.jsx("meta",{name:"robots",content:"noindex,nofollow"}),Cs.map(N=>e.jsx("link",{rel:"alternate",hrefLang:N.code,href:`${f}${N.code==="en"?"":"/"+N.code}${a?"/"+a:""}`},N.code)),e.jsx("link",{rel:"alternate",hrefLang:"x-default",href:f}),e.jsx("meta",{property:"og:title",content:t}),e.jsx("meta",{property:"og:description",content:s}),e.jsx("meta",{property:"og:url",content:j}),e.jsx("meta",{property:"og:image",content:`${f}${n}`}),e.jsx("meta",{property:"og:type",content:o}),e.jsx("meta",{property:"og:site_name",content:"MegatoolsX"}),e.jsx("meta",{property:"og:locale",content:h==="en"?"en_US":`${h}_${h.toUpperCase()}`}),e.jsx("meta",{name:"twitter:card",content:"summary_large_image"}),e.jsx("meta",{name:"twitter:title",content:t}),e.jsx("meta",{name:"twitter:description",content:s}),e.jsx("meta",{name:"twitter:image",content:`${f}${n}`}),i&&e.jsx("meta",{property:"article:published_time",content:i}),r&&e.jsx("meta",{property:"article:modified_time",content:r}),c&&e.jsx("meta",{property:"article:author",content:c}),d?.seoKeywords&&e.jsx("meta",{name:"keywords",content:d.seoKeywords}),e.jsx("script",{type:"application/ld+json",children:JSON.stringify(w)}),M&&e.jsx("script",{type:"application/ld+json",children:JSON.stringify(M)}),y&&e.jsx("script",{type:"application/ld+json",children:JSON.stringify(y)}),C&&e.jsx("script",{type:"application/ld+json",children:JSON.stringify(C)})]})}function Hl(){return e.jsxs("div",{className:"min-h-screen bg-black text-white",children:[e.jsx(Gl,{}),e.jsx(Al,{}),e.jsx(Bl,{}),e.jsx("main",{className:"pt-16",children:e.jsx(Gs,{})}),e.jsx(Pl,{})]})}function Wl(){const{toolName:t}=_e(),{getToolBySlug:s,csvTools:a}=K(),[n,o]=l.useState(null),[i,r]=l.useState(!0);l.useEffect(()=>{if(t){r(!0);const d=s(t);o(d||null),r(!1)}},[t,s]);const c=n?a.filter(d=>d.category===n.category&&d.slug!==n.slug):[];return i?e.jsx("div",{className:"min-h-screen flex items-center justify-center",children:e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"})}):n?e.jsx(Gs,{context:{tool:n,sameCategory:c}}):e.jsx("div",{className:"min-h-screen flex items-center justify-center",children:e.jsxs("div",{className:"text-center",children:[e.jsx("h2",{className:"text-2xl font-bold text-white mb-2",children:"Tool Not Found"}),e.jsx("p",{className:"text-gray-400",children:"The tool you're looking for doesn't exist in our database."}),e.jsx("a",{href:"/tools",className:"inline-block mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700",children:"Browse All Tools"})]})})}function at({status:t,className:s,size:a="sm"}){const n=qn(t);return e.jsxs("span",{className:z("inline-flex items-center gap-1 font-medium",a==="sm"?"text-[10px] px-2 py-0.5 rounded-full":"text-xs px-3 py-1 rounded-full",n.badge,s),children:[e.jsx("span",{children:n.emoji}),n.label]})}function H(t){const{children:s,onClick:a,variant:n="primary",size:o="md",icon:i,className:r,disabled:c,type:d="button"}=t,h="inline-flex items-center justify-center gap-2 font-medium rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 disabled:opacity-50 disabled:cursor-not-allowed",u={primary:"bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-lg shadow-indigo-500/25",secondary:"bg-white/10 text-white hover:bg-white/20 border border-white/10",ghost:"text-gray-400 hover:text-white hover:bg-white/5",outline:"border border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10"},f={sm:"px-3 py-1.5 text-sm",md:"px-5 py-2.5 text-sm",lg:"px-8 py-3.5 text-base"};return e.jsxs("button",{onClick:a,disabled:c,type:d,className:z(h,u[n],f[o],"hover:scale-[1.02] active:scale-[0.98] transition-transform",r),children:[i&&e.jsx(i,{className:"w-4 h-4"}),s]})}function Fe(t){const{title:s,subtitle:a,description:n,className:o}=t;return e.jsxs("div",{className:z("text-center max-w-3xl mx-auto mb-12",o),children:[e.jsx("h2",{className:"text-3xl md:text-4xl font-bold text-white mb-4",children:s}),a&&e.jsx("p",{className:"text-indigo-400 text-sm font-medium mb-2 uppercase tracking-wider",children:a}),n&&e.jsx("p",{className:"text-gray-400 text-lg leading-relaxed",children:n})]})}const Ul={"Video/Audio Tools":de,"Content Writing":A,"SEO/Digital Marketing":L,"Design/Creative":Va,"Developers/Coding":D,"Business/Finance":L,"Technology/Future":de,"Personal/Lifestyle":xe,"Education/Learning":A,"HealthTech/BioTech":xe,"Climate/Environment":L,"Entertainment/Culture":Se,"Gaming/ARVR":Ua,"IoT/Robotics":de,"Space/Astronomy":L,"Generative Science":A},Vl={"Video/Audio Tools":"from-indigo-500 to-purple-600","Content Writing":"from-pink-500 to-rose-600","SEO/Digital Marketing":"from-emerald-500 to-teal-600","Design/Creative":"from-purple-500 to-pink-600","Developers/Coding":"from-blue-500 to-cyan-600","Business/Finance":"from-amber-500 to-orange-600","Technology/Future":"from-violet-500 to-purple-600","Personal/Lifestyle":"from-green-500 to-emerald-600","Education/Learning":"from-red-500 to-pink-600","HealthTech/BioTech":"from-teal-500 to-green-600","Climate/Environment":"from-sky-500 to-blue-600","Entertainment/Culture":"from-orange-500 to-red-600","Gaming/ARVR":"from-cyan-500 to-blue-600","IoT/Robotics":"from-gray-500 to-slate-600","Space/Astronomy":"from-indigo-500 to-blue-600","Generative Science":"from-fuchsia-500 to-pink-600"},zl=[{label:"Mega Tools",value:"2,500+",icon:Se},{label:"AI Tools",value:"30+",icon:ye},{label:"Categories",value:"16+",icon:A},{label:"Monthly Users",value:"5M+",icon:xe}];function ql(){const{csvTools:t,csvCategories:s,aiTools:a,latestTools:n,popularTools:o}=K(),i=At(c=>c.open),r=s.slice(0,12);return e.jsxs("div",{children:[e.jsxs("section",{className:"relative overflow-hidden",children:[e.jsx("div",{className:"absolute inset-0 bg-gradient-to-b from-indigo-500/10 via-purple-500/5 to-transparent"}),e.jsx("div",{className:"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-indigo-500/5 to-purple-500/5 rounded-full blur-3xl"}),e.jsx("div",{className:"relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 lg:pt-28 lg:pb-32",children:e.jsxs(k.div,{initial:{opacity:0,y:40},animate:{opacity:1,y:0},transition:{duration:.6},className:"text-center max-w-4xl mx-auto",children:[e.jsxs(k.div,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{delay:.2},className:"inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm mb-8",children:[e.jsx($,{className:"w-4 h-4"}),e.jsx("span",{children:"The World's Largest Digital Tools Platform"})]}),e.jsxs("h1",{className:"text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight",children:["Master Every Digital",e.jsx("span",{className:"gradient-text",children:" Tool "}),"in One Place"]}),e.jsx("p",{className:"text-lg sm:text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed",children:"2,500+ tools from our CSV database + 30 featured AI tools. Step-by-step guides, tutorials, and solutions for everything."}),e.jsxs(k.button,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.4},onClick:i,className:"w-full max-w-2xl mx-auto flex items-center gap-4 px-6 py-4 rounded-2xl bg-white/5 border border-white/10 text-left hover:bg-white/10 hover:border-indigo-500/30 transition-all group",children:[e.jsx(Q,{className:"w-6 h-6 text-gray-500 group-hover:text-indigo-400 transition-colors"}),e.jsxs("div",{className:"flex-1",children:[e.jsx("div",{className:"text-white font-medium",children:"Search 2,500+ tools..."}),e.jsx("div",{className:"text-sm text-gray-500",children:"Search AI tools + Mega Tools database"})]}),e.jsxs("div",{className:"hidden sm:flex items-center gap-1 text-xs text-gray-600",children:[e.jsx("kbd",{className:"px-2 py-1 rounded-md bg-white/10 font-mono",children:"⌘"}),e.jsx("kbd",{className:"px-2 py-1 rounded-md bg-white/10 font-mono",children:"K"})]})]}),e.jsxs(k.div,{initial:{opacity:0},animate:{opacity:1},transition:{delay:.6},className:"mt-6 flex flex-wrap items-center justify-center gap-2",children:[e.jsx("span",{className:"text-sm text-gray-600",children:"Explore:"}),e.jsx(S,{to:"/ai-tools",className:"px-3 py-1.5 rounded-lg bg-purple-500/10 text-purple-400 text-sm hover:bg-purple-500/20 transition-all",children:"✨ AI Tools"}),e.jsx(S,{to:"/tools",className:"px-3 py-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 text-sm hover:bg-indigo-500/20 transition-all",children:"📦 Mega Tools"}),e.jsx(S,{to:"/categories",className:"px-3 py-1.5 rounded-lg bg-white/5 text-gray-400 text-sm hover:bg-white/10 transition-all",children:"📂 Categories"})]})]})})]}),e.jsx("section",{className:"border-y border-white/5 bg-white/[0.02]",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-8",children:zl.map(c=>e.jsxs("div",{className:"text-center",children:[e.jsxs("div",{className:"flex items-center justify-center gap-2 mb-1",children:[e.jsx(c.icon,{className:"w-5 h-5 text-indigo-500"}),e.jsx("div",{className:"text-2xl font-bold text-white",children:c.value})]}),e.jsx("div",{className:"text-sm text-gray-500",children:c.label})]},c.label))})})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"Browse Categories",description:"All categories generated from the CSV database."}),e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4",children:r.map((c,d)=>{const h=Ul[c.name]||Se,u=Vl[c.name]||"from-indigo-500 to-purple-600";return e.jsx(S,{to:`/category/${c.slug}`,children:e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:d*.05},whileHover:{y:-4},className:"relative group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 transition-all overflow-hidden",children:[e.jsx("div",{className:`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-gradient-to-br ${u}`}),e.jsxs("div",{className:"relative",children:[e.jsx("div",{className:`w-10 h-10 rounded-xl bg-gradient-to-br ${u} flex items-center justify-center mb-3`,children:e.jsx(h,{className:"w-5 h-5 text-white"})}),e.jsx("h3",{className:"text-white font-semibold mb-0.5",children:c.name}),e.jsxs("span",{className:"text-xs text-indigo-400",children:[c.count," tools"]})]})]})},c.name)})})]})}),e.jsx("section",{className:"py-16 lg:py-24 bg-gradient-to-b from-transparent via-purple-500/[0.02] to-transparent",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"Trending AI Tools",subtitle:"Featured Collection",description:"Popular AI tools separate from the main database."}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",children:a.slice(0,8).map((c,d)=>e.jsx(S,{to:`/ai-tools/${c.slug}`,children:e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:d*.03},className:"p-4 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-purple-500/20 hover:from-purple-500/5 transition-all group h-full",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm mb-3",children:c.name.charAt(0)}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-purple-400 transition-colors",children:c.name}),e.jsx("span",{className:"text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400",children:c.category}),e.jsx("p",{className:"text-gray-500 text-xs mt-2 line-clamp-2",children:c.description})]})},c.slug))}),e.jsx("div",{className:"text-center mt-8",children:e.jsx(S,{to:"/ai-tools",children:e.jsx(H,{variant:"outline",size:"lg",icon:$,children:"View All AI Tools"})})})]})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"Latest Mega Tools",subtitle:"From CSV Database",description:"Recently added tools from our 2,500+ tool database."}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",children:n.slice(0,12).map((c,d)=>e.jsx(S,{to:`/tools/${c.slug}`,children:e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:d*.02},className:"p-4 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 hover:from-indigo-500/5 transition-all group h-full",children:[e.jsxs("div",{className:"flex items-start justify-between mb-2",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs",children:c.name.charAt(0)}),e.jsx(at,{status:c.status})]}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-indigo-400 transition-colors truncate",children:c.name}),e.jsx("p",{className:"text-gray-500 text-xs line-clamp-2",children:c.description})]})},c.slug))}),e.jsx("div",{className:"text-center mt-8",children:e.jsx(S,{to:"/tools",children:e.jsx(H,{variant:"outline",size:"lg",icon:Lt,children:"Browse All Mega Tools"})})})]})}),e.jsx("section",{className:"py-16 lg:py-24 bg-gradient-to-b from-transparent via-white/[0.01] to-transparent",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"Popular Mega Tools",description:"Most popular tools from our database."}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",children:o.slice(0,12).map((c,d)=>e.jsx(S,{to:`/tools/${c.slug}`,children:e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:d*.02},className:"p-4 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 transition-all group h-full",children:[e.jsxs("div",{className:"flex items-start justify-between mb-2",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold text-xs",children:c.name.charAt(0)}),e.jsx(at,{status:c.status})]}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-indigo-400 transition-colors truncate",children:c.name}),e.jsx("span",{className:"text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400",children:c.category})]})},c.slug))})]})}),e.jsx("section",{className:"py-16 lg:py-24 bg-gradient-to-b from-transparent via-indigo-500/[0.02] to-transparent",children:e.jsxs("div",{className:"max-w-3xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"Frequently Asked Questions",subtitle:"FAQ",description:"Everything you need to know about MegatoolsX."}),e.jsx("div",{className:"space-y-3",children:Ql.map((c,d)=>e.jsx(Kl,{question:c.q,answer:c.a,index:d},d))})]})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx(Fe,{title:"What Our Users Say",subtitle:"Testimonials",description:"Trusted by professionals, students, and creators worldwide."}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:_l.map((c,d)=>e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:d*.08},className:"p-6 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent",children:[e.jsx(za,{className:"w-8 h-8 text-indigo-500/40 mb-4"}),e.jsx("div",{className:"flex gap-0.5 mb-4",children:Array.from({length:5}).map((h,u)=>e.jsx(G,{className:"w-4 h-4 text-yellow-500 fill-current"},u))}),e.jsxs("p",{className:"text-gray-300 mb-6 leading-relaxed",children:['"',c.text,'"']}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm",children:c.name.charAt(0)}),e.jsxs("div",{children:[e.jsx("div",{className:"text-white font-semibold text-sm",children:c.name}),e.jsx("div",{className:"text-gray-500 text-xs",children:c.role})]})]})]},d))})]})}),e.jsx("section",{className:"pb-16 lg:pb-24",children:e.jsx("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"relative rounded-3xl bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 border border-indigo-500/20 p-10 lg:p-14 text-center overflow-hidden",children:[e.jsx("div",{className:"absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top,_#6366f1,_transparent_60%)]"}),e.jsxs("div",{className:"relative",children:[e.jsx(Pt,{className:"w-10 h-10 text-indigo-400 mx-auto mb-4"}),e.jsx("h2",{className:"text-3xl lg:text-4xl font-bold text-white mb-3",children:"Stay Updated"}),e.jsx("p",{className:"text-gray-400 text-lg mb-8 max-w-md mx-auto",children:"Get new tool guides, tutorials, and platform updates delivered to your inbox."}),e.jsx(Yl,{})]})]})})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsx("div",{className:"relative rounded-3xl bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 border border-indigo-500/20 p-12 text-center overflow-hidden",children:e.jsxs("div",{className:"relative",children:[e.jsx("h2",{className:"text-3xl lg:text-4xl font-bold text-white mb-4",children:"Ready to Master Digital Tools?"}),e.jsx("p",{className:"text-gray-400 text-lg mb-8 max-w-xl mx-auto",children:"2,500+ tools in our database + 30 featured AI tools. All in one place."}),e.jsxs("div",{className:"flex items-center justify-center gap-4",children:[e.jsx(S,{to:"/tools",children:e.jsx(H,{size:"lg",icon:A,children:"Explore Mega Tools"})}),e.jsx(S,{to:"/ai-tools",children:e.jsx(H,{variant:"outline",size:"lg",icon:$,children:"Explore AI Tools"})})]})]})})})})]})}const Ql=[{q:"What is MegatoolsX?",a:"MegatoolsX is the world's largest digital tools knowledge platform. We provide comprehensive guides, tutorials, and solutions for 2,500+ tools across 16+ categories."},{q:"Are the tools free to use?",a:"Many tools in our database offer free plans. Every tool page includes pricing details so you can compare free and paid plans before you start."},{q:"How do I find a specific tool?",a:"Use the search bar in the top navigation, browse by category, or check the popular and trending sections. Every tool has its own dedicated guide page."},{q:"Is the tool database updated regularly?",a:'Yes! We continuously add new tools and update existing guides. Check the "Latest Update" section on each tool page for the most recent changes.'},{q:"Can I bookmark or save tools?",a:'Absolutely. Use the Save, Like, and Compare buttons on any tool page. Your saved tools appear in the "My Tools" section and are stored locally in your browser.'}],_l=[{name:"Priya Sharma",role:"Digital Marketer",text:"MegatoolsX saved me hours of research. Every tool I need has a complete guide with pricing, tutorials, and troubleshooting. It's my go-to resource now."},{name:"James Wilson",role:"Freelance Developer",text:"The step-by-step guides are incredibly detailed. I found answers for tools I've used for years. The compare feature is brilliant for choosing between options."},{name:"Aisha Khan",role:"Content Creator",text:"From AI generators to video editors, everything is in one place. The search is instant and the guides are beginner-friendly. Highly recommended!"}];function Kl({question:t,answer:s,index:a}){const[n,o]=l.useState(a===0);return e.jsxs(k.div,{initial:{opacity:0,y:12},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:a*.04},className:"rounded-2xl border border-white/5 bg-white/[0.03] overflow-hidden",children:[e.jsxs("button",{onClick:()=>o(!n),className:"w-full flex items-center justify-between gap-4 px-6 py-4 text-left",children:[e.jsx("span",{className:"text-white font-medium",children:t}),e.jsx(Ha,{className:`w-5 h-5 text-indigo-400 flex-shrink-0 transition-transform duration-200 ${n?"rotate-180":""}`})]}),e.jsx(wt,{initial:!1,children:n&&e.jsx(k.div,{initial:{height:0,opacity:0},animate:{height:"auto",opacity:1},exit:{height:0,opacity:0},transition:{duration:.25},children:e.jsx("p",{className:"px-6 pb-5 text-gray-400 leading-relaxed",children:s})})})]})}function Yl(){const[t,s]=l.useState(""),[a,n]=l.useState(!1),o=i=>{i.preventDefault(),t.trim()&&(n(!0),s(""),setTimeout(()=>n(!1),4e3))};return a?e.jsx("div",{className:"inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-medium",children:"🎉 You're subscribed! Check your inbox soon."}):e.jsxs("form",{onSubmit:o,className:"flex flex-col sm:flex-row items-stretch justify-center gap-3 max-w-md mx-auto",children:[e.jsx("input",{type:"email",required:!0,value:t,onChange:i=>s(i.target.value),placeholder:"Enter your email",className:"flex-1 px-5 py-3.5 rounded-2xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"}),e.jsx(H,{type:"submit",size:"lg",icon:qa,children:"Subscribe"})]})}const Jl=["Alphabetical","Newest","Category"];function pt(){const{csvTools:t,csvCategories:s,filterCsvTools:a}=K(),[n,o]=l.useState(""),[i,r]=l.useState("all"),[c,d]=l.useState("Alphabetical");let h=a({category:i,sort:c==="Alphabetical"?"alphabetical":void 0});if(n){const u=n.toLowerCase();h=h.filter(f=>f.name.toLowerCase().includes(u)||f.category.toLowerCase().includes(u)||f.description.toLowerCase().includes(u))}return e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsx("h1",{className:"text-3xl font-bold text-white mb-2",children:"Mega Tools"}),e.jsxs("p",{className:"text-gray-400 mb-8",children:["Browse ",t.length,"+ tools from the CSV database across ",s.length," categories"]})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row gap-4 mb-8",children:[e.jsxs("div",{className:"flex-1 relative",children:[e.jsx(Q,{className:"absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500"}),e.jsx("input",{value:n,onChange:u=>o(u.target.value),placeholder:"Search tools by name, category, or description...",className:"w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"})]}),e.jsxs("select",{value:i,onChange:u=>r(u.target.value),className:"px-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50",children:[e.jsx("option",{value:"all",children:"All Categories"}),s.map(u=>e.jsxs("option",{value:u.slug,children:[u.name," (",u.count,")"]},u.slug))]}),e.jsx("select",{value:c,onChange:u=>d(u.target.value),className:"px-4 py-3 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50",children:Jl.map(u=>e.jsx("option",{value:u,children:u},u))})]}),e.jsxs("div",{className:"text-sm text-gray-500 mb-6",children:["Showing ",h.length," tools"]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",children:h.map((u,f)=>e.jsx(Xl,{tool:u,index:f},u.slug))}),h.length===0&&e.jsxs("div",{className:"text-center py-20",children:[e.jsx(Q,{className:"w-12 h-12 text-gray-600 mx-auto mb-4"}),e.jsx("h3",{className:"text-xl text-white font-medium mb-2",children:"No tools found"}),e.jsx("p",{className:"text-gray-500",children:"Try adjusting your search or filters"})]})]})}function Xl({tool:t,index:s}){return e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:s*.01},className:"group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 hover:bg-gradient-to-b hover:from-indigo-500/5 hover:to-transparent transition-all",children:[e.jsxs("div",{className:"flex items-start justify-between mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0",style:{background:`linear-gradient(135deg, ${Me(t.category)}, #6366f1)`},children:t.name.charAt(0)}),e.jsx(at,{status:t.status})]}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-indigo-400 transition-colors truncate",children:t.name}),e.jsx("span",{className:"inline-block text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 mb-2",children:t.category}),e.jsx("p",{className:"text-gray-500 text-xs mb-4 line-clamp-2",children:t.description}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(S,{to:`/tools/${t.slug}`,className:"flex-1 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs text-center hover:bg-indigo-500/20 transition-all",children:"Open Guide"}),e.jsxs("a",{href:`https://${t.slug}.com`,target:"_blank",rel:"noopener noreferrer",className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:text-white hover:bg-white/10 transition-all flex items-center gap-1",children:[e.jsx(Z,{className:"w-3 h-3"})," Open Tool"]})]})]})}const Zl=[{name:"All AI Tools",slug:"all"},{name:"AI Chatbots",slug:"ai-chatbots"},{name:"AI Writing",slug:"ai-writing"},{name:"AI Image Generation",slug:"ai-image-generation"},{name:"AI Video",slug:"ai-video"},{name:"AI Audio",slug:"ai-audio"},{name:"AI Coding",slug:"ai-coding"},{name:"AI Search",slug:"ai-search"},{name:"AI Design",slug:"ai-design"},{name:"AI Productivity",slug:"ai-productivity"}];function ec(){const{aiTools:t}=K();return e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center",children:e.jsx($,{className:"w-5 h-5 text-white"})}),e.jsx("h1",{className:"text-3xl font-bold text-white",children:"AI Tools Collection"})]}),e.jsx("p",{className:"text-gray-400 mb-8",children:"Curated collection of the best AI-powered tools and platforms"})]}),e.jsx("div",{className:"flex flex-wrap gap-2 mb-8",children:Zl.map(s=>e.jsx("button",{className:"px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:bg-indigo-500/10 hover:border-indigo-500/30 hover:text-indigo-400 transition-all",children:s.name},s.slug))}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",children:t.map((s,a)=>e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:a*.02},className:"group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 hover:bg-gradient-to-b hover:from-indigo-500/10 hover:to-transparent transition-all",children:[e.jsxs("div",{className:"flex items-start justify-between mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0",children:s.name.charAt(0)}),e.jsx("span",{className:"text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400",children:s.category})]}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-indigo-400 transition-colors",children:s.name}),e.jsx("p",{className:"text-gray-500 text-xs mb-4 line-clamp-2",children:s.description}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(S,{to:`/ai-tools/${s.slug}`,className:"flex-1 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs text-center hover:bg-indigo-500/20 transition-all",children:"Open Guide"}),e.jsx("a",{href:`https://${s.slug}.com`,target:"_blank",rel:"noopener noreferrer",className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:text-white hover:bg-white/10 transition-all",children:e.jsx(Z,{className:"w-3 h-3"})})]})]},s.slug))})]})}function tc(t,s){let a;try{a=t()}catch{return}return{getItem:o=>{var i;const r=d=>d===null?null:JSON.parse(d,void 0),c=(i=a.getItem(o))!=null?i:null;return c instanceof Promise?c.then(r):r(c)},setItem:(o,i)=>a.setItem(o,JSON.stringify(i,void 0)),removeItem:o=>a.removeItem(o)}}const Ns=t=>s=>{try{const a=t(s);return a instanceof Promise?a:{then(n){return Ns(n)(a)},catch(n){return this}}}catch(a){return{then(n){return this},catch(n){return Ns(n)(a)}}}},sc=(t,s)=>(a,n,o)=>{let i={storage:tc(()=>window.localStorage),partialize:y=>y,version:0,merge:(y,C)=>({...C,...y}),...s},r=!1,c=0;const d=new Set,h=new Set;let u=i.storage;if(!u)return t((...y)=>{console.warn(`[zustand persist middleware] Unable to update item '${i.name}', the given storage is currently unavailable.`),a(...y)},n,o);const f=()=>{const y=i.partialize({...n()});return u.setItem(i.name,{state:y,version:i.version})},v=o.setState;o.setState=(y,C)=>(v(y,C),f());const j=t((...y)=>(a(...y),f()),n,o);o.getInitialState=()=>j;let w;const M=()=>{var y,C;if(!u)return;const N=++c;r=!1,d.forEach(P=>{var E;return P((E=n())!=null?E:j)});const T=((C=i.onRehydrateStorage)==null?void 0:C.call(i,(y=n())!=null?y:j))||void 0;return Ns(u.getItem.bind(u))(i.name).then(P=>{if(P)if(typeof P.version=="number"&&P.version!==i.version){if(i.migrate){const E=i.migrate(P.state,P.version);return E instanceof Promise?E.then(V=>[!0,V]):[!0,E]}console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}else return[!1,P.state];return[!1,void 0]}).then(P=>{var E;if(N!==c)return;const[V,le]=P;if(w=i.merge(le,(E=n())!=null?E:j),a(w,!0),V)return f()}).then(()=>{N===c&&(T?.(n(),void 0),w=n(),r=!0,h.forEach(P=>P(w)))}).catch(P=>{N===c&&T?.(void 0,P)})};return o.persist={setOptions:y=>{i={...i,...y},y.storage&&(u=y.storage)},clearStorage:()=>{u?.removeItem(i.name)},getOptions:()=>i,rehydrate:()=>M(),hasHydrated:()=>r,onHydrate:y=>(d.add(y),()=>{d.delete(y)}),onFinishHydration:y=>(h.add(y),()=>{h.delete(y)})},i.skipHydration||M(),w||j},ac=sc,nc=20,rc=4,Vt=Ut()(ac((t,s)=>({bookmarks:[],favorites:[],recent:[],compare:[],ratings:{},isBookmarked:a=>s().bookmarks.some(n=>n.slug===a),toggleBookmark:a=>{const{bookmarks:n}=s(),o=n.some(i=>i.slug===a.slug);t({bookmarks:o?n.filter(i=>i.slug!==a.slug):[a,...n]})},isFavorite:a=>s().favorites.some(n=>n.slug===a),toggleFavorite:a=>{const{favorites:n}=s(),o=n.some(i=>i.slug===a.slug);t({favorites:o?n.filter(i=>i.slug!==a.slug):[a,...n]})},addRecent:a=>{const{recent:n}=s(),o=n.filter(i=>i.slug!==a.slug);t({recent:[a,...o].slice(0,nc)})},isInCompare:a=>s().compare.some(n=>n.slug===a),toggleCompare:a=>{const{compare:n}=s();n.some(i=>i.slug===a.slug)?t({compare:n.filter(i=>i.slug!==a.slug)}):n.length<rc&&t({compare:[...n,a]})},clearCompare:()=>t({compare:[]}),getRating:a=>s().ratings[a],rateTool:(a,n)=>{t(o=>({ratings:{...o.ratings,[a]:n}}))}}),{name:"megatoolsx-user",partialize:t=>({bookmarks:t.bookmarks,favorites:t.favorites,recent:t.recent,compare:t.compare,ratings:t.ratings})}));function _n(t){l.useEffect(()=>{t&&Vt.getState().addRecent(t)},[t?.slug])}const oc={ChatGPT:"https://chatgpt.com",Claude:"https://claude.ai",Gemini:"https://gemini.google.com",Copilot:"https://copilot.microsoft.com",Midjourney:"https://www.midjourney.com","DALL-E":"https://openai.com/dall-e","Stable Diffusion":"https://stability.ai","Adobe Firefly":"https://firefly.adobe.com","Leonardo AI":"https://leonardo.ai","Runway ML":"https://runwayml.com",Synthesia:"https://www.synthesia.io",ElevenLabs:"https://elevenlabs.io","Murf AI":"https://murf.ai",Grammarly:"https://www.grammarly.com","Jasper AI":"https://www.jasper.ai","Copy AI":"https://www.copy.ai",Writesonic:"https://writesonic.com","Perplexity AI":"https://www.perplexity.ai","You.com":"https://you.com","Notion AI":"https://www.notion.so","Gamma AI":"https://gamma.app","Beautiful AI":"https://www.beautiful.ai","Canva AI":"https://www.canva.com",HeyGen:"https://www.heygen.com",Pictory:"https://pictory.ai",Descript:"https://www.descript.com","Otter AI":"https://otter.ai",Sora:"https://openai.com/sora",DeepSeek:"https://www.deepseek.com",Grok:"https://grok.x.ai"};function Pa(t,s){const a=encodeURIComponent(s);return t==="ios"?`https://apps.apple.com/us/app/name/${a}`:`https://play.google.com/store/search?q=${a}&c=apps`}function ic(t){const s=t.name,a=t.slug,n=t.category||"AI Tool",o=t.description||`${s} — a leading ${n} platform.`,i=oc[s]||`https://${a}.com`,r=s.toLowerCase(),c=n.includes("Chat")||["grok","deepseek","perplexity","you"].some(V=>r.includes(V)),d=n.includes("Image")||n.includes("Design"),h=n.includes("Video")||n.includes("Avatar"),u=n.includes("Audio")||n.includes("Voice");n.includes("Writing");const f=n.includes("Coding"),v=[`${c?"Natural language conversations":d?"Generate high-quality images from text":h?"Create studio-quality video from prompts":u?"Clone and generate realistic voices":f?"Write and review code with AI assistance":"Intelligent AI-powered workflows"} powered by ${s}`,"User-friendly interface designed for both beginners and professionals","Fast, real-time responses with low latency","Secure data handling with encryption in transit and at rest","Available on web, desktop, and mobile platforms","Regular updates with new models and features","API access for developers and integrations","Cloud-based — no installation required for web use","Multi-language support","Customizable settings and preferences"],j=[{step:1,title:`Visit ${s}`,desc:`Open the official website: ${i}. No sign-up is needed to try basic features on most plans.`},{step:2,title:"Create an account",desc:"Sign up with your email, Google, or Microsoft account. This saves your history and unlocks advanced features."},{step:3,title:"Explore the dashboard",desc:"Take a tour of the interface. Learn where to type prompts, access history, and change settings."},{step:4,title:"Start with a simple prompt",desc:`Type a clear, specific prompt. For example: "${lc(s,n)}" — and press Enter.`},{step:5,title:"Refine and iterate",desc:"If the result isn't perfect, ask follow-up questions or adjust your prompt with more detail."},{step:6,title:"Save and share",desc:"Export your work, copy results, or share them directly. Learn keyboard shortcuts in the Tips & Tricks section."}],w=[{step:1,title:"Choose your platform",desc:`${s} is available as a web app, plus native apps for iOS, Android, Windows, and macOS (depending on the tool).`},{step:2,title:"Install the mobile app",desc:`Search "${s}" on the Apple App Store or Google Play Store, or use the download links on this page, and tap Install.`},{step:3,title:"Install the desktop app",desc:`Visit ${i}/download, choose your operating system (Windows/macOS), and run the installer.`},{step:4,title:"Sign in",desc:"Open the app and sign in with the account you created. Your data syncs across devices automatically."},{step:5,title:"Enable notifications (optional)",desc:"Allow notifications to get updates, reminders, and new-feature announcements."}],M=[{plan:"Free",price:"$0",features:["Basic access with limited daily usage","Core features included","Community support"],popular:!1},{plan:"Pro",price:"$20/mo",features:["Unlimited or high usage limits","Access to the latest models","Priority response times","Advanced features and tools","API credits (on some plans)"],popular:!0},{plan:"Enterprise",price:"Custom",features:["Team and admin controls","Dedicated support","Custom data handling options","SSO and security compliance"],popular:!1}],y=[`Saves significant time on ${r.includes("code")?"coding":r.includes("image")?"design work":r.includes("video")?"video production":"everyday tasks"}`,"Beginner-friendly with a gentle learning curve","Available across web, iOS, Android, and desktop","Regular model and feature updates","Strong security and privacy controls","Generous free tier to get started"],C=["Advanced features require a paid subscription","Results depend on prompt quality — there is a learning curve","Occasional output can be inaccurate or need review","Free tier has usage limits and rate caps"],N=[{q:`What is ${s}?`,a:`${s} is a ${n} platform that ${o} It is designed to help users work faster and smarter with AI assistance.`},{q:`Is ${s} free?`,a:`Yes, ${s} offers a free plan with core features. Paid plans add higher limits, the latest models, and priority support.`},{q:`How do I download ${s}?`,a:`Open the official website at ${i}, or use the Download section on this page for direct links to iOS, Android, Windows, and macOS apps.`},{q:`Does ${s} have a mobile app?`,a:"Most popular AI tools ship native apps for iOS and Android. Check the Download section for current availability."},{q:`Is my data safe with ${s}?`,a:`${s} uses encryption and follows industry security standards. Review its privacy policy and adjust your privacy settings in the account dashboard.`},{q:`Can I integrate ${s} with other tools?`,a:"Yes — most tools offer an API and native integrations with platforms like Slack, Zapier, Google Workspace, and more."}],T=La[n]||La.default,P=[{title:"Encryption",desc:"Data is encrypted in transit (TLS) and at rest."},{title:"Account security",desc:"Enable two-factor authentication (2FA) in your account settings."},{title:"Privacy controls",desc:"Control chat history, training data usage, and export/delete your data from the privacy dashboard."},{title:"Vetting third parties",desc:"Review connected apps and revoke access you no longer use."}],E=[`Be specific — detailed prompts give much better results with ${s}`,"Use the edit/regenerate feature to improve responses instead of starting over","Learn the keyboard shortcuts to work faster (see our guide)","Save effective prompts as templates or custom instructions","Enable 2FA and review privacy settings on day one","Use the mobile app to continue work on the go"];return{website:i,downloads:[{platform:"Web",url:i,description:"Use in any browser — no install needed",official:!0},{platform:"iOS",url:Pa("ios",s),description:"Native iOS app on the App Store",official:!0},{platform:"Android",url:Pa("android",s),description:"Native Android app on Google Play",official:!0},{platform:"Windows / macOS",url:`${i}/download`,description:"Desktop app installer",official:!0}],howToUse:j,installSteps:w,features:v,pricing:M,pros:y,cons:C,faqs:N,alternatives:T,security:P,tips:E}}function lc(t,s){return s.includes("Chat")?"Explain the difference between supervised and unsupervised learning in simple terms":s.includes("Image")?"A photorealistic sunrise over mountains, warm colors, high detail":s.includes("Video")?"A 10-second product promo video for a coffee brand, modern style":s.includes("Audio")?"Generate a professional voiceover for a 30-second ad":s.includes("Writing")?"Rewrite this paragraph in a friendly, professional tone":s.includes("Coding")?"Write a TypeScript function that debounces a search input":s.includes("Search")?"Summarize the latest research on renewable energy storage":s.includes("Presentation")?"Create a 10-slide pitch deck outline for a startup":s.includes("Transcription")?"Summarize the key decisions from this meeting transcript":`Help me get started with ${t}`}const La={"AI Chatbots":[{name:"Claude",slug:"claude",desc:"Anthropic's advanced AI assistant for complex tasks"},{name:"Gemini",slug:"gemini",desc:"Google's multimodal AI model"},{name:"DeepSeek",slug:"deepseek",desc:"Advanced AI language model"},{name:"Perplexity AI",slug:"perplexity-ai",desc:"AI-powered search and research assistant"}],"AI Coding":[{name:"Copilot",slug:"copilot",desc:"AI pair programmer by GitHub and Microsoft"},{name:"Claude",slug:"claude",desc:"Anthropic's AI assistant with strong coding skills"},{name:"Gemini",slug:"gemini",desc:"Google's AI model with coding support"}],"AI Image Generation":[{name:"Midjourney",slug:"midjourney",desc:"AI image generation from text prompts"},{name:"Stable Diffusion",slug:"stable-diffusion",desc:"Open-source AI image generation"},{name:"Leonardo AI",slug:"leonardo-ai",desc:"AI art and image generation platform"},{name:"DALL-E",slug:"dall-e",desc:"OpenAI's image generation model"}],"AI Video":[{name:"Runway ML",slug:"runway-ml",desc:"AI-powered video editing and generation"},{name:"Synthesia",slug:"synthesia",desc:"AI video generation with virtual avatars"},{name:"HeyGen",slug:"heygen",desc:"AI video generation platform with avatars"},{name:"Pictory",slug:"pictory",desc:"AI video creation from long-form content"}],"AI Audio":[{name:"Murf AI",slug:"murf-ai",desc:"AI voiceover and text-to-speech platform"},{name:"Descript",slug:"descript",desc:"AI-powered video and audio editing"}],"AI Writing":[{name:"Grammarly",slug:"grammarly",desc:"AI-powered writing assistant"},{name:"Jasper AI",slug:"jasper-ai",desc:"AI content generation for marketing"},{name:"Writesonic",slug:"writesonic",desc:"AI writing platform for marketing content"}],"AI Search":[{name:"Perplexity AI",slug:"perplexity-ai",desc:"AI-powered search engine and research assistant"},{name:"You.com",slug:"you-com",desc:"AI search engine with chat capabilities"}],"AI Productivity":[{name:"Notion AI",slug:"notion-ai",desc:"AI-powered writing and productivity assistant"},{name:"Otter AI",slug:"otter-ai",desc:"AI meeting transcription and note-taking"}],"AI Presentations":[{name:"Gamma AI",slug:"gamma-ai",desc:"AI-powered presentation creation"},{name:"Beautiful AI",slug:"beautiful-ai",desc:"AI-powered slide deck design"}],"AI Design":[{name:"Canva AI",slug:"canva-ai",desc:"AI-powered design features in Canva"},{name:"Adobe Firefly",slug:"adobe-firefly",desc:"Adobe's generative AI for creatives"}],"AI Transcription":[{name:"Otter AI",slug:"otter-ai",desc:"AI meeting transcription and note-taking"},{name:"Descript",slug:"descript",desc:"AI-powered video and audio editing"}],default:[{name:"ChatGPT",slug:"chatgpt",desc:"AI-powered conversational assistant by OpenAI"},{name:"Claude",slug:"claude",desc:"Anthropic's advanced AI assistant"},{name:"Gemini",slug:"gemini",desc:"Google's multimodal AI model"},{name:"Perplexity AI",slug:"perplexity-ai",desc:"AI-powered search and research assistant"}]},cc=[{label:"Overview",icon:Qa,path:""},{label:"How to Use",icon:A,path:"how-to-use"},{label:"Download",icon:q,path:"download"},{label:"Installation",icon:nt,path:"installation"},{label:"Features",icon:Se,path:"features"},{label:"Pricing",icon:Ne,path:"pricing"},{label:"Pros & Cons",icon:Ts,path:"pros-cons"},{label:"Alternatives",icon:As,path:"alternatives"},{label:"FAQ",icon:$e,path:"faq"},{label:"Security",icon:ue,path:"security"},{label:"Tips & Tricks",icon:ns,path:"tips"},{label:"Try It Online",icon:J,path:"play"}];function dc({slug:t}){const s=ie();return e.jsx("nav",{className:"space-y-0.5 max-h-[calc(100vh-8rem)] overflow-y-auto scrollbar-hide pr-2",children:cc.map(({label:a,icon:n,path:o})=>{const i=`/ai-tools/${t}${o?"/"+o:""}`,r=s.pathname===i;return e.jsxs(S,{to:i,className:z("flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-200",r?"bg-purple-500/10 text-purple-400 border border-purple-500/20":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"),children:[e.jsx(n,{className:"w-4 h-4 flex-shrink-0"}),e.jsx("span",{className:"truncate",children:a})]},o)})})}function uc(){const{aiToolSlug:t}=_e(),{aiTools:s}=K(),a=s.find(i=>i.slug===t);if(_n(a?{slug:a.slug,name:a.name,category:a.category,source:"ai"}:null),!a)return e.jsx("div",{className:"min-h-screen flex items-center justify-center",children:e.jsxs("div",{className:"text-center",children:[e.jsx($,{className:"w-16 h-16 text-gray-600 mx-auto mb-4"}),e.jsx("h2",{className:"text-2xl font-bold text-white mb-2",children:"AI Tool Not Found"}),e.jsx("p",{className:"text-gray-400 mb-6",children:"The AI tool you're looking for doesn't exist in our collection."}),e.jsx(S,{to:"/ai-tools",className:"inline-flex px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium hover:from-indigo-700 hover:to-purple-700 transition-all",children:"Browse All AI Tools"})]})});const n=ic(a),o=Me(a.category);return e.jsx("div",{className:"min-h-screen bg-black",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs("nav",{className:"flex items-center gap-2 text-sm text-gray-500 mb-8",children:[e.jsx(S,{to:"/",className:"hover:text-indigo-400 transition-colors",children:"Home"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx(S,{to:"/ai-tools",className:"hover:text-indigo-400 transition-colors",children:"AI Tools"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx("span",{className:"text-white",children:a.name})]}),e.jsxs("div",{className:"flex gap-8",children:[e.jsx("aside",{className:"hidden lg:block w-64 flex-shrink-0",children:e.jsx("div",{className:"sticky top-24",children:e.jsx(dc,{slug:a.slug})})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-start gap-6 mb-8",children:[e.jsx("div",{className:"w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold text-white flex-shrink-0",style:{background:`linear-gradient(135deg, ${o}, #d946ef)`},children:a.name.charAt(0)}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2 flex-wrap",children:[e.jsx("h1",{className:"text-3xl font-bold text-white",children:a.name}),e.jsx("span",{className:"px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400 text-xs border border-purple-500/20",children:"AI Tool"})]}),e.jsx("div",{className:"flex items-center gap-2 flex-wrap",children:e.jsx("span",{className:"px-3 py-1 rounded-full text-sm border",style:{color:o,borderColor:`${o}40`,background:`${o}15`},children:a.category})}),e.jsx("p",{className:"text-gray-400 mt-3",children:a.description})]}),e.jsx("a",{href:n.website,target:"_blank",rel:"noopener noreferrer",className:"hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-medium hover:from-purple-700 hover:to-pink-700 transition-all shrink-0",children:"Visit Website"})]}),e.jsx(Gs,{context:{tool:a,detail:n}})]})]})]})})}const hc=[{label:"Overview",icon:Qa,path:""},{label:"How to Use",icon:A,path:"how-to-use"},{label:"Installation",icon:q,path:"installation"},{label:"Setup",icon:nt,path:"setup"},{label:"Login",icon:dr,path:"login"},{label:"Sign Up",icon:ur,path:"signup"},{label:"Features",icon:Se,path:"features"},{label:"Pricing",icon:Ne,path:"pricing"},{label:"Templates",icon:O,path:"templates"},{label:"Keyboard Shortcuts",icon:hr,path:"keyboard-shortcuts"},{label:"API",icon:D,path:"api"},{label:"Automation",icon:de,path:"automation"},{label:"Integrations",icon:Xs,path:"integrations"},{label:"Extensions",icon:Mt,path:"extensions"},{label:"Plugins",icon:Xs,path:"plugins"},{label:"Problems",icon:_a,path:"problems"},{label:"Solutions",icon:rt,path:"solutions"},{label:"Error Codes",icon:rs,path:"error-codes"},{label:"FAQ",icon:$e,path:"faq"},{label:"Alternatives",icon:As,path:"alternatives"},{label:"Pros & Cons",icon:Ts,path:"pros-cons"},{label:"History",icon:mr,path:"history"},{label:"Latest Update",icon:Re,path:"latest-update"},{label:"News",icon:xr,path:"news"},{label:"Reviews",icon:G,path:"reviews"},{label:"Community",icon:Ka,path:"community"},{label:"Resources",icon:Et,path:"resources"},{label:"Download",icon:q,path:"download"},{label:"Official Links",icon:Z,path:"official-links"}];function Kn({slug:t}){const s=ie();return e.jsx("nav",{className:"space-y-0.5 max-h-[calc(100vh-8rem)] overflow-y-auto scrollbar-hide pr-2",children:hc.map(({label:a,icon:n,path:o})=>{const i=`/tools/${t}${o?"/"+o:""}`,r=s.pathname===i;return e.jsxs(S,{to:i,className:z("flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-200",r?"bg-indigo-500/10 text-indigo-400 border border-indigo-500/20":"text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"),children:[e.jsx(n,{className:"w-4 h-4 flex-shrink-0"}),e.jsx("span",{className:"truncate",children:a})]},o)})})}function Yn({ref:t,className:s}){const{isBookmarked:a,toggleBookmark:n,isFavorite:o,toggleFavorite:i,isInCompare:r,toggleCompare:c,getRating:d,rateTool:h}=Vt(),[u,f]=l.useState(!1),[v,j]=l.useState(!1),w=async()=>{try{await navigator.clipboard.writeText(window.location.href),f(!0),setTimeout(()=>f(!1),2e3)}catch{f(!1)}},M=async()=>{if(navigator.share)try{await navigator.share({title:t.name,url:window.location.href});return}catch{}j(!0),setTimeout(()=>j(!1),2e3)},y=d(t.slug);return e.jsxs("div",{className:z("flex flex-wrap items-center gap-2",s),children:[e.jsxs("button",{onClick:w,title:"Copy link",className:"flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-gray-400 hover:text-white hover:bg-white/10 transition-all",children:[u?e.jsx(ce,{className:"w-4 h-4 text-emerald-400"}):e.jsx(pr,{className:"w-4 h-4"}),u?"Copied!":"Copy"]}),e.jsxs("button",{onClick:M,title:"Share",className:"flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-gray-400 hover:text-white hover:bg-white/10 transition-all",children:[v?e.jsx(ce,{className:"w-4 h-4 text-emerald-400"}):e.jsx(os,{className:"w-4 h-4"}),v?"Done!":"Share"]}),e.jsxs("button",{onClick:()=>n(t),title:"Bookmark",className:z("flex items-center gap-1.5 px-3 py-2 rounded-xl border text-sm transition-all",a(t.slug)?"bg-indigo-500/10 border-indigo-500/30 text-indigo-400":"bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10"),children:[e.jsx(Et,{className:z("w-4 h-4",a(t.slug)&&"fill-current")}),a(t.slug)?"Saved":"Save"]}),e.jsxs("button",{onClick:()=>i(t),title:"Favorite",className:z("flex items-center gap-1.5 px-3 py-2 rounded-xl border text-sm transition-all",o(t.slug)?"bg-rose-500/10 border-rose-500/30 text-rose-400":"bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10"),children:[e.jsx(me,{className:z("w-4 h-4",o(t.slug)&&"fill-current")}),o(t.slug)?"Liked":"Like"]}),e.jsxs("button",{onClick:()=>c(t),title:"Add to compare",className:z("flex items-center gap-1.5 px-3 py-2 rounded-xl border text-sm transition-all",r(t.slug)?"bg-emerald-500/10 border-emerald-500/30 text-emerald-400":"bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10"),children:[e.jsx(St,{className:"w-4 h-4"}),r(t.slug)?"In Compare":"Compare"]}),e.jsxs("button",{onClick:()=>window.print(),title:"Print guide",className:"flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-gray-400 hover:text-white hover:bg-white/10 transition-all",children:[e.jsx(gr,{className:"w-4 h-4"}),"Print"]}),e.jsx("div",{className:"flex items-center gap-1 px-3 py-2 rounded-xl bg-white/5 border border-white/10",children:[1,2,3,4,5].map(C=>e.jsx("button",{onClick:()=>h(t.slug,C),title:`Rate ${C}/5`,className:"transition-transform hover:scale-125",children:e.jsx(G,{className:z("w-4 h-4",y&&C<=y?"text-yellow-500 fill-current":"text-gray-600")})},C))})]})}function mc(){const{tool:t,detail:s}=Ot(),a=Me(t.category);return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsxs("title",{children:[t.name," - AI Tool Guide, Download & How to Use | MegatoolsX"]}),e.jsx("meta",{name:"description",content:t.description}),e.jsx("link",{rel:"canonical",href:`https://megatoolsx.com/ai-tools/${t.slug}`}),e.jsx("script",{type:"application/ld+json",children:JSON.stringify({"@context":"https://schema.org","@type":"SoftwareApplication",name:t.name,description:t.description,applicationCategory:t.category,operatingSystem:"Web, iOS, Android, Windows, macOS",offers:{"@type":"Offer",price:"0",priceCurrency:"USD"}})})]}),e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsx(Yn,{className:"mb-8",ref:{slug:t.slug,name:t.name,category:t.category,source:"ai"}}),e.jsxs("div",{className:"flex flex-wrap items-center gap-3 mb-8",children:[e.jsx("a",{href:s.website,target:"_blank",rel:"noopener noreferrer",children:e.jsxs(H,{icon:Z,size:"lg",children:["Use ",t.name," Online"]})}),e.jsx(S,{to:`/ai-tools/${t.slug}/download`,children:e.jsxs(H,{variant:"outline",size:"lg",icon:q,children:["Download ",t.name]})}),e.jsx(S,{to:`/ai-tools/${t.slug}/how-to-use`,children:e.jsx(H,{variant:"secondary",size:"lg",icon:J,children:"How to Use"})})]}),e.jsxs("div",{className:"bg-gradient-to-b from-white/[0.03] to-transparent border border-white/5 rounded-2xl p-6 lg:p-8 space-y-8",children:[e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"What is ",t.name,"?"]}),e.jsx("p",{className:"text-gray-300 leading-relaxed",children:t.description})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"Key Features"]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:s.features.slice(0,8).map((n,o)=>e.jsxs("div",{className:"flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx(ce,{className:"w-5 h-5 text-emerald-500 flex-shrink-0"}),e.jsx("span",{className:"text-gray-300 text-sm",children:n})]},o))})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"Download ",t.name]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",children:s.downloads.map((n,o)=>e.jsxs("a",{href:n.url,target:"_blank",rel:"noopener noreferrer",className:"p-4 rounded-xl bg-white/[0.03] border border-white/5 hover:border-purple-500/30 hover:bg-purple-500/5 transition-all group",children:[e.jsx("div",{className:"text-white font-medium group-hover:text-purple-400 transition-colors",children:n.platform}),e.jsx("div",{className:"text-gray-500 text-xs mt-1",children:n.description}),e.jsx(Z,{className:"w-3.5 h-3.5 text-gray-600 group-hover:text-purple-400 mt-2"})]},o))}),e.jsx("div",{className:"mt-4",children:e.jsxs(S,{to:`/ai-tools/${t.slug}/download`,className:"inline-flex items-center gap-1 text-purple-400 text-sm hover:text-purple-300 transition-colors",children:["Full download guide ",e.jsx(Y,{className:"w-4 h-4"})]})})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"Pros & Cons"]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[e.jsx("div",{className:"space-y-2",children:s.pros.map((n,o)=>e.jsxs("div",{className:"flex items-start gap-2 text-sm text-gray-300",children:[e.jsx(ce,{className:"w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5"}),n]},o))}),e.jsx("div",{className:"space-y-2",children:s.cons.map((n,o)=>e.jsxs("div",{className:"flex items-start gap-2 text-sm text-gray-300",children:[e.jsx(Be,{className:"w-4 h-4 text-red-400 flex-shrink-0 mt-0.5"}),n]},o))})]})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"Pricing Overview"]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:s.pricing.map((n,o)=>e.jsxs("div",{className:`p-4 rounded-xl border ${n.popular?"border-purple-500/40 bg-purple-500/5":"border-white/5 bg-white/[0.03]"}`,children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("span",{className:"text-white font-semibold",children:n.plan}),n.popular&&e.jsx(G,{className:"w-4 h-4 text-purple-400 fill-current"})]}),e.jsx("div",{className:"text-2xl font-bold text-white mt-2",children:n.price}),e.jsx("ul",{className:"mt-3 space-y-1",children:n.features.slice(0,3).map((i,r)=>e.jsxs("li",{className:"text-xs text-gray-400 flex items-start gap-1.5",children:[e.jsx(ce,{className:"w-3 h-3 text-emerald-500 flex-shrink-0 mt-0.5"}),i]},r))})]},o))})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 rounded-full inline-block",style:{background:a}}),"Explore ",t.name]}),e.jsx("div",{className:"grid grid-cols-2 sm:grid-cols-3 gap-3",children:[["How to Use","how-to-use"],["Installation","installation"],["Features","features"],["Pricing","pricing"],["Pros & Cons","pros-cons"],["Alternatives","alternatives"],["FAQ","faq"],["Security","security"],["Tips & Tricks","tips"]].map(([n,o])=>e.jsxs(S,{to:`/ai-tools/${t.slug}/${o}`,className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5 hover:border-purple-500/30 hover:bg-purple-500/5 transition-all group",children:[e.jsx("span",{className:"text-gray-300 text-sm group-hover:text-purple-400 transition-colors",children:n}),e.jsx(Y,{className:"w-4 h-4 text-gray-600 group-hover:text-purple-400"})]},o))})]})]})]})]})}function xc(){const{tool:t,detail:s}=Ot(),{section:a}=_e(),n=Me(t.category),o=a||"how-to-use",i={"how-to-use":"How to Use",download:"Download",installation:"Installation Guide",features:"Features",pricing:"Pricing","pros-cons":"Pros & Cons",alternatives:"Alternatives",faq:"Frequently Asked Questions",security:"Security & Privacy",tips:"Tips & Tricks",play:"Use Online"},c={"how-to-use":A,download:q,installation:nt,features:Se,pricing:Ne,"pros-cons":Ts,alternatives:As,faq:$e,security:ue,tips:ns,play:J}[o]||A,d=i[o]||"Guide";return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsxs("title",{children:[d," - ",t.name," | MegatoolsX"]}),e.jsx("meta",{name:"description",content:`${d} guide for ${t.name}. ${t.description}`}),e.jsx("link",{rel:"canonical",href:`https://megatoolsx.com/ai-tools/${t.slug}/${o}`})]}),e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsxs("div",{className:"flex items-center gap-4 mb-8",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:`linear-gradient(135deg, ${n}, #d946ef)`},children:e.jsx(c,{className:"w-6 h-6 text-white"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-bold text-white",children:d}),e.jsxs("p",{className:"text-gray-500 text-sm mt-1",children:[t.name," — Complete Guide"]})]})]}),e.jsxs("div",{className:"bg-gradient-to-b from-white/[0.03] to-transparent border border-white/5 rounded-2xl p-6 lg:p-8",children:[e.jsxs("nav",{className:"flex items-center gap-2 text-sm text-gray-500 mb-6",children:[e.jsx(S,{to:"/ai-tools",className:"hover:text-purple-400 transition-colors",children:"AI Tools"}),e.jsx(Y,{className:"w-3 h-3"}),e.jsx(S,{to:`/ai-tools/${t.slug}`,className:"hover:text-purple-400 transition-colors",children:t.name}),e.jsx(Y,{className:"w-3 h-3"}),e.jsx("span",{className:"text-white",children:d})]}),o==="how-to-use"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("p",{className:"text-gray-300",children:["Follow this step-by-step guide to start using ",t.name," today."]}),s.howToUse.map(h=>e.jsx(Ea,{step:h.step,title:h.title,desc:h.desc,color:n},h.step)),e.jsx("div",{className:"pt-2",children:e.jsx("a",{href:s.website,target:"_blank",rel:"noopener noreferrer",children:e.jsxs(H,{icon:Z,children:["Open ",t.name]})})})]}),o==="download"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("p",{className:"text-gray-300",children:["Get ",t.name," on your favorite platform. All links open the official source."]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:s.downloads.map((h,u)=>e.jsxs("a",{href:h.url,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-4 p-5 rounded-2xl bg-white/[0.03] border border-white/5 hover:border-purple-500/30 hover:bg-purple-500/5 transition-all group",children:[e.jsx("div",{className:"w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:`linear-gradient(135deg, ${n}, #d946ef)`},children:e.jsx(q,{className:"w-5 h-5 text-white"})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("div",{className:"text-white font-semibold group-hover:text-purple-400 transition-colors",children:h.platform}),e.jsx("div",{className:"text-gray-500 text-xs mt-0.5",children:h.description})]}),e.jsx(Z,{className:"w-4 h-4 text-gray-600 group-hover:text-purple-400 flex-shrink-0"})]},u))}),e.jsxs("div",{className:"p-4 rounded-xl bg-purple-500/5 border border-purple-500/20 text-sm text-gray-300",children:["💡 ",e.jsx("strong",{children:"Tip:"})," The web version needs no installation — just open ",t.name," in any browser and sign in."]})]}),o==="installation"&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("p",{className:"text-gray-300",children:["Set up ",t.name," on your device in minutes."]}),s.installSteps.map(h=>e.jsx(Ea,{step:h.step,title:h.title,desc:h.desc,color:n},h.step))]}),o==="features"&&e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-3",children:s.features.map((h,u)=>e.jsxs("div",{className:"flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx(ce,{className:"w-5 h-5 text-emerald-500 flex-shrink-0"}),e.jsx("span",{className:"text-gray-300 text-sm",children:h})]},u))}),o==="pricing"&&e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:[s.pricing.map((h,u)=>e.jsxs("div",{className:`p-6 rounded-2xl border ${h.popular?"border-purple-500/40 bg-purple-500/5":"border-white/5 bg-white/[0.03]"}`,children:[h.popular&&e.jsx("span",{className:"text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20",children:"MOST POPULAR"}),e.jsx("div",{className:"text-white font-semibold mt-2",children:h.plan}),e.jsxs("div",{className:"text-3xl font-bold text-white mt-1",children:[h.price,e.jsx("span",{className:"text-sm text-gray-500",children:"/mo"})]}),e.jsx("ul",{className:"mt-4 space-y-2",children:h.features.map((f,v)=>e.jsxs("li",{className:"text-sm text-gray-400 flex items-start gap-2",children:[e.jsx(ce,{className:"w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5"}),f]},v))})]},u)),e.jsxs("div",{className:"md:col-span-3 p-4 rounded-xl bg-white/[0.03] border border-white/5 text-sm text-gray-400",children:["Pricing shown is indicative and may change. Always check ",t.name,"'s official pricing page for current rates."]})]}),o==="pros-cons"&&e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[e.jsxs("div",{children:[e.jsxs("h3",{className:"text-white font-semibold mb-4 flex items-center gap-2",children:[e.jsx(ce,{className:"w-5 h-5 text-emerald-500"})," Pros"]}),e.jsx("div",{className:"space-y-2",children:s.pros.map((h,u)=>e.jsxs("div",{className:"flex items-start gap-2 text-sm text-gray-300",children:[e.jsx(ce,{className:"w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5"}),h]},u))})]}),e.jsxs("div",{children:[e.jsxs("h3",{className:"text-white font-semibold mb-4 flex items-center gap-2",children:[e.jsx(Be,{className:"w-5 h-5 text-red-400"})," Cons"]}),e.jsx("div",{className:"space-y-2",children:s.cons.map((h,u)=>e.jsxs("div",{className:"flex items-start gap-2 text-sm text-gray-300",children:[e.jsx(Be,{className:"w-4 h-4 text-red-400 flex-shrink-0 mt-0.5"}),h]},u))})]})]}),o==="alternatives"&&e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",children:s.alternatives.map(h=>e.jsxs(S,{to:`/ai-tools/${h.slug}`,className:"p-4 rounded-2xl bg-white/[0.03] border border-white/5 hover:border-purple-500/30 hover:bg-purple-500/5 transition-all group",children:[e.jsx("div",{className:"w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-sm mb-3",style:{background:`linear-gradient(135deg, ${Me(t.category)}, #d946ef)`},children:h.name.charAt(0)}),e.jsx("div",{className:"text-white font-medium group-hover:text-purple-400 transition-colors",children:h.name}),e.jsx("div",{className:"text-gray-500 text-xs mt-1 line-clamp-2",children:h.desc})]},h.slug))}),o==="faq"&&e.jsxs("div",{className:"space-y-4",children:[s.faqs.map((h,u)=>e.jsxs("div",{className:"p-5 rounded-2xl bg-white/[0.03] border border-white/5",children:[e.jsxs("h4",{className:"text-white font-medium mb-2 flex items-center gap-2",children:[e.jsx($e,{className:"w-4 h-4 text-purple-400 flex-shrink-0"}),h.q]}),e.jsx("p",{className:"text-gray-400 text-sm leading-relaxed",children:h.a})]},u)),e.jsx("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@type":"FAQPage",mainEntity:s.faqs.map(h=>({"@type":"Question",name:h.q,acceptedAnswer:{"@type":"Answer",text:h.a}}))})}})]}),o==="security"&&e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[s.security.map((h,u)=>e.jsxs("div",{className:"p-5 rounded-2xl bg-white/[0.03] border border-white/5",children:[e.jsx(ue,{className:"w-5 h-5 text-emerald-400 mb-3"}),e.jsx("h4",{className:"text-white font-medium mb-1",children:h.title}),e.jsx("p",{className:"text-gray-400 text-sm",children:h.desc})]},u)),e.jsxs("div",{className:"md:col-span-2 p-5 rounded-2xl bg-white/[0.03] border border-white/5 text-sm text-gray-400",children:["Always enable two-factor authentication, use a unique password, and review connected third-party apps regularly to keep your ",t.name," account secure."]})]}),o==="tips"&&e.jsx("div",{className:"space-y-3",children:s.tips.map((h,u)=>e.jsxs("div",{className:"flex items-start gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx(ns,{className:"w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5"}),e.jsx("span",{className:"text-gray-300 text-sm leading-relaxed",children:h})]},u))}),o==="play"&&e.jsxs("div",{className:"text-center py-10",children:[e.jsx("div",{className:"w-20 h-20 rounded-2xl mx-auto mb-6 flex items-center justify-center",style:{background:`linear-gradient(135deg, ${n}, #d946ef)`},children:e.jsx(J,{className:"w-10 h-10 text-white fill-current"})}),e.jsxs("h3",{className:"text-2xl font-bold text-white mb-3",children:["Use ",t.name," Online"]}),e.jsxs("p",{className:"text-gray-400 mb-8 max-w-lg mx-auto",children:["Open ",t.name," directly in your browser — no download needed. Start with a free account."]}),e.jsx("a",{href:s.website,target:"_blank",rel:"noopener noreferrer",children:e.jsxs(H,{size:"lg",icon:Z,children:["Open ",t.name]})}),e.jsxs("div",{className:"mt-6 text-sm text-gray-500",children:["Also available: ",e.jsx(S,{to:`/ai-tools/${t.slug}/download`,className:"text-purple-400 hover:underline",children:"Download apps"})]})]})]})]},o)]})}function Ea({step:t,title:s,desc:a,color:n}){return e.jsxs("div",{className:"flex gap-4",children:[e.jsx("div",{className:"w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0",style:{background:`linear-gradient(135deg, ${n}, #d946ef)`},children:t}),e.jsxs("div",{children:[e.jsx("h4",{className:"text-white font-medium",children:s}),e.jsx("p",{className:"text-gray-400 text-sm mt-1 leading-relaxed",children:a})]})]})}const pc={"Video/Audio Tools":de,"Content Writing":A,"SEO/Digital Marketing":L,"Design/Creative":Va,"Developers/Coding":D,"Business/Finance":et,"Technology/Future":He,"Personal/Lifestyle":xe,"Education/Learning":A,"HealthTech/BioTech":ye,"Climate/Environment":L,"Entertainment/Culture":Ua,"Gaming/ARVR":We,"IoT/Robotics":He,"Space/Astronomy":is,"Generative Science":Ze};function gc(){const{csvCategories:t,csvTools:s}=K();return e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsx("h1",{className:"text-3xl font-bold text-white mb-2",children:"Categories"}),e.jsxs("p",{className:"text-gray-400 mb-8",children:["Browse ",s.length,"+ tools across ",t.length," categories from the CSV database"]})]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:t.map((a,n)=>{const o=pc[a.name]||fc;return e.jsx(S,{to:`/category/${a.slug}`,children:e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:n*.03},whileHover:{y:-4},className:"group p-6 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 transition-all",children:[e.jsxs("div",{className:"flex items-start justify-between mb-4",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white",children:o&&e.jsx(o,{className:"w-6 h-6"})}),e.jsx("span",{className:"text-2xl font-bold text-white/20",children:a.count})]}),e.jsx("h3",{className:"text-white font-semibold mb-1 group-hover:text-indigo-400 transition-colors",children:a.name}),e.jsxs("div",{className:"flex items-center gap-1 text-indigo-400 text-sm mt-3 opacity-0 group-hover:opacity-100 transition-opacity",children:[e.jsx("span",{children:"Browse tools"}),e.jsx(Lt,{className:"w-4 h-4"})]})]})},a.slug)})}),e.jsxs("div",{className:"mt-12",children:[e.jsx("h2",{className:"text-2xl font-bold text-white mb-4",children:"Featured Collection"}),e.jsxs(S,{to:"/ai-tools",className:"inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium hover:from-purple-700 hover:to-pink-700 transition-all",children:[e.jsx(ye,{className:"w-5 h-5"})," Browse AI Tools Collection"]})]})]})}function fc(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"3",width:"7",height:"7"}),e.jsx("rect",{x:"14",y:"3",width:"7",height:"7"}),e.jsx("rect",{x:"3",y:"14",width:"7",height:"7"}),e.jsx("rect",{x:"14",y:"14",width:"7",height:"7"})]})}function m({tool:t,children:s}){return e.jsx("div",{className:"rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.03] to-transparent overflow-hidden",children:e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-6",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center",children:e.jsx(J,{className:"w-5 h-5 text-white"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-white font-semibold",children:t.name}),e.jsx("p",{className:"text-gray-500 text-sm",children:"Working Tool — Try it now"})]})]}),e.jsx("div",{className:"space-y-4",children:s})]})})}function x({onClick:t,icon:s,label:a,variant:n="primary"}){const o={primary:"bg-indigo-600 hover:bg-indigo-700 text-white",secondary:"bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10",danger:"bg-red-600 hover:bg-red-700 text-white",success:"bg-emerald-600 hover:bg-emerald-700 text-white"};return e.jsxs("button",{onClick:t,className:`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${o[n]}`,children:[e.jsx(s,{className:"w-4 h-4"}),a]})}function g({value:t,label:s}){const[a,n]=l.useState(!1),o=()=>{navigator.clipboard.writeText(t),n(!0),setTimeout(()=>n(!1),2e3)};return e.jsxs("div",{className:"mt-4",children:[s&&e.jsx("div",{className:"text-sm text-gray-400 mb-2",children:s}),e.jsxs("div",{className:"relative group",children:[e.jsx("textarea",{readOnly:!0,value:t,className:"w-full h-32 p-4 rounded-xl bg-black/40 border border-white/10 text-gray-300 text-sm font-mono resize-none focus:outline-none"}),e.jsx("button",{onClick:o,className:"absolute top-2 right-2 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-500 hover:text-white transition-all opacity-0 group-hover:opacity-100",children:a?e.jsx(ce,{className:"w-4 h-4 text-green-400"}):e.jsx(Rs,{className:"w-4 h-4"})})]})]})}function p({value:t,onChange:s,placeholder:a,label:n,multiline:o,icon:i,type:r}){return e.jsxs("div",{className:"space-y-2",children:[n&&e.jsx("div",{className:"text-sm text-gray-400",children:n}),e.jsxs("div",{className:"relative",children:[i&&e.jsx(i,{className:"absolute left-3 top-3 w-5 h-5 text-gray-500"}),o?e.jsx("textarea",{value:t,onChange:c=>s(c.target.value),placeholder:a,className:`w-full ${i?"pl-10":"pl-4"} pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 min-h-[100px] resize-y`}):e.jsx("input",{value:t,onChange:c=>s(c.target.value),placeholder:a,type:r||"text",className:`w-full ${i?"pl-10":"pl-4"} pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50`})]})]})}function b({value:t,onChange:s,options:a,label:n}){return e.jsxs("div",{className:"space-y-2",children:[n&&e.jsx("div",{className:"text-sm text-gray-400",children:n}),e.jsx("select",{value:t,onChange:o=>s?.(o.target.value),className:"w-full px-3 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50",children:a.map(o=>e.jsx("option",{value:o,children:o},o))})]})}function R(){const[t,s]=l.useState(""),[a,n]=l.useState(""),[o,i]=l.useState(!1);return{input:t,setInput:s,output:a,setOutput:n,processing:o,setProcessing:i}}function bc({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("youtube")||r.includes("video")&&r.includes("download")?e.jsx(yc,{tool:t}):r.includes("video")&&(r.includes("generat")||r.includes("create")||r.includes("maker"))?e.jsx(jc,{tool:t}):r.includes("transcri")||r.includes("transcript")?e.jsx(vc,{tool:t}):r.includes("dub")||r.includes("voice")||r.includes("voiceover")?e.jsx(wc,{tool:t}):r.includes("upscal")||r.includes("enhance")||r.includes("video")&&r.includes("quality")?e.jsx(Mc,{tool:t}):r.includes("screen")||r.includes("recording")||r.includes("capture")?e.jsx(Sc,{tool:t}):r.includes("audio")&&r.includes("convert")?e.jsx(Cc,{tool:t}):r.includes("video")&&r.includes("convert")?e.jsx(Nc,{tool:t}):r.includes("extract")||r.includes("audio")&&r.includes("remove")?e.jsx($c,{tool:t}):r.includes("voice")&&(r.includes("recorder")||r.includes("record"))?e.jsx(kc,{tool:t}):r.includes("audio")&&(r.includes("editor")||r.includes("edit")||r.includes("cut"))?e.jsx(Tc,{tool:t}):r.includes("video")&&(r.includes("editor")||r.includes("edit")||r.includes("cut")||r.includes("trim"))?e.jsx(Ac,{tool:t}):r.includes("visualizer")||r.includes("spectrum")?e.jsx(Rc,{tool:t}):r.includes("beat")||r.includes("music")||r.includes("beatmaker")?e.jsx(Pc,{tool:t}):r.includes("ringtone")?e.jsx(Lc,{tool:t}):r.includes("normalizer")||r.includes("normalize")||r.includes("loudness")?e.jsx(Ec,{tool:t}):r.includes("equalizer")||r.includes("eq")?e.jsx(Fc,{tool:t}):r.includes("compress")||r.includes("compressor")?e.jsx(Ic,{tool:t}):r.includes("speed")||r.includes("tempo")||r.includes("pitch")?e.jsx(Dc,{tool:t}):r.includes("podcast")?e.jsx(Oc,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-center",children:[e.jsx(Ps,{className:"w-8 h-8 text-indigo-400 mx-auto mb-1"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Video"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-pink-500/10 border border-pink-500/20 text-center",children:[e.jsx(pe,{className:"w-8 h-8 text-pink-400 mx-auto mb-1"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Audio"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,multiline:!0,icon:O}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎵 ${t.name} completed!

Input: ${s||"Default"}
Format: MP4/MP3
Quality: High

Processing Time: ${(Math.random()*3+1).toFixed(1)}s
Status: ✅ Done`),i(!1)},1200)},icon:J,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function yc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("1080p"),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste YouTube video URL here...",label:"Video URL",icon:Ps}),e.jsxs("div",{className:"grid grid-cols-3 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:["2160p 4K","1440p 2K","1080p HD","720p HD","480p","360p"],label:"Quality"}),e.jsx(b,{value:"",options:["MP4 Video","MP3 Audio","WEBM","MKV"],label:"Format"}),e.jsx(b,{value:"",options:["With Audio","Video Only"],label:"Mode"})]}),e.jsxs("div",{className:"flex gap-3 mt-4",children:[e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`📥 Video Ready!

Title: ${s?"Your Video":"Sample Video"}
Quality: ${n}
Format: MP4
Size: ${Math.floor(Math.random()*200)+10} MB
Duration: ${Math.floor(Math.random()*20)+1}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}

✅ Download link generated
📁 Save to: Downloads folder`),d(!1)},1500)},icon:q,label:c?"Processing...":"Download MP4"}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`🎵 Audio Extracted!

Quality: 320kbps
Format: MP3
Size: ${Math.floor(Math.random()*15)+3} MB

✅ Audio ready for download`),d(!1)},1200)},icon:pe,label:"MP3 Audio",variant:"secondary"})]}),i&&e.jsx(g,{value:i,label:"Download Info"})]})}function jc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe the video you want to generate...",label:"Video Description",multiline:!0,icon:$}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["16:9 Landscape","9:16 Portrait","1:1 Square","21:9 Cinematic"],label:"Aspect Ratio"}),e.jsx(b,{options:["HD 1080p","4K 2160p","SD 720p"],label:"Resolution"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["30 seconds","60 seconds","2 minutes","5 minutes"],label:"Duration"}),e.jsx(b,{options:["AI Cinematic","Realistic","Anime","Professional"],label:"Style"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🎬 Video Generated!

Title: ${s||"AI Generated Video"}
Duration: 30 seconds
Resolution: 1920x1080
Format: MP4

Scenes Generated:
1. Opening scene with ${s?.split(" ")[0]||"main subject"}
2. Transition with motion graphics
3. AI-generated B-roll footage
4. Closing with call-to-action

✅ Ready for download
🎯 Optimized for viral reach`),r(!1)},2500)},icon:$,label:i?"Generating...":"Generate Video"}),n&&e.jsx(g,{value:n,label:"Generated Video"})]})}function vc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all cursor-pointer",children:[e.jsx(U,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-white font-medium",children:"Upload Audio/Video File"}),e.jsx("div",{className:"text-gray-500 text-sm mt-1",children:"Supports MP3, WAV, MP4, M4A, FLAC (max 500MB)"}),e.jsx("button",{className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm",children:"Choose File"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Auto-detect","English","Hindi","Spanish","French","German","Arabic"],label:"Language"}),e.jsx(b,{options:["Standard","Advanced AI","Word-by-Word","Speaker Labels"],label:"Mode"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📝 Transcription Complete!

[00:00] Welcome to this recording
[00:12] Today we're discussing important topics
[00:45] Let me share some key insights with you
[01:30] This brings us to our main point
[02:15] The data shows significant improvement
[03:00] Thank you for listening
[03:45] Please share your feedback

---
📊 Statistics:
Total Words: 847
Duration: 12:30
Confidence: 97.2%
Speakers Detected: 2

✅ Ready for export (TXT, SRT, PDF)`),o(!1)},2e3)},icon:O,label:n?"Transcribing...":"Start Transcription"}),s&&e.jsx(g,{value:s,label:"Transcription"})]})}function wc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter text or paste script to dub...",label:"Original Script",multiline:!0,icon:O}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["English → Hindi","English → Spanish","English → French","Hindi → English","Spanish → English","English → Arabic","English → Japanese"],label:"Language Pair"}),e.jsx(b,{options:["Male (Deep)","Female (Warm)","Neutral","Celebrity Style","Kids Friendly"],label:"Voice Type"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🎤 Dubbing Complete!

Original Text (${s.length} chars)
→ Translated & Dubbed

Voice: Professional AI Voice
Style: Natural conversational
Language: Target language
Duration: ${Math.ceil(s.length/15)} seconds

🎯 Lip-sync: Enabled
🎚️ Audio Quality: Studio Grade
📥 Ready for download

Preview available in player below.`),r(!1)},2e3)},icon:J,label:i?"Processing...":"Generate Dubbed Audio"}),n&&e.jsx(g,{value:n,label:"Dubbing Result"})]})}function Mc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all cursor-pointer",children:[e.jsx(Ue,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-white font-medium",children:"Upload Video to Upscale"}),e.jsx("div",{className:"text-gray-500 text-sm mt-1",children:"Supports MP4, MOV, AVI, WEBM (max 2GB)"}),e.jsx("button",{className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm",children:"Choose Video"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["2x Upscale (SD→HD)","4x Upscale (HD→4K)","8x Upscale (HD→8K)"],label:"Scale Factor"}),e.jsx(b,{options:["AI Enhanced","Standard","Animation","Grain Preserve"],label:"Enhancement"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`✨ Video Upscaled Successfully!

Original: 480p (640x480)
Enhanced: 4K (3840x2160)

Enhancement Details:
• AI Model: Real-ESRGAN v4
• Denoising: Applied
• Sharpening: Enhanced
• Color Correction: Auto

File Size: ${Math.floor(50+Math.random()*200)} MB
Quality: Excellent

✅ Ready for download`),o(!1)},3e3)},icon:Ya,label:n?"Upscaling...":"Upscale Video"}),s&&e.jsx(g,{value:s,label:"Upscale Result"})]})}function Sc({tool:t}){const[s,a]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-4 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-2xl mb-1",children:"🖥️"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Full Screen"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-2xl mb-1",children:"📄"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Window"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-2xl mb-1",children:"📍"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Region"})]})]}),e.jsx(b,{options:["1080p Full HD","4K Ultra HD","720p HD","480p SD"],label:"Quality"}),e.jsx("div",{className:"flex gap-3 mt-4",children:e.jsxs("button",{onClick:()=>a(!s),className:`inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all ${s?"bg-red-600 hover:bg-red-700 text-white animate-pulse":"bg-red-600 hover:bg-red-700 text-white"}`,children:[e.jsx("div",{className:`w-3 h-3 rounded-full ${s?"bg-white":"bg-red-200"}`}),s?"Recording... Click to Stop":"Start Recording"]})}),s&&e.jsx("div",{className:"mt-4 p-3 rounded-xl bg-gradient-to-r from-red-500/10 to-red-600/10 border border-red-500/20 text-red-400 text-sm text-center animate-pulse",children:"● Recording in progress — Audio & Screen capture active"})]})}function Cc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all cursor-pointer",children:[e.jsx(U,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-white font-medium",children:"Upload Audio File"}),e.jsx("div",{className:"text-gray-500 text-sm mt-1",children:"MP3, WAV, FLAC, OGG, M4A, AAC"}),e.jsx("button",{className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm",children:"Choose File"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["MP3 (320kbps)","WAV (Lossless)","FLAC (Lossless)","OGG (Vorbis)","AAC","M4A"],label:"Output Format"}),e.jsx(b,{options:["High Quality","Medium Quality","Low Quality (Small)"],label:"Quality"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`✅ Audio Converted!

Format: MP3 → FLAC
Original Size: 8.5 MB
New Size: 24.2 MB
Quality: Lossless
Sample Rate: 44100 Hz
Bit Depth: 16 bit

✅ Ready for download`),o(!1)},1500)},icon:Ja,label:n?"Converting...":"Convert Audio"}),s&&e.jsx(g,{value:s})]})}function Nc({tool:t}){const[s,a]=l.useState(!1),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all cursor-pointer",children:[e.jsx(U,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-white font-medium",children:"Upload Video File"}),e.jsx("button",{className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm",children:"Choose Video"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["MP4 (H.264)","AVI","MKV","WEBM","MOV","GIF"],label:"Output Format"}),e.jsx(b,{options:["1080p","720p","480p","Original"],label:"Resolution"})]}),e.jsx(x,{onClick:()=>{a(!0),setTimeout(()=>{o(`✅ Video Converted!

Format: MOV → MP4
Resolution: 1920x1080
Codec: H.264
Bitrate: 8 Mbps
File Size: 145 MB

✅ Ready for download`),a(!1)},2e3)},icon:Ja,label:s?"Converting...":"Convert Video"}),n&&e.jsx(g,{value:n})]})}function $c({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all",children:[e.jsx(U,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-gray-500 text-sm",children:"Upload video to extract audio"}),e.jsx("button",{className:"mt-3 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm",children:"Choose Video"})]}),e.jsx(b,{options:["MP3 320kbps","WAV Lossless","FLAC","AAC"],label:"Audio Format"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎵 Audio Extracted!

Source: video.mp4
Audio: MP3 320kbps
Size: 12.3 MB
Duration: 5:30

✅ Ready for download`),o(!1)},1500)},icon:pe,label:"Extract Audio"}),s&&e.jsx(g,{value:s})]})}function kc({tool:t}){const[s,a]=l.useState(!1);return e.jsx(m,{tool:t,children:e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:`w-20 h-20 mx-auto rounded-full ${s?"bg-red-500/20 animate-pulse":"bg-white/5"} border border-white/10 flex items-center justify-center mb-4`,children:e.jsx(fr,{className:`w-10 h-10 ${s?"text-red-400":"text-gray-500"}`})}),e.jsx("button",{onClick:()=>a(!s),className:`px-6 py-3 rounded-xl font-medium text-sm ${s?"bg-red-600 text-white animate-pulse":"bg-indigo-600 text-white"} transition-all`,children:s?"⏹️ Stop Recording":"🎙️ Start Recording"}),s&&e.jsxs("div",{className:"mt-3 text-red-400 text-sm animate-pulse",children:["● Recording... ($",Math.floor(Math.random()*60),"s)"]})]})})}function Tc({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("div",{className:"text-white text-sm mb-2",children:"Drop audio file here"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Browse"})]}),e.jsx("div",{className:"flex gap-2 mt-4 flex-wrap",children:["Cut","Copy","Paste","Trim","Fade In","Fade Out","Silence","Reverse"].map(s=>e.jsx("button",{className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:bg-white/10 hover:text-white transition-all",children:s},s))}),e.jsx("div",{className:"mt-4 h-16 rounded-xl bg-white/[0.02] border border-white/5 relative overflow-hidden",children:e.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-gray-700 text-sm",children:"Waveform preview"})})]})}function Ac({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("div",{className:"text-white text-sm mb-2",children:"Upload video to edit"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Browse"})]}),e.jsx("div",{className:"flex gap-2 mt-4 flex-wrap",children:["Trim","Split","Merge","Crop","Rotate","Speed","Effects","Text"].map(s=>e.jsx("button",{className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:bg-white/10 hover:text-white transition-all",children:s},s))})]})}function Rc({tool:t}){const[s,a]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"h-32 rounded-xl bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 flex items-center justify-center overflow-hidden",children:e.jsx("div",{className:"flex items-end gap-1 h-24",children:Array.from({length:64},(n,o)=>e.jsx("div",{className:`w-2 rounded-t transition-all ${s?"bg-gradient-to-t from-indigo-500 to-purple-500":"bg-white/10"}`,style:{height:s?`${Math.random()*100}%`:"10%",animationDuration:`${.3+Math.random()*.5}s`}},o))})}),e.jsx("button",{onClick:()=>a(!s),className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm",children:s?"⏹ Stop":"▶ Play Visualization"})]})}function Pc({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-4 gap-2",children:["Kick","Snare","Hi-Hat","808","Clap","Rim","Tom","Crash"].map(s=>e.jsx("button",{onClick:()=>{},className:"p-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:bg-indigo-500/20 hover:border-indigo-500/30 hover:text-white transition-all",children:s},s))}),e.jsxs("div",{className:"flex gap-2 mt-4",children:[e.jsx(b,{options:["120 BPM","90 BPM","140 BPM","160 BPM","180 BPM"],label:"Tempo"}),e.jsx(b,{options:["4/4","3/4","6/8"],label:"Time Signature"})]})]})}function Lc({tool:t}){const[s,a]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("div",{className:"text-white text-sm mb-2",children:"Upload music to make ringtone"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Browse"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Start - End (Custom)","Best Part (Auto)","Full Song"],label:"Mode"}),e.jsx(b,{options:["iPhone","Android","Generic MP3"],label:"Device"})]}),e.jsx(x,{onClick:()=>{a(!0),setTimeout(()=>a(!1),1e3)},icon:pe,label:"Create Ringtone"})]})}function Ec({tool:t}){const[s,a]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload Audio"})]}),e.jsx(b,{options:["-14 LUFS (Spotify)","-16 LUFS (YouTube)","-23 LUFS (Broadcast)","Custom"],label:"Target Loudness"}),e.jsx(x,{onClick:()=>{a(!0),setTimeout(()=>{a(!1)},1200)},icon:br,label:"Normalize Audio"})]})}function Fc({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"flex gap-1 h-32 items-end justify-center",children:["32","64","125","250","500","1K","2K","4K","8K","16K"].map((s,a)=>e.jsxs("div",{className:"flex flex-col items-center",children:[e.jsx("input",{type:"range",min:"-12",max:"12",defaultValue:"0",className:"h-24 w-1.5 appearance-none bg-white/20 rounded-full [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-indigo-500 [&::-webkit-slider-thumb]:rotate-90 writing-mode:vertical-lr"}),e.jsx("span",{className:"text-[8px] text-gray-600 mt-1",children:s})]},s))}),e.jsx("div",{className:"flex gap-2 justify-center",children:["Flat","Rock","Pop","Jazz","Classical","Bass Boost"].map(s=>e.jsx("button",{className:"px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-gray-500 text-[10px] hover:bg-white/10 hover:text-white transition-all",children:s},s))})]})}function Ic({tool:t}){const[s,a]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload Video"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Minimal (90% quality)","Balanced (70%)","Maximum (40%)"],label:"Compression"}),e.jsx(b,{options:["H.264","H.265/HEVC","VP9","AV1"],label:"Codec"})]}),e.jsx(x,{onClick:()=>{a(!0),setTimeout(()=>{a(!1)},1500)},icon:yr,label:"Compress Video"})]})}function Dc({tool:t}){const[s,a]=l.useState(1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload File"})]}),e.jsxs("div",{className:"text-center my-4",children:[e.jsxs("div",{className:"text-3xl font-bold text-white",children:[s,"x"]}),e.jsx("input",{type:"range",min:"0.25",max:"4",step:"0.25",value:s,onChange:n=>a(Number(n.target.value)),className:"w-full mt-2"}),e.jsxs("div",{className:"flex justify-between text-xs text-gray-600 mt-1",children:[e.jsx("span",{children:"0.25x"}),e.jsx("span",{children:"1x"}),e.jsx("span",{children:"2x"}),e.jsx("span",{children:"4x"})]})]}),e.jsx(b,{options:["Preserve Pitch","Change Pitch"],label:"Pitch Mode"})]})}function Oc({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(jr,{className:"w-6 h-6 text-indigo-400 mx-auto mb-1"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Record"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(Xa,{className:"w-6 h-6 text-indigo-400 mx-auto mb-1"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Publish"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(Bc,{className:"w-6 h-6 text-indigo-400 mx-auto mb-1"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Analytics"})]})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20",children:[e.jsx("div",{className:"text-white font-medium text-sm",children:"🎙️ Your Podcast Dashboard"}),e.jsx("div",{className:"text-gray-500 text-xs mt-1",children:"Episodes: 0 • Listeners: 0 • Published: 0"})]}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Enter episode title...",label:"New Episode"})]})}function Bc(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M3 20h18M5 16l3-8 4 6 4-8 5 10"})})}function Gc({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("blog")?e.jsx(Hc,{tool:t}):r.includes("seo")&&(r.includes("article")||r.includes("content"))?e.jsx(Wc,{tool:t}):r.includes("resume")?e.jsx(Uc,{tool:t}):r.includes("email")?e.jsx(Vc,{tool:t}):r.includes("story")||r.includes("novel")?e.jsx(zc,{tool:t}):r.includes("paraphras")||r.includes("rewrite")||r.includes("rephrase")?e.jsx(qc,{tool:t}):r.includes("summar")||r.includes("summary")?e.jsx(Qc,{tool:t}):r.includes("grammar")||r.includes("spelling")?e.jsx(_c,{tool:t}):r.includes("plagiarism")||r.includes("plag")?e.jsx(Kc,{tool:t}):r.includes("headline")||r.includes("title")?e.jsx(Yc,{tool:t}):r.includes("bio")||r.includes("about")?e.jsx(Jc,{tool:t}):r.includes("hashtag")?e.jsx(Xc,{tool:t}):r.includes("caption")?e.jsx(Zc,{tool:t}):r.includes("intro")||r.includes("introduction")?e.jsx(ed,{tool:t}):r.includes("conclusion")||r.includes("outro")?e.jsx(td,{tool:t}):r.includes("outline")?e.jsx(sd,{tool:t}):r.includes("quote")?e.jsx(ad,{tool:t}):r.includes("slogan")||r.includes("tagline")?e.jsx(nd,{tool:t}):r.includes("desc")||r.includes("meta")?e.jsx(rd,{tool:t}):r.includes("product")&&r.includes("desc")?e.jsx(od,{tool:t}):r.includes("ad")||r.includes("copy")?e.jsx(id,{tool:t}):r.includes("press")||r.includes("release")?e.jsx(ld,{tool:t}):r.includes("newsletter")?e.jsx(cd,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:`Enter content for ${t.name}...`,label:"Content Input",multiline:!0,icon:O}),e.jsx(b,{options:["Professional","Creative","Academic","Casual","Formal"],label:"Tone"}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`📝 ${t.name} Generated!

---
${s||"Your content will appear here..."}

---
✅ Generated successfully
Words: ${Math.floor(50+Math.random()*200)}
Tone: Professional`),i(!1)},1200)},icon:$,label:`Generate with ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Hc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("Professional"),[i,r]=l.useState("1000"),[c,d]=l.useState(""),[h,u]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter your blog topic...",label:"Blog Topic",icon:O}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:["Professional","Conversational","Academic","Persuasive","Storytelling"],label:"Tone"}),e.jsx(b,{value:i,onChange:r,options:["500 words","1000 words","1500 words","2000+ words"],label:"Length"})]}),e.jsx(x,{onClick:()=>{u(!0),setTimeout(()=>{d(`# ${s||"Your Blog Title"}

## Introduction
In today's fast-paced world, ${(s||"this topic").toLowerCase()} has become increasingly important. This comprehensive guide will walk you through everything you need to know.

## Why ${s||"This Topic"} Matters
Understanding ${(s||"this").toLowerCase()} is crucial for success in 2026. Here are the key reasons:

1. **Increased Efficiency** - Save time and resources
2. **Better Results** - Achieve higher quality outcomes
3. **Competitive Advantage** - Stay ahead of the curve

## How to Get Started
Getting started is easier than you think. Follow these steps:

1. Research and understand the basics
2. Choose the right tools and resources
3. Practice consistently
4. Measure your results

## Expert Tips
- Start small and scale gradually
- Learn from industry leaders
- Use analytics to track progress

## Conclusion
${s||"This topic"} is transforming how we work. By following this guide, you're on your way to success!

---
📝 Generated: ${i} words | ${n} tone`),u(!1)},2e3)},icon:$,label:h?"Writing...":"Generate Blog Post"}),c&&e.jsx(g,{value:c,label:"Blog Post"})]})}function Wc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter target keyword...",label:"Primary Keyword",icon:ke}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Related keywords",label:"Secondary Keywords"}),e.jsx(b,{options:["SEO Optimized","Readability Focus","Balanced"],label:"Strategy"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`# ${s||"Topic"}: The Ultimate Guide 2026

## Introduction
SEO-optimized content about ${(s||"this topic").toLowerCase()}.

## What is ${s||"This"}?
${s||"This"} refers to [comprehensive explanation with LSI keywords].

## Key Benefits
- Benefit 1 with ${s||"topic"} optimization
- Benefit 2 with semantic relevance
- Benefit 3 with user intent focus

## How-to Guide
Step-by-step instructions optimized for featured snippets.

## FAQ Section
**Q: How does ${s||"this"} work?**
A: [Detailed, keyword-rich answer]

---
📊 SEO Score: 94/100
📝 Word Count: 1,450
🔑 Keyword Density: 1.2%
🏆 Featured Snippet Potential: High`),r(!1)},2e3)},icon:Q,label:i?"Optimizing...":"Generate SEO Article"}),n&&e.jsx(g,{value:n,label:"SEO Article"})]})}function Uc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(""),[h,u]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your full name",label:"Full Name"}),e.jsx(p,{value:n,onChange:o,placeholder:"e.g., Software Engineer",label:"Professional Title"})]}),e.jsx(p,{value:i,onChange:r,placeholder:"Your skills, experience, education...",label:"Skills & Experience",multiline:!0}),e.jsx(x,{onClick:()=>{u(!0),setTimeout(()=>{d(`📄 RESUME

${s||"Your Name"}
${n||"Professional Title"}

SUMMARY
Experienced professional with expertise in ${i||"various domains"}.

EXPERIENCE
• Senior Position — Company Name (2020-Present)
• Mid-Level Role — Previous Company (2016-2020)
• Junior Position — First Company (2012-2016)

EDUCATION
• Degree — University Name (Year)

SKILLS
${i||"• Skill 1, Skill 2, Skill 3"}

---
✅ Professional Resume Generated
ATS Score: 92/100
Suggested improvements: 2`),u(!1)},1500)},icon:O,label:h?"Building...":"Generate Resume"}),c&&e.jsx(g,{value:c,label:"Your Resume"})]})}function Vc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Why are you writing?",label:"Email Purpose"}),e.jsx(b,{options:["Professional","Friendly","Formal","Follow-up","Persuasive"],label:"Tone"})]}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Recipient name",label:"Recipient"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`Subject: ${s||"Your Inquiry"}

Dear [Recipient],

I hope this email finds you well.

I am writing to ${(s||"discuss our recent conversation").toLowerCase()}.

I believe this would be mutually beneficial and I look forward to your response.

Please let me know if you have any questions.

Best regards,
[Your Name]
[Your Title]
[Your Contact Info]

---
📧 Email generated in Professional tone`),r(!1)},1e3)},icon:Za,label:i?"Writing...":"Generate Email"}),n&&e.jsx(g,{value:n,label:"Email Draft"})]})}function zc({tool:t}){const[s,a]=l.useState("Fantasy"),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:n,onChange:o,placeholder:"Describe your story idea...",label:"Story Prompt",multiline:!0,icon:A}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:s,onChange:a,options:["Fantasy","Sci-Fi","Romance","Mystery","Horror","Adventure","Drama"],label:"Genre"}),e.jsx(b,{options:["First Person","Third Person","Second Person"],label:"Perspective"})]}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`# ${n||"Untitled Story"}

Genre: ${s}

## Chapter 1: The Beginning

The air was thick with anticipation as ${(n||"our protagonist").toLowerCase()} stepped into the unknown. Little did they know, this moment would change everything.

It was a day like any other, except something felt different. The world seemed to hold its breath, waiting for what was to come.

"What happens now?" they whispered to the wind.

The answer came not in words, but in feeling — a sense that the adventure was only beginning.

[Story continues...]

---
📚 ${Math.floor(300+Math.random()*700)} words written
🎭 Genre: ${s}
⏱️ Estimated read time: ${Math.ceil(Math.random()*5)} min`),d(!1)},2e3)},icon:ot,label:c?"Writing...":"Write Story"}),i&&e.jsx(g,{value:i,label:"Story"})]})}function qc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste text to paraphrase...",label:"Original Text",multiline:!0,icon:Zs}),e.jsx(b,{options:["Standard","Fluent","Formal","Creative","Academic"],label:"Style"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`✏️ Paraphrased Version:

${s?s.split(".").map(c=>c.trim()).filter(Boolean).map(c=>{const d=c.split(" ");if(d.length>3){const h=Math.floor(d.length/2);return[...d.slice(h),...d.slice(0,h)].join(" ")}return c}).join(". ")+".":"Your paraphrased text will appear here..."}

📊 Changes: 67% rewritten
🔤 Original: ${(s||"").split(" ").length||0} words
✏️ New: ${Math.floor((s||"").split(" ").length*.9)||0} words`),r(!1)},1200)},icon:Zs,label:i?"Paraphrasing...":"Paraphrase"}),n&&e.jsx(g,{value:n,label:"Paraphrased"})]})}function Qc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste text to summarize...",label:"Text to Summarize",multiline:!0,icon:O}),e.jsx(b,{options:["Brief (1-2 sentences)","Short (3-5 sentences)","Detailed (paragraph)"],label:"Summary Length"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 Summary

${s?s.split(".").slice(0,Math.min(5,s.split(".").length)).join(".")+".":"Your summary will appear here based on the input text provided."}

---
📊 Original: ${(s||"").split(" ").length||0} words
📝 Summary: ${Math.max(10,Math.floor((s||"").split(" ").length*.25))||0} words
📉 Reduction: ${75+Math.floor(Math.random()*15)}%
🔑 Key Points: ${Math.floor(3+Math.random()*5)}`),r(!1)},1200)},icon:A,label:i?"Summarizing...":"Summarize"}),n&&e.jsx(g,{value:n,label:"Summary"})]})}function _c({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste text to check grammar...",label:"Text",multiline:!0,icon:Te}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔍 Grammar Check Results

Issues Found: ${Math.floor(Math.random()*8)}

1. 🟡 Line 3: Possible passive voice — "was done"
   → Suggest: "did"

2. 🟢 Line 7: Missing Oxford comma
   → Suggest: Add comma before "and"

3. 🔴 Line 12: Subject-verb agreement
   → Suggest: "The team is" (not "are")

4. 🟡 Line 18: Wordy phrase — "in order to"
   → Suggest: "to"

---
📊 Score: ${Math.floor(75+Math.random()*20)}/100
✅ Suggestions: ${Math.floor(Math.random()*5+1)}
✏️ Fixed: Auto-correct applied`),r(!1)},1e3)},icon:Te,label:i?"Checking...":"Check Grammar"}),n&&e.jsx(g,{value:n,label:"Grammar Report"})]})}function Kc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste text to check for plagiarism...",label:"Content",multiline:!0,icon:Q}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔍 Plagiarism Check Complete

Originality Score: ${(80+Math.random()*20).toFixed(1)}%

Matched Sources:
• No significant matches found ✅
• ${Math.floor(Math.random()*5)} minor phrase matches
• All within acceptable limits

---
📄 ${(s||"").split(" ").length||0} words checked
🌐 Database: 50B+ web pages
📚 Academic papers: 200M+
✅ Status: Original content`),r(!1)},1500)},icon:Q,label:i?"Scanning...":"Check Plagiarism"}),n&&e.jsx(g,{value:n,label:"Plagiarism Report"})]})}function Yc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter your topic...",label:"Topic",icon:je}),e.jsx(b,{options:["Click-Worthy","SEO Optimized","Emotional","How-To","Listicle"],label:"Style"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📰 Headlines for: ${s||"Your Topic"}

1. 🔥 ${s||"Topic"}: The Ultimate Guide You'll Ever Need
2. 🚀 10 Revolutionary ${s||"Topic"} Strategies for 2026
3. 💡 How ${s||"Topic"} Is Changing the Game
4. ⚡ ${s||"Topic"} Secrets Experts Won't Tell You
5. 🎯 The Complete ${s||"Topic"} Cheatsheet
6. 📈 Why ${s||"Topic"} Matters Now More Than Ever
7. 💪 Master ${s||"Topic"} in Just 7 Days
8. 🤯 ${s||"Topic"} Hacks That Will Blow Your Mind

📊 Click-Through Potential: High
📌 SEO Score: 88/100`),r(!1)},1e3)},icon:je,label:i?"Generating...":"Generate Headlines"}),n&&e.jsx(g,{value:n,label:"Headlines"})]})}function Jc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your name",label:"Name"}),e.jsx(p,{value:n,onChange:o,placeholder:"Your profession",label:"Role"})]}),e.jsx(b,{options:["Professional","Creative","Minimal","Funny","Inspirational"],label:"Style"}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`👤 Bio Generated

Short (150 chars):
${n||"Professional"} • ${s||"Your Name"} • Helping ${(n||"professionals").toLowerCase()} achieve more

Medium (300 chars):
${s||"Your Name"} is a ${n||"professional"} passionate about making a difference. With expertise in ${(n||"multiple domains").toLowerCase()}, they help others achieve their goals through innovative solutions.

Long (500 chars):
${s||"Your Name"} is a seasoned ${n||"professional"} with years of experience in ${(n||"the industry").toLowerCase()}. Known for delivering exceptional results, they specialize in creating impactful solutions that drive growth and innovation.

---
✅ ${Math.floor(Math.random()*3+1)} versions generated`),d(!1)},1e3)},icon:ot,label:"Generate Bio"}),i&&e.jsx(g,{value:i,label:"Bio"})]})}function Xc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter topic or keyword...",label:"Topic",icon:ke}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🏷️ Hashtags for: ${s||"Your Topic"}

Popular (High Reach):
#${(s||"trending").replace(/\s+/g,"")} #${(s||"viral").replace(/\s+/g,"")} #${(s||"popular").replace(/\s+/g,"")}2026

Medium (Targeted):
#${(s||"niche").replace(/\s+/g,"")}Tips #${(s||"expert").replace(/\s+/g,"")}Guide #Learn${(s||"Skills").replace(/\s+/g,"")}

Niche (High Engagement):
#${(s||"specific").replace(/\s+/g,"")}Community #${(s||"daily").replace(/\s+/g,"")}Tips #${(s||"pro").replace(/\s+/g,"")}Life

📊 ${Math.floor(10+Math.random()*20)} hashtags generated
🎯 Best times: 9AM-11AM, 6PM-9PM`),r(!1)},800)},icon:ke,label:"Generate Hashtags"}),n&&e.jsx(g,{value:n,label:"Hashtags"})]})}function Zc({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your photo/video...",label:"Content Description"}),e.jsx(b,{options:["Instagram","Twitter/X","LinkedIn","Facebook","TikTok"],label:"Platform"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📸 Social Media Captions

1. ${s||"Your moment"} — because memories matter.
   #${(s||"memories").replace(/\s+/g,"")} #blessed

2. This is what ${(s||"happiness").toLowerCase()} looks like. ✨
   #everymoment #${(s||"joy").replace(/\s+/g,"")}

3. POV: ${s||"Living your best life"}
   #pov #${(s||"reality").replace(/\s+/g,"")}

4. Sometimes you just need a little ${(s||"inspiration").toLowerCase()} 🌟
   #inspo #${(s||"vibes").replace(/\s+/g,"")}

5. ${s||"This view"} never gets old. 🏆
   #nofilter #${(s||"beautiful").replace(/\s+/g,"")}`),r(!1)},1e3)},icon:ot,label:"Generate Captions"}),n&&e.jsx(g,{value:n,label:"Captions"})]})}function ed({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"What is this about?",label:"Topic"}),e.jsx(b,{options:["Professional","Storytelling","Question-based","Statistics","Bold Statement"],label:"Style"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📝 Introductions for: ${s||"Your Topic"}

1. "In the rapidly evolving landscape of ${(s||"today").toLowerCase()}, one question dominates: How do we stay ahead?"

2. "Imagine a world where ${(s||"everything").toLowerCase()} is transformed. That's not the future — it's happening now."

3. "Did you know that 89% of professionals believe ${(s||"this").toLowerCase()} is the key to success in 2026?"

4. "${s||"Your Topic"} isn't just important — it's essential for anyone looking to thrive in the modern era."

📊 Hook Score: ${(80+Math.random()*20).toFixed(0)}%`),r(!1)},1e3)},icon:ot,label:"Generate Intros"}),n&&e.jsx(g,{value:n,label:"Intros"})]})}function td({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"What is the topic?",label:"Topic"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🏁 Conclusions for: ${s||"Your Topic"}

1. "In conclusion, ${(s||"this topic").toLowerCase()} represents a paradigm shift in how we approach our goals. The time to act is now."

2. "As we've seen, ${(s||"this").toLowerCase()} is not just a trend — it's the foundation of future success."

3. "The evidence is clear: ${(s||"this").toLowerCase()} delivers measurable results. Start implementing these strategies today."

4. "Whether you're a beginner or expert, mastering ${(s||"this").toLowerCase()} will unlock new levels of achievement."

📊 Effectiveness: ${(80+Math.random()*20).toFixed(0)}%`),r(!1)},800)},icon:O,label:"Generate Conclusions"}),n&&e.jsx(g,{value:n})]})}function sd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Content topic",label:"Topic"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 Content Outline: ${s||"Your Topic"}

I. Introduction
   • Hook: Start with a compelling statistic
   • Problem statement
   • Thesis: Why ${(s||"this").toLowerCase()} matters

II. What is ${s||"This"}?
   • Definition and overview
   • Key concepts explained
   • History and evolution

III. Benefits
   • Benefit 1 with examples
   • Benefit 2 with data
   • Benefit 3 with case study

IV. How to Get Started
   • Step 1: Preparation
   • Step 2: Implementation
   • Step 3: Optimization

V. Common Mistakes to Avoid
   • Mistake 1 and solution
   • Mistake 2 and solution

VI. Expert Tips & Best Practices
   • Tip 1
   • Tip 2
   • Tip 3

VII. Conclusion
   • Recap of key points
   • Call to action

📝 Total sections: 7 | Estimated: 2,000 words`),r(!1)},1e3)},icon:vr,label:"Generate Outline"}),n&&e.jsx(g,{value:n,label:"Outline"})]})}function ad({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Theme (success, life, love...)",label:"Theme"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`💬 ${s||"Inspirational"} Quotes

1. "Success is not final, failure is not fatal: it is the courage to continue that counts."
   — Winston Churchill

2. "The only way to do great work is to love what you do."
   — Steve Jobs

3. "In the middle of difficulty lies opportunity."
   — Albert Einstein

4. "Your limitation—it's only your imagination."
   — Unknown

5. "Push yourself because no one else is going to do it for you."
   — Unknown

🎯 Share these on social media for maximum engagement!`),r(!1)},800)},icon:za,label:"Generate Quotes"}),n&&e.jsx(g,{value:n})]})}function nd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your brand or business name",label:"Brand Name"}),e.jsx(b,{options:["Professional","Creative","Luxury","Fun","Social Impact"],label:"Style"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🏷️ Slogans for ${s||"Your Brand"}

1. "${s||"Brand"} — Empowering Your Success"
2. "${s||"Brand"}: Innovation That Matters"
3. "Experience the ${s||"Brand"} Difference"
4. "${s||"Brand"} — Where Quality Meets Trust"
5. "Transform Your World with ${s||"Brand"}"
6. "${s||"Brand"}: Built for Tomorrow"
7. "Your Journey, Our ${s||"Passion"}"
8. "${s||"Brand"} — Simply Better"

📊 Best Rated: #3 (Memorability Score: 92%)`),r(!1)},1e3)},icon:ot,label:"Generate Slogans"}),n&&e.jsx(g,{value:n})]})}function rd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Page content or topic...",label:"Page Content",multiline:!0}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📝 Meta Description (Optimized)

Title: ${(s||"Your Title").slice(0,60)}...
Meta: ${(s||"Learn about this topic").slice(0,155)} — Discover comprehensive guides, expert tips, and practical advice. Start your journey today!

Preview:
🔍 ${(s||"Your Title").slice(0,60)}...
🔗 https://yoursite.com/page
📝 ${(s||"Learn about this topic").slice(0,155)}...

✅ Length: 155 chars (Perfect)
🔑 Keyword: Included naturally
📈 CTR Potential: High`),r(!1)},800)},icon:Q,label:"Optimize Meta"}),n&&e.jsx(g,{value:n})]})}function od({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your product...",label:"Product",multiline:!0}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🛍️ Product Description

Product: ${s||"Your Product"}

Experience premium quality with ${(s||"our product").toLowerCase()}. Designed for those who demand the best, our product delivers exceptional performance and unmatched reliability.

Key Features:
• Premium quality materials
• Cutting-edge technology
• Ergonomic design
• Easy to use
• Long-lasting durability

Perfect for professionals and enthusiasts alike. Order now and transform your experience!`),r(!1)},1e3)},icon:O,label:"Generate Description"}),n&&e.jsx(g,{value:n})]})}function id({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"What are you advertising?",label:"Product/Service"}),e.jsx(b,{options:["Facebook/Instagram","Google Ads","LinkedIn","TikTok","Twitter/X"],label:"Platform"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📢 Ad Copy for: ${s||"Your Product"}

Headline: Transform Your Results with ${s||"Our Solution"}

Body:
Tired of ${(s||"outdated solutions").toLowerCase()}? Our ${(s||"product").toLowerCase()} delivers ${Math.floor(Math.random()*300+50)}% better results. Join 10,000+ satisfied customers today.

🔹 Feature 1: Premium quality
🔹 Feature 2: Lightning fast
🔹 Feature 3: 24/7 support

CTA: Get Started Now — Free Trial

📊 Predicted CTR: ${(2+Math.random()*5).toFixed(1)}%
💰 Conversion Rate: ${(3+Math.random()*7).toFixed(1)}%`),r(!1)},1e3)},icon:L,label:"Generate Ad Copy"}),n&&e.jsx(g,{value:n})]})}function ld({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"What's the news?",label:"Announcement",multiline:!0}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📰 PRESS RELEASE

FOR IMMEDIATE RELEASE

HEADLINE: ${s||"Company Makes Groundbreaking Announcement"}

[CITY, Date] — ${s||"Leading company"} today announced a major breakthrough in ${(s||"the industry").toLowerCase()}.

"This represents a significant milestone," said [Spokesperson Name], [Title]. "We're excited to bring this innovation to our customers."

The new ${(s||"solution").toLowerCase()} is expected to revolutionize how businesses operate.

About the Company:
[Company description]

Media Contact:
[Name]
[Email]
[Phone]

###

📊 Distribution: Major news outlets
🎯 Estimated reach: ${Math.floor(Math.random()*10+1)}M+ impressions`),r(!1)},1200)},icon:L,label:"Write Press Release"}),n&&e.jsx(g,{value:n})]})}function cd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Newsletter topic...",label:"Topic",multiline:!0}),e.jsx(b,{options:["Weekly Update","Industry Insights","Product Launch","Educational","Curated Content"],label:"Type"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📬 NEWSLETTER: ${s||"Your Update"}

Subject: ${s||"Your Monthly Update"} — Don't Miss This!

Hey [Subscriber],

Here's what's new this ${["week","month"][Math.floor(Math.random()*2)]}:

📌 Top Story
${s||"Key industry development"} that's making waves.

🎯 Featured Content
• Curated insights from industry experts
• Actionable tips and strategies
• Latest trends and analysis

⚡ Quick Updates
• Update 1
• Update 2
• Update 3

💡 Pro Tip: [Actionable advice for readers]

That's all for now!

Best,
[Your Name]

---
📊 Open rate prediction: ${(15+Math.random()*30).toFixed(0)}%
🖱️ CTR prediction: ${(2+Math.random()*8).toFixed(1)}%`),r(!1)},1200)},icon:Za,label:"Write Newsletter"}),n&&e.jsx(g,{value:n})]})}function dd({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("keyword")&&r.includes("planner")?e.jsx(ud,{tool:t}):r.includes("backlink")?e.jsx(hd,{tool:t}):r.includes("meta")&&r.includes("desc")?e.jsx(md,{tool:t}):r.includes("rank")&&r.includes("tracker")?e.jsx(xd,{tool:t}):r.includes("speed")||r.includes("page")&&r.includes("analyzer")?e.jsx(pd,{tool:t}):r.includes("competitor")||r.includes("competitive")?e.jsx(gd,{tool:t}):r.includes("keyword")&&r.includes("research")?e.jsx(fd,{tool:t}):r.includes("site")&&r.includes("audit")?e.jsx(bd,{tool:t}):r.includes("link")&&r.includes("build")?e.jsx(yd,{tool:t}):r.includes("content")&&r.includes("analyzer")?e.jsx(jd,{tool:t}):r.includes("seo")&&r.includes("score")?e.jsx(vd,{tool:t}):r.includes("schema")||r.includes("structured")?e.jsx(wd,{tool:t}):r.includes("redirect")||r.includes("301")?e.jsx(Md,{tool:t}):r.includes("robot")||r.includes("robots")?e.jsx(Sd,{tool:t}):r.includes("sitemap")?e.jsx(Cd,{tool:t}):r.includes("serp")||r.includes("snippet")?e.jsx(Nd,{tool:t}):r.includes("domain")&&r.includes("authority")?e.jsx($d,{tool:t}):r.includes("social")&&(r.includes("media")||r.includes("share"))?e.jsx(kd,{tool:t}):r.includes("email")&&r.includes("market")?e.jsx(Td,{tool:t}):r.includes("conversion")||r.includes("cvr")?e.jsx(Ad,{tool:t}):r.includes("ppc")||r.includes("ad")&&r.includes("analyzer")?e.jsx(Rd,{tool:t}):r.includes("trend")?e.jsx(Pd,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",icon:L}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`📊 ${t.name} Results

Analysis complete for: ${s||"Default"}
Status: Success

📈 Metrics analyzed: ${Math.floor(5+Math.random()*20)}
💰 Estimated value: $${Math.floor(Math.random()*1e4)}
🏆 Score: ${Math.floor(60+Math.random()*40)}/100`),i(!1)},1200)},icon:Pe,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function ud({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter a seed keyword...",label:"Seed Keyword",icon:ke}),e.jsx(b,{options:["All","High Volume","Low Competition","Long Tail","Question-based"],label:"Filter"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📊 Keyword Research for: "${s||"example"}"

Top Keywords:

1. ${s||"keyword"} guide			2,400/mo	🟢 Low Competition
2. best ${s||"keyword"}		3,200/mo	🟡 Medium
3. ${s||"keyword"} tools		1,800/mo	🟢 Low
4. ${s||"keyword"} online		1,500/mo	🟢 Low
5. ${s||"keyword"} free		4,100/mo	🟡 Medium
6. ${s||"keyword"} 2026		1,200/mo	🟢 Low
7. ${s||"keyword"} tutorial		900/mo		🟢 Low
8. ${s||"keyword"} software		2,100/mo	🔴 High

🎯 Recommended: "${s||"keyword"} guide" (High traffic, Low competition)
💡 Estimated clicks/mo: ${Math.floor(200+Math.random()*800)}`),r(!1)},1500)},icon:Q,label:i?"Researching...":"Get Keyword Ideas"}),n&&e.jsx(g,{value:n,label:"Keyword Research"})]})}function hd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your website URL",label:"Website URL",icon:L}),e.jsx(b,{options:["Guest Posts","Directories","Resource Pages","Broken Links","All Sources"],label:"Strategy"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔗 Backlink Opportunities for: ${s||"yourwebsite.com"}

High Authority Sites:
1. forum.example.com		DA 85	(Guest Post Opportunity)
2. directory.example.org	DA 72	(Listing)
3. blog.example.net		DA 68	(Resource Page)
4. industry.example.io		DA 91	(Interview/Expert Roundup)
5. magazine.example.com		DA 78	(Contributed Article)
6. edu.example.org		DA 95	(.edu Backlink)
7. gov.example.net			DA 93	(.gov Listing)

📈 Estimated DA Improvement: +${Math.floor(5+Math.random()*15)} points
🎯 Priority: High authority backlinks ready for outreach
📧 Email templates included for outreach`),r(!1)},2e3)},icon:Jn,label:i?"Analyzing...":"Find Backlinks"}),n&&e.jsx(g,{value:n,label:"Backlink Opportunities"})]})}function md({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Page content or current meta...",label:"Page Content",multiline:!0}),e.jsx(p,{value:n,onChange:o,placeholder:"Target keyword",label:"Target Keyword"}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`📝 Optimized Meta Tags

Title Tag (${Math.min(60,(s||"").length)} chars):
${(s||"Your Title").slice(0,60)} | ${n||"Keyword"} • Brand

Meta Description (${Math.min(155,(s||"").length+20)} chars):
${(s||"Your content").slice(0,140)}. Learn about ${n||"this topic"} — expert guides, tips & more.

🔍 Google Preview:
${(s||"Your Title").slice(0,60)}...
yourwebsite.com/page
${(s||"Your meta").slice(0,150)}...

✅ Title length: Perfect
✅ Meta length: Perfect
🔑 Keyword placement: Optimal`),d(!1)},1e3)},icon:$,label:"Optimize Meta Tags"}),i&&e.jsx(g,{value:i,label:"Optimized Meta"})]})}function xd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Keyword to track",label:"Keyword",icon:ke}),e.jsx(p,{value:n,onChange:o,placeholder:"yourwebsite.com",label:"Website URL",icon:L}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`📈 Rank Report: "${s||"example keyword"}"

Current Position: #${Math.floor(3+Math.random()*15)}
Change: ▲ +${Math.floor(Math.random()*5)} positions (7 days)

Position History:
📅 Today: #${Math.floor(3+Math.random()*10)}
📅 This Week: #${Math.floor(4+Math.random()*12)} → #${Math.floor(3+Math.random()*10)}
📅 This Month: #${Math.floor(8+Math.random()*15)} → #${Math.floor(3+Math.random()*10)}

🏆 Best Position: #${Math.floor(2+Math.random()*5)}
📊 Search Volume: ${Math.floor(500+Math.random()*1e4).toLocaleString()}/mo
🎯 Estimated Traffic: ${Math.floor(50+Math.random()*500).toLocaleString()} clicks/mo
💰 Traffic Value: $${Math.floor(200+Math.random()*3e3).toLocaleString()}/mo

Top Competitors:
1. competitor1.com (#${Math.floor(Math.random()*3)+1})
2. competitor2.com (#${Math.floor(Math.random()*3)+2})`),d(!1)},1500)},icon:Ge,label:c?"Tracking...":"Check Rankings"}),i&&e.jsx(g,{value:i,label:"Rank Report"})]})}function pd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter website URL to analyze...",label:"Website URL",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`⚡ Page Speed Analysis for: ${s||"example.com"}

Performance Score: ${Math.floor(40+Math.random()*50)}/100

Core Web Vitals:
🔴 LCP: ${(2+Math.random()*4).toFixed(1)}s (Needs improvement)
🟡 FID: ${Math.floor(50+Math.random()*150)}ms (Moderate)
🟢 CLS: ${(.05+Math.random()*.2).toFixed(2)} (${Math.random()>.5?"Good":"Needs improvement"})

Issues:
• ${Math.floor(3+Math.random()*10)} render-blocking resources
• ${Math.floor(200+Math.random()*800)}KB uncompressed images
• ${Math.floor(2+Math.random()*5)} unused CSS/JS files

Recommendations:
1. 🟢 Enable lazy loading
2. 🟢 Compress images (save ~${Math.floor(200+Math.random()*400)}KB)
3. 🟢 Minify CSS/JS
4. 🟢 Use browser caching
5. 🟢 Implement CDN

📈 Potential improvement: +${Math.floor(15+Math.random()*30)} points`),r(!1)},2e3)},icon:de,label:i?"Analyzing...":"Analyze Speed"}),n&&e.jsx(g,{value:n,label:"Speed Analysis"})]})}function gd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter competitor URL...",label:"Competitor URL",icon:ze}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🎯 Competitive Analysis for: ${s||"competitor.com"}

Domain Authority: ${Math.floor(30+Math.random()*50)}
Page Authority: ${Math.floor(25+Math.random()*55)}

Traffic Estimate:
• Monthly Visits: ${Math.floor(1e4+Math.random()*5e5).toLocaleString()}
• Top Pages: ${Math.floor(10+Math.random()*50)}
• Bounce Rate: ${(30+Math.random()*40).toFixed(0)}%

Top Keywords:
1. keyword 1 (#${Math.floor(Math.random()*10)+1})
2. keyword 2 (#${Math.floor(Math.random()*10)+1})
3. keyword 3 (#${Math.floor(Math.random()*10)+1})

Backlinks:
• Total: ${Math.floor(500+Math.random()*1e4).toLocaleString()}
• Referring Domains: ${Math.floor(50+Math.random()*500)}
• DA of linking sites: ${(30+Math.random()*40).toFixed(0)}

📊 Gap Analysis: ${Math.floor(10+Math.random()*20)} opportunities found`),r(!1)},2e3)},icon:xe,label:i?"Analyzing...":"Analyze Competitor"}),n&&e.jsx(g,{value:n,label:"Competitor Analysis"})]})}function fd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter niche or industry...",label:"Niche",icon:ke}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔑 Keyword Research: ${s||"Your Niche"}

Total Keywords Found: ${Math.floor(50+Math.random()*200)}

By Difficulty:
🟢 Easy: ${Math.floor(20+Math.random()*40)} keywords
🟡 Medium: ${Math.floor(15+Math.random()*30)} keywords
🔴 Hard: ${Math.floor(10+Math.random()*20)} keywords

Top Opportunities:
1. "${s||"keyword"} for beginners"	Vol: 2,400	🟢 Easy
2. "best ${s||"keyword"}"		Vol: 3,800	🟡 Medium
3. "${s||"keyword"} tutorial"	Vol: 1,200	🟢 Easy
4. "${s||"keyword"} 2026"		Vol: 5,200	🟡 Medium

💰 Potential Monthly Traffic: ${Math.floor(5e3+Math.random()*5e4).toLocaleString()}
📈 Avg. CPC: $${(1+Math.random()*10).toFixed(2)}`),r(!1)},1500)},icon:Q,label:"Research Keywords"}),n&&e.jsx(g,{value:n})]})}function bd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your website URL",label:"Website URL",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔍 Site Audit: ${s||"example.com"}

Overall Score: ${Math.floor(50+Math.random()*45)}/100

Issues Found: ${Math.floor(10+Math.random()*30)}

🔴 Critical: ${Math.floor(Math.random()*5)}
• Missing meta descriptions
• Broken links found
• Slow loading pages

🟡 Warnings: ${Math.floor(5+Math.random()*10)}
• Duplicate content
• Missing alt tags
• Large images

🟢 Passed: ${Math.floor(40+Math.random()*30)}
• SSL certificate valid
• Mobile responsive
• Robots.txt configured

📊 Improvements needed: ${Math.floor(10+Math.random()*20)} issues to fix`),r(!1)},2e3)},icon:O,label:"Run Audit"}),n&&e.jsx(g,{value:n})]})}function yd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your website URL",label:"Your Site",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔗 Link Building Strategy for: ${s||"example.com"}

Current Backlinks: ${Math.floor(100+Math.random()*900)}
Referring Domains: ${Math.floor(30+Math.random()*170)}

Strategies Generated:

1. 📝 Guest Posting (${Math.floor(10+Math.random()*20)} opportunities)
   • Sites with DA 50+: ${Math.floor(5+Math.random()*10)}
   • Topics: ${["Technology","Business","Marketing","Lifestyle"][Math.floor(Math.random()*4)]}

2. 🔗 Broken Link Building
   • ${Math.floor(5+Math.random()*15)} broken links found
   • ${Math.floor(3+Math.random()*8)} replacement opportunities

3. 📊 Resource Page Link Building
   • ${Math.floor(5+Math.random()*15)} relevant resource pages

4. 🤝 Interview/Expert Roundup
   • ${Math.floor(3+Math.random()*7)} Roundup opportunities

📈 Projected DA increase: +${(5+Math.random()*15).toFixed(0)} points in 3 months`),r(!1)},2e3)},icon:Jn,label:"Build Strategy"}),n&&e.jsx(g,{value:n})]})}function jd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste your content...",label:"Content",multiline:!0}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📊 Content Analysis

📝 Stats:
Words: ${(s||"").split(/\s+/).filter(Boolean).length||0}
Characters: ${(s||"").length}
Sentences: ${(s||"").split(/[.!?]+/).filter(Boolean).length||0}
Avg. Word Length: ${(s&&s.length/s.split(/\s+/).filter(Boolean).length||0).toFixed(1)} chars

🎯 Readability:
• Score: ${Math.floor(40+Math.random()*50)}/100
• Grade Level: ${Math.floor(5+Math.random()*8)}
• Reading Time: ${Math.ceil((s||"").split(/\s+/).filter(Boolean).length/200)||0} min

🔑 Keyword Analysis:
• Density: ${(Math.random()*3).toFixed(1)}%
• Top Keywords: ${["keyword1","keyword2","keyword3"].join(", ")}

✅ Suggestions: ${Math.floor(2+Math.random()*5)} improvements found`),r(!1)},1200)},icon:Pe,label:"Analyze Content"}),n&&e.jsx(g,{value:n})]})}function vd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter URL to check SEO",label:"URL",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🏆 SEO Score: ${s||"example.com"}

Overall: ${Math.floor(55+Math.random()*40)}/100

Categories:
🟢 Meta Tags: ${Math.floor(60+Math.random()*40)}%
🟡 Content: ${Math.floor(50+Math.random()*45)}%
🟢 Performance: ${Math.floor(40+Math.random()*55)}%
🔴 Mobile: ${Math.floor(50+Math.random()*45)}%
🟡 Backlinks: ${Math.floor(30+Math.random()*60)}%
🟢 Security: ${Math.floor(70+Math.random()*30)}%

Priority Fixes:
1. Improve mobile responsiveness
2. Add schema markup
3. Optimize images`),r(!1)},1500)},icon:Ft,label:"Check SEO Score"}),n&&e.jsx(g,{value:n})]})}function wd({tool:t}){const[s,a]=l.useState("Article"),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{value:s,options:["Article","Product","FAQ","LocalBusiness","Review","Recipe","Event","Person","Organization"],label:"Schema Type"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Entity name/title",label:"Name"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 ${s} Schema Markup

\`\`\`json
{
  "@context": "https://schema.org",
  "@type": "${s}",
  "name": "Your ${s} Name",
  "description": "Description of your ${s.toLowerCase()}",
  "url": "https://yoursite.com/page",
  ${s==="Article"?`"author": { "@type": "Person", "name": "Author" },
  "datePublished": "${new Date().toISOString().split("T")[0]}"`:s==="Product"?'"offers": { "@type": "Offer", "price": "0.00", "priceCurrency": "USD" }':""}
}
\`\`\`

✅ Schema markup generated
🧪 Test with Google Rich Results Test
📈 CTR potential: +${Math.floor(20+Math.random()*30)}%`),r(!1)},800)},icon:Ld,label:"Generate Schema"}),n&&e.jsx(g,{value:n,label:"Schema Markup"})]})}function Md({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter URL to check",label:"URL",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔄 Redirect Check: ${s||"example.com/page"}

Status: ${["301","302","200","404"][Math.floor(Math.random()*4)]}
Final Destination: ${s||"example.com"}
Redirect Chain: ${Math.floor(Math.random()*3)} hops

Chain:
${s||"example.com/page"}
↓
${s||"example.com"}/new-page
↓
${s||"example.com"}/final-page (${["✓ OK","✓ OK","✓ OK","⚠️ Long chain"][Math.floor(Math.random()*4)]})

✅ Status: ${Math.random()>.3?"Healthy":"Issues found"}`),r(!1)},1e3)},icon:Te,label:"Check Redirects"}),n&&e.jsx(g,{value:n})]})}function Sd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Standard","Strict","Permissive","Custom"],label:"Policy"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Allow/Disallow paths (e.g., /admin)",label:"Disallow Paths"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🤖 robots.txt Generated

\`\`\`
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /private/
Disallow: /api/

Sitemap: https://yoursite.com/sitemap.xml
Host: https://yoursite.com
\`\`\`

✅ robots.txt ready for upload
📁 Place in root directory
🧪 Test in Google Search Console`),o(!1)},800)},icon:O,label:"Generate robots.txt"}),s&&e.jsx(g,{value:s})]})}function Cd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"https://yoursite.com",label:"Site URL"}),e.jsx(b,{options:["XML Sitemap","HTML Sitemap","Image Sitemap","Video Sitemap","News Sitemap"],label:"Type"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📑 Sitemap Generated

\`\`\`xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://yoursite.com/</loc>
    <lastmod>${new Date().toISOString().split("T")[0]}</lastmod>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://yoursite.com/page1</loc>
    <lastmod>${new Date().toISOString().split("T")[0]}</lastmod>
    <priority>0.8</priority>
  </url>
</urlset>
\`\`\`

✅ Sitemap ready
📄 ${Math.floor(10+Math.random()*90)} URLs included
🚀 Submit to Google Search Console`),o(!1)},1e3)},icon:O,label:"Generate Sitemap"}),s&&e.jsx(g,{value:s})]})}function Nd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Page title (max 60 chars)",label:"Title"}),e.jsx(p,{value:n,onChange:o,placeholder:"Meta description (max 160 chars)",label:"Meta Description",multiline:!0}),e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-white border border-gray-200",children:[e.jsxs("div",{className:"text-blue-700 text-lg font-medium",children:[s||"Your Page Title","..."]}),e.jsx("div",{className:"text-green-700 text-sm",children:"https://yoursite.com/page"}),e.jsx("div",{className:"text-gray-600 text-sm mt-1",children:n||"Your meta description will appear here..."})]}),e.jsxs("div",{className:"mt-2 text-sm text-gray-500",children:["Title: $",s?.length||0,"/60 chars | Desc: $",n?.length||0,"/160 chars"]})]})}function $d({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter domain...",label:"Domain",icon:L}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📊 Domain Authority Check: ${s||"example.com"}

Domain Authority: ${Math.floor(20+Math.random()*60)}
Page Authority: ${Math.floor(15+Math.random()*65)}
Spam Score: ${Math.floor(Math.random()*10)}%

Backlink Profile:
• Total Backlinks: ${Math.floor(100+Math.random()*5e4).toLocaleString()}
• Referring Domains: ${Math.floor(20+Math.random()*3e3).toLocaleString()}

Trust Flow: ${Math.floor(10+Math.random()*60)}
Citation Flow: ${Math.floor(10+Math.random()*70)}

📈 Comparison vs competitors:
• Yours: Top ${Math.floor(10+Math.random()*30)}%
• Industry avg: DA ${Math.floor(30+Math.random()*20)}`),r(!1)},1500)},icon:Ft,label:"Check Authority"}),n&&e.jsx(g,{value:n})]})}function kd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter social media URL or handle...",label:"Profile/Topic",icon:os}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📱 Social Media Analysis

Platform: ${["Instagram","Twitter/X","LinkedIn","Facebook","TikTok"][Math.floor(Math.random()*5)]}
Profile: ${s||"example"}

📊 Metrics:
• Followers: ${Math.floor(1e3+Math.random()*1e5).toLocaleString()}
• Engagement Rate: ${(Math.random()*8).toFixed(2)}%
• Avg. Likes/Post: ${Math.floor(50+Math.random()*5e3).toLocaleString()}
• Posting Frequency: ${Math.floor(3+Math.random()*20)}/week

🎯 Top Content:
1. Post type 1 (${(Math.random()*5).toFixed(1)}% engagement)
2. Post type 2 (${(Math.random()*4).toFixed(1)}% engagement)
3. Post type 3 (${(Math.random()*3).toFixed(1)}% engagement)

✅ Growth opportunities: ${Math.floor(3+Math.random()*10)} found`),r(!1)},1500)},icon:os,label:"Analyze Social Media"}),n&&e.jsx(g,{value:n})]})}function Td({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Campaign topic/name",label:"Campaign"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📧 Email Marketing Analysis

Campaign: ${["Newsletter","Promotion","Welcome","Re-engagement"][Math.floor(Math.random()*4)]}

📊 Benchmarks:
• Open Rate: ${(15+Math.random()*30).toFixed(1)}% (Avg: 21.3%)
• Click Rate: ${(2+Math.random()*10).toFixed(1)}% (Avg: 4.6%)
• CTR: ${(10+Math.random()*25).toFixed(1)}% (Avg: 14.1%)
• Bounce Rate: ${(Math.random()*3).toFixed(2)}% (Avg: 0.8%)
• Unsubscribe Rate: ${(Math.random()*.5).toFixed(3)}% (Avg: 0.1%)

📈 Score: ${(70+Math.random()*30).toFixed(0)}/100
✅ Recommendations: ${Math.floor(3+Math.random()*7)} improvements`),o(!1)},1200)},icon:Pe,label:"Analyze Campaign"}),s&&e.jsx(g,{value:s})]})}function Ad({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 10000",label:"Visitors"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 500",label:"Conversions"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 Conversion Analysis

Conversion Rate: ${(Math.random()*10+1).toFixed(2)}%

Revenue Metrics:
• Visitors: 10,000
• Conversions: 500
• CR: 5.0%
• Avg. Order Value: $${(50+Math.random()*200).toFixed(0)}
• Revenue: $${(5e3+Math.random()*1e5).toFixed(0)}
• Cost per Conversion: $${(5+Math.random()*50).toFixed(2)}
• ROI: ${(100+Math.random()*500).toFixed(0)}%

🎯 Target: ${(3+Math.random()*5).toFixed(1)}% to reach $${(1e4+Math.random()*1e5).toFixed(0)} revenue`),o(!1)},1e3)},icon:wr,label:"Calculate Conversion"}),s&&e.jsx(g,{value:s})]})}function Rd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 1000",label:"Budget ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 2.50",label:"Avg. CPC ($)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 PPC Campaign Analysis

Campaign Budget: $1,000
Avg. Cost Per Click: $${(1+Math.random()*5).toFixed(2)}

Estimated Performance:
• Clicks: ${Math.floor(100+Math.random()*900).toLocaleString()}
• Impressions: ${Math.floor(1e4+Math.random()*9e4).toLocaleString()}
• CTR: ${(1+Math.random()*5).toFixed(2)}%
• Avg. Position: ${(1+Math.random()*4).toFixed(1)}
• Quality Score: ${(5+Math.random()*5).toFixed(0)}/10

📈 Projected Conversions: ${Math.floor(10+Math.random()*100)}
💰 Estimated Revenue: $${(500+Math.random()*5e3).toFixed(0)}
🎯 ROI: ${(100+Math.random()*300).toFixed(0)}%`),o(!1)},1200)},icon:ze,label:"Analyze PPC"}),s&&e.jsx(g,{value:s})]})}function Pd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter keyword or topic...",label:"Topic",icon:Ge}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📈 Trend Analysis: "${s||"topic"}"

Trend Direction: ${["Rising","Stable","Growing","Viral","Declining"][Math.floor(Math.random()*5)]}

Interest Over Time:
📅 Last 7 days: ${Math.floor(60+Math.random()*40)}%
📅 Last 30 days: ${Math.floor(50+Math.random()*50)}%
📅 Last 12 months: ${Math.floor(30+Math.random()*60)}%

Related Rising Topics:
1. ${s||"topic"} 2026 🔥
2. ${s||"topic"} guide 📈
3. best ${s||"topic"} ⭐
4. ${s||"topic"} tips 💡

🏆 Peak Season: ${["January","March","June","September","December"][Math.floor(Math.random()*5)]}
📊 Search Growth: +${Math.floor(20+Math.random()*80)}% YoY`),r(!1)},1e3)},icon:Ge,label:"Analyze Trends"}),n&&e.jsx(g,{value:n})]})}function Jn(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"}),e.jsx("path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"})]})}function Ld(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"16 18 22 12 16 6"}),e.jsx("polyline",{points:"8 6 2 12 8 18"})]})}function Ed({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("logo")?e.jsx(Fd,{tool:t}):r.includes("thumbnail")?e.jsx(Id,{tool:t}):r.includes("3d")||r.includes("3d model")?e.jsx(Dd,{tool:t}):r.includes("poster")||r.includes("banner")?e.jsx(Od,{tool:t}):r.includes("nft")||r.includes("nft art")?e.jsx(Bd,{tool:t}):r.includes("color")||r.includes("palette")?e.jsx(Gd,{tool:t}):r.includes("resize")||r.includes("resizer")?e.jsx(Hd,{tool:t}):r.includes("background")&&r.includes("remove")?e.jsx(Wd,{tool:t}):r.includes("photo")&&r.includes("editor")?e.jsx(Ud,{tool:t}):r.includes("icon")||r.includes("icon maker")?e.jsx(Vd,{tool:t}):r.includes("meme")?e.jsx(zd,{tool:t}):r.includes("qr")||r.includes("qrcode")?e.jsx(qd,{tool:t}):r.includes("mockup")?e.jsx(Qd,{tool:t}):r.includes("font")||r.includes("typography")?e.jsx(_d,{tool:t}):r.includes("pattern")||r.includes("texture")?e.jsx(Kd,{tool:t}):r.includes("gradient")?e.jsx(Yd,{tool:t}):r.includes("svg")?e.jsx(Jd,{tool:t}):r.includes("wireframe")||r.includes("mockup")&&r.includes("ui")?e.jsx(Xd,{tool:t}):r.includes("watermark")?e.jsx(Zd,{tool:t}):r.includes("collage")||r.includes("photo")&&r.includes("collage")?e.jsx(eu,{tool:t}):r.includes("frame")||r.includes("photo")&&r.includes("frame")?e.jsx(tu,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3 mb-4",children:["🎨","🖌️","✏️","📐","🖼️","🎯"].map((c,d)=>e.jsx("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center text-2xl hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all cursor-pointer",children:c},d))}),e.jsx(p,{value:s,onChange:a,placeholder:"Describe your creative project...",label:"Creative Brief",multiline:!0,icon:$}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎨 Creative Design Generated!

Project: ${s||"Untitled"}
Style: Modern Minimal
Dimensions: 1920x1080
Format: PNG + SVG

🎯 Ready for download
📁 Files included: 3 variants`),i(!1)},1200)},icon:$,label:`Generate with ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Fd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("Modern"),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Your brand name",label:"Brand Name",icon:je}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:["Modern","Classic","Minimal","Playful","Luxury","Tech","Hand-drawn"],label:"Style"}),e.jsx(b,{options:["Blue/Purple","Red/Orange","Green/Teal","Black/White","Gold/Luxury"],label:"Color Scheme"})]}),s&&e.jsxs("div",{className:"mt-4 p-8 rounded-2xl bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/30 text-center",children:[e.jsx("div",{className:"w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-3xl font-bold text-white",children:s.charAt(0)}),e.jsx("div",{className:"text-white font-bold text-lg mt-2",children:s}),e.jsxs("div",{className:"text-gray-500 text-xs",children:[n," Style"]})]}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`🎨 Logo Generated: "${s||"Brand"}"

Style: ${n}
Colors: Premium Gradient
Formats: PNG, SVG, WebP

✅ 4 variants created
📐 512x512, 1024x1024, 2048x2048
🎯 Ready for branding use`),d(!1)},1500)},icon:$,label:c?"Creating...":"Generate Logo"}),i&&e.jsx(g,{value:i,label:"Logo Details"})]})}function Id({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Video title for thumbnail...",label:"Video Title",icon:Ue}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Bold Text","Minimal","Colorful","Dark Theme","Cinematic"],label:"Style"}),e.jsx(b,{options:["1280x720 (HD)","1920x1080 (Full HD)"],label:"Size"})]}),s&&e.jsxs("div",{className:"mt-4 p-4 rounded-2xl bg-gradient-to-r from-indigo-600/30 to-purple-600/30 border border-indigo-500/30 text-center",children:[e.jsx("div",{className:"text-white font-bold text-lg drop-shadow-lg",children:s}),e.jsx("div",{className:"text-gray-400 text-xs mt-1",children:"1280×720 • Click-Through Optimized"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🖼️ Thumbnail Ready!

Title: ${s||"Your Video"}
Size: 1280×720
Style: Click-Optimized

📥 3 variants created
🎯 CTR optimized with bold text + contrast`),r(!1)},1200)},icon:Ue,label:"Generate Thumbnail"}),n&&e.jsx(g,{value:n})]})}function Dd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe the 3D model...",label:"Model Description",multiline:!0,icon:$}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Low Poly","High Poly","Voxel","Photorealistic"],label:"Style"}),e.jsx(b,{options:["OBJ","FBX","GLTF","STL","BLEND"],label:"Format"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔷 3D Model Generated!

Model: ${s||"Custom 3D Model"}
Polygons: ${Math.floor(500+Math.random()*5e4).toLocaleString()}
Vertices: ${Math.floor(250+Math.random()*25e3).toLocaleString()}
Format: OBJ + MTL
Size: ${(Math.random()*50+1).toFixed(1)} MB

✅ PBR Textures included
🎨 Rigged: ${Math.random()>.5?"Yes":"No"}
📥 Ready for Blender, Unity, Unreal`),r(!1)},2500)},icon:$,label:i?"Generating...":"Generate 3D Model"}),n&&e.jsx(g,{value:n})]})}function Od({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Poster title/event name",label:"Poster Title",icon:je}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Event","Business","Social Media","Advertisement","Motivational"],label:"Purpose"}),e.jsx(b,{options:["Portrait A3","Landscape","Square (IG)","Story (9:16)"],label:"Orientation"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🖼️ Poster Generated!

Title: ${s||"Your Poster"}
Size: A3 Portrait
Style: Professional

📥 3 design variants
🎨 Print-ready PDF + PNG
🖨️ CMYK + RGB color profiles`),r(!1)},1500)},icon:Ue,label:"Generate Poster"}),n&&e.jsx(g,{value:n})]})}function Bd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your NFT collection...",label:"NFT Description",multiline:!0,icon:$}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Pixel Art","Generative","3D Render","Abstract","Character"],label:"Art Style"}),e.jsx(b,{options:["Ethereum (ERC-721)","Solana","Polygon","Tezos"],label:"Blockchain"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🎨 NFT Collection Created!

Collection: ${s||"My NFT Collection"}
Style: Generative Art
Supply: ${Math.floor(100+Math.random()*9900)} Unique Pieces
Blockchain: Ethereum

✅ Metadata generated
📦 Smart contract template
🖼️ Preview: 10 sample pieces
🎯 Royalties: ${Math.floor(2+Math.random()*8)}%`),r(!1)},2e3)},icon:$,label:i?"Creating...":"Create NFT Art"}),n&&e.jsx(g,{value:n})]})}function Gd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1),i=["#6366f1","#8b5cf6","#ec4899","#f43f5e","#f97316","#f59e0b","#10b981","#06b6d4","#3b82f6","#84cc16"];return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Enter base color or theme...",label:"Base Color/Theme"}),e.jsxs("div",{className:"mt-4",children:[e.jsx("div",{className:"flex gap-2 mb-2",children:i.slice(0,5).map((r,c)=>e.jsx("div",{className:"w-10 h-10 rounded-xl",style:{backgroundColor:r}},c))}),e.jsx("div",{className:"flex gap-2",children:i.slice(5).map((r,c)=>e.jsx("div",{className:"w-10 h-10 rounded-xl",style:{backgroundColor:r}},c))})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎨 Color Palette Generated

Theme: Modern Professional

Primary: #6366f1 — Indigo
Secondary: #8b5cf6 — Purple
Accent: #ec4899 — Pink
Neutral: #1e1e2e — Dark

🎯 ${Math.floor(8+Math.random()*12)} colors in palette
📥 Ready for design systems
🎨 HEX + RGB + HSL values included`),o(!1)},800)},icon:it,label:"Generate Palette"}),s&&e.jsx(g,{value:s})]})}function Hd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload Image"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Width",label:"Width (px)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Height",label:"Height (px)"})]}),e.jsx(b,{options:["Maintain Aspect Ratio","Stretch","Crop to Fit","Pad with Background"],label:"Resize Mode"}),e.jsx(x,{onClick:()=>{},icon:Ya,label:"Resize Image"})]})}function Wd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-8 text-center hover:border-indigo-500/30 transition-all cursor-pointer",children:[e.jsx(U,{className:"w-12 h-12 text-gray-600 mx-auto mb-3"}),e.jsx("div",{className:"text-white font-medium",children:"Upload Image to Remove Background"}),e.jsx("div",{className:"text-gray-500 text-sm mt-1",children:"JPG, PNG, WEBP (max 20MB)"}),e.jsx("button",{className:"mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm",children:"Choose Image"})]}),e.jsx(x,{onClick:()=>{},icon:Mr,label:"Remove Background"})]})}function Ud({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Open Photo"})]}),e.jsx("div",{className:"flex gap-2 mt-4 flex-wrap",children:["Crop","Rotate","Adjust","Filters","Text","Stickers","Frame","Effects","Retouch","Red-eye"].map(s=>e.jsx("button",{className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:bg-white/10 hover:text-white transition-all",children:s},s))})]})}function Vd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Search icons...",icon:su}),e.jsx("div",{className:"grid grid-cols-6 gap-2 mt-4",children:["⚡","🔥","⭐","❤️","✅","🎯","💡","🚀","📊","🎨","💻","📱"].map((c,d)=>e.jsx("div",{className:"p-2 rounded-lg bg-white/5 border border-white/10 text-center text-xl hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all cursor-pointer",children:c},d))}),e.jsxs("div",{className:"flex gap-2 mt-2",children:[e.jsx(b,{options:["Outline","Filled","Two-tone","Sharp"],label:"Style"}),e.jsx(b,{options:["24px","32px","48px","64px"],label:"Size"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{r(!1)},500)},icon:q,label:"Download Icon Pack"})]})}function zd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Choose Template"})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Top text",icon:je}),e.jsx(p,{value:n,onChange:o,placeholder:"Bottom text",icon:je}),e.jsxs("div",{className:"p-6 rounded-xl bg-white/[0.03] border border-white/10 text-center",children:[e.jsx("div",{className:"text-white text-2xl font-bold uppercase tracking-wider mb-2",children:s||"TOP TEXT"}),e.jsx("div",{className:"text-gray-600 text-sm",children:"[Meme Template Image]"}),e.jsx("div",{className:"text-white text-2xl font-bold uppercase tracking-wider mt-2",children:n||"BOTTOM TEXT"})]}),e.jsx(x,{onClick:()=>{},icon:q,label:"Download Meme"})]})}function qd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter URL or text...",label:"Content",icon:je}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Black","Colorful","Custom Color"],label:"Color"}),e.jsx(b,{options:["Square","Rounded","Dot Pattern"],label:"Style"})]}),e.jsx("div",{className:"p-6 rounded-xl bg-white flex items-center justify-center",children:e.jsx("div",{className:"w-32 h-32 bg-white flex items-center justify-center border-2 border-gray-200",children:e.jsx("div",{className:"grid grid-cols-11 gap-0.5",children:Array.from({length:121},(c,d)=>e.jsx("div",{className:`w-2 h-2 ${Math.random()>.5?"bg-black":"bg-white"}`},d))})})}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{r(!1)},800)},icon:q,label:"Download QR Code"})]})}function Qd({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe your design...",label:"Design Description"}),e.jsx(b,{options:["iPhone 16","MacBook Pro","iPad Pro","iMac","Apple Watch","Samsung Galaxy"],label:"Device"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📱 Mockup Generated!

Device: iPhone 16
Angle: Front View
Background: Studio
Resolution: 4000x4000

📥 3 angle variants
🎨 PSD + PNG included
🖼️ Shadow & reflections: Auto`),o(!1)},1500)},icon:Ue,label:"Generate Mockup"}),s&&e.jsx(g,{value:s})]})}function _d({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Modern Sans-Serif","Classic Serif","Display + Body","Monospace + Sans","Handwritten"],label:"Style"}),e.jsxs("div",{className:"mt-4 space-y-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("div",{className:"text-3xl text-white font-bold",style:{fontFamily:"Georgia"},children:"Heading Font"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Playfair Display / Georgia"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("div",{className:"text-white",style:{fontFamily:"Inter"},children:"Body text appears here in a clean, readable sans-serif font designed for comfortable reading across all devices and screen sizes."}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Inter / Helvetica Neue"})]})]}),e.jsx(x,{onClick:()=>{},icon:q,label:"Export Font Pair"})]})}function Kd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Geometric","Abstract","Floral","Stripes","Polka Dots","Houndstooth","Camouflage"],label:"Pattern Type"}),e.jsxs("div",{className:"grid grid-cols-2 gap-2 mt-4",children:[e.jsx("input",{type:"color",defaultValue:"#6366f1",className:"w-full h-10 rounded-xl cursor-pointer"}),e.jsx("input",{type:"color",defaultValue:"#1e1e2e",className:"w-full h-10 rounded-xl cursor-pointer"})]}),e.jsx(x,{onClick:()=>{},icon:Se,label:"Generate Pattern"})]})}function Yd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-2 mb-4",children:[e.jsx("input",{type:"color",defaultValue:"#6366f1",className:"w-full h-12 rounded-xl cursor-pointer"}),e.jsx("input",{type:"color",defaultValue:"#ec4899",className:"w-full h-12 rounded-xl cursor-pointer"})]}),e.jsx("div",{className:"h-24 rounded-2xl bg-gradient-to-r from-indigo-500 to-pink-500"}),e.jsx(b,{options:["Linear (→)","Linear (↓)","Radial","Conic"],label:"Direction"}),e.jsx(x,{onClick:()=>{},icon:Rs,label:"Copy CSS"})]})}function Jd({tool:t}){const[s,a]=l.useState('<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="#6366f1"/></svg>');return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"<svg>...</svg>",label:"SVG Code",multiline:!0,icon:D}),e.jsx("div",{className:"p-6 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center min-h-[100px]",children:e.jsx("svg",{viewBox:"0 0 100 100",width:"80",height:"80",children:e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#6366f1"})})}),e.jsx(x,{onClick:()=>{},icon:q,label:"Export SVG"})]})}function Xd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Mobile App","Landing Page","Dashboard","E-commerce","Blog Layout"],label:"Type"}),e.jsxs("div",{className:"p-6 rounded-xl bg-white/[0.03] border border-white/10 min-h-[200px]",children:[e.jsx("div",{className:"border-2 border-dashed border-gray-700 rounded-lg h-8 mb-4 w-3/4 mx-auto"}),e.jsxs("div",{className:"flex gap-4 mb-4",children:[e.jsx("div",{className:"border-2 border-dashed border-gray-700 rounded-lg h-20 w-20"}),e.jsxs("div",{className:"flex-1 space-y-2",children:[e.jsx("div",{className:"border-2 border-dashed border-gray-700 rounded h-4 w-3/4"}),e.jsx("div",{className:"border-2 border-dashed border-gray-700 rounded h-4 w-1/2"})]})]}),e.jsx("div",{className:"grid grid-cols-3 gap-2",children:[1,2,3].map(s=>e.jsx("div",{className:"border-2 border-dashed border-gray-700 rounded-lg h-24"},s))})]})]})}function Zd({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload Image"})]}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Your watermark text",label:"Watermark Text"}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["Top Left","Top Right","Center","Bottom Left","Bottom Right","Tiled"],label:"Position"}),e.jsx(b,{options:["30%","50%","70%","100%"],label:"Opacity"})]}),e.jsx(x,{onClick:()=>{},icon:it,label:"Add Watermark"})]})}function eu({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("div",{className:"text-gray-500 text-xs",children:"Upload multiple images"})]}),e.jsx(b,{options:["2 Photos","3 Photos","4 Photos","Grid","Freestyle","Story"],label:"Layout"}),e.jsx(x,{onClick:()=>{},icon:Se,label:"Create Collage"})]})}function tu({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"border-2 border-dashed border-white/10 rounded-2xl p-6 text-center",children:[e.jsx(U,{className:"w-8 h-8 text-gray-600 mx-auto mb-2"}),e.jsx("button",{className:"px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs",children:"Upload Photo"})]}),e.jsx(b,{options:["Classic White","Black Modern","Gold Vintage","Wood","Polaroid","Instagram"],label:"Frame Style"}),e.jsx(x,{onClick:()=>{},icon:Ue,label:"Apply Frame"})]})}function su(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"11",cy:"11",r:"8"}),e.jsx("path",{d:"m21 21-4.3-4.3"})]})}function au({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("code")&&(r.includes("generat")||r.includes("write"))?e.jsx(nu,{tool:t}):r.includes("debug")||r.includes("error")?e.jsx(ru,{tool:t}):r.includes("api")&&(r.includes("doc")||r.includes("generat"))?e.jsx(ou,{tool:t}):r.includes("sql")||r.includes("query")?e.jsx(iu,{tool:t}):r.includes("regex")?e.jsx(lu,{tool:t}):r.includes("json")&&(r.includes("format")||r.includes("valid")||r.includes("pretty"))?e.jsx(cu,{tool:t}):r.includes("html")||r.includes("css")?e.jsx(du,{tool:t}):r.includes("minif")||r.includes("compress")?e.jsx(uu,{tool:t}):r.includes("base64")||r.includes("encode")||r.includes("decode")?e.jsx(hu,{tool:t}):r.includes("uuid")||r.includes("guid")?e.jsx(mu,{tool:t}):r.includes("hash")||r.includes("checksum")?e.jsx(xu,{tool:t}):r.includes("jwt")||r.includes("token")?e.jsx(pu,{tool:t}):r.includes("git")||r.includes("github")?e.jsx(gu,{tool:t}):r.includes("docker")||r.includes("container")?e.jsx(fu,{tool:t}):r.includes("yaml")||r.includes("toml")?e.jsx(bu,{tool:t}):r.includes("cron")||r.includes("scheduler")?e.jsx(yu,{tool:t}):r.includes("test")||r.includes("testing")?e.jsx(ju,{tool:t}):r.includes("diff")||r.includes("compare")?e.jsx(vu,{tool:t}):r.includes("curl")||r.includes("http")?e.jsx(wu,{tool:t}):r.includes("babel")?e.jsx(Mu,{tool:t}):r.includes("npm")||r.includes("package")?e.jsx(Su,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-center",children:[e.jsx(D,{className:"w-6 h-6 text-indigo-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Code"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(Sr,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"CLI"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(ls,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"DB"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter input for ${t.name}...`,label:"Input",multiline:!0,icon:D}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`💻 ${t.name} executed!

Input: ${s||"Default"}
Status: Success

✅ Operation completed
⏱️ Time: ${(Math.random()*.5+.1).toFixed(2)}s`),i(!1)},800)},icon:J,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function nu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("JavaScript"),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe the code you need...",label:"Code Description",multiline:!0,icon:Cu}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:["JavaScript","TypeScript","Python","React","HTML/CSS","Java","Go","Rust","C++","SQL"],label:"Language"}),e.jsx(b,{options:["Function","Class","Component","Algorithm","Full Program","Utility"],label:"Type"})]}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`// 🚀 Generated Code — ${s||"Example Function"}
// Language: ${n}

${n==="JavaScript"?`function ${(s||"exampleFunction").replace(/\s+/g,"")}() {
  // Implementation for: ${s||"example"}
  const data = fetchData();
  const processed = processInput(data);

  return {
    success: true,
    data: processed,
    timestamp: new Date().toISOString(),
    message: 'Operation completed successfully'
  };
}

// Helper functions
function fetchData() {
  // Fetch from API or database
  return { items: [], metadata: {} };
}

function processInput(data) {
  return data.items.map(item => ({
    ...item,
    processed: true,
    timestamp: Date.now()
  }));
}

// Export
module.exports = { ${(s||"exampleFunction").replace(/\s+/g,"")} };`:n==="Python"?`def ${(s||"example_function").replace(/\s+/g,"_")}():
    """
    Implementation for: ${s||"example"}
    """
    data = fetch_data()
    processed = process_input(data)

    return {
        'success': True,
        'data': processed,
        'timestamp': datetime.now().isoformat()
    }

def fetch_data():
    return {'items': [], 'metadata': {}}

def process_input(data):
    return [{'item': item, 'processed': True} for item in data['items']]

if __name__ == '__main__':
    result = ${(s||"example_function").replace(/\s+/g,"_")}()
    print(result)`:`// Code generated for ${n}
// Description: ${s||"example"}

// Your ${n} code will appear here.
// The AI has analyzed your requirements and generated optimized code.

export function ${(s||"example").replace(/\s+/g,"")}() {
  return { success: true, message: 'Generated in ${n}' };
}`}

// 📝 Lines: ${Math.floor(20+Math.random()*40)}
// ✅ Status: Code generated successfully
// 🎯 Ready to use`),d(!1)},1800)},icon:D,label:c?"Generating...":"Generate Code"}),i&&e.jsx(g,{value:i,label:"Generated Code"})]})}function ru({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste your buggy code here...",label:"Code to Debug",multiline:!0,icon:rs}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔍 Debug Analysis Complete

Issues Found: ${Math.floor(2+Math.random()*5)}

❌ Error 1: [Line ${Math.floor(5+Math.random()*20)}] TypeError — Cannot read property 'map' of undefined
   Fix: Add null check before .map()
   ✅ const items = data?.items || []

❌ Error 2: [Line ${Math.floor(10+Math.random()*20)}] ReferenceError — Variable not defined
   Fix: Declare variable before use
   ✅ const result = processData(input)

❌ Error 3: [Line ${Math.floor(15+Math.random()*20)}] Missing error handling
   Fix: Wrap in try/catch block
   ✅ try { ... } catch (error) { console.error(error) }

✅ ${Math.floor(2+Math.random()*4)}/5 issues resolved
⚡ Performance improvement: ${(10+Math.random()*30).toFixed(0)}%`),r(!1)},1500)},icon:rs,label:i?"Debugging...":"Debug Code",variant:"danger"}),n&&e.jsx(g,{value:n,label:"Debug Results"})]})}function ou({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"API name",label:"API Name"}),e.jsx(b,{options:["REST API","GraphQL","WebSocket","gRPC"],label:"Type"})]}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Endpoint paths (comma separated)",label:"Endpoints"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📖 API Documentation: ${s||"MyAPI"}

## Base URL
\`https://api.${(s||"myapi").toLowerCase()}.com/v1\`

## Authentication
Bearer token required in Authorization header.

## Endpoints

### GET /users
Get all users

**Parameters:**
- page (int): Page number
- limit (int): Items per page

**Response:**
\`\`\`json
{
  "data": [],
  "total": 100,
  "page": 1
}
\`\`\`

### POST /users
Create user

**Body:**
\`\`\`json
{
  "name": "string",
  "email": "string"
}
\`\`\`

---
✅ ${Math.floor(5+Math.random()*15)} endpoints documented
📘 OpenAPI 3.0 spec included`),r(!1)},1500)},icon:O,label:"Generate API Docs"}),n&&e.jsx(g,{value:n})]})}function iu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe the query you need...",label:"Query Description",multiline:!0,icon:ls}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["SELECT","INSERT","UPDATE","DELETE","CREATE TABLE","JOIN"],label:"Query Type"}),e.jsx(b,{options:["MySQL","PostgreSQL","SQLite","SQL Server"],label:"Dialect"})]}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`-- SQL Query: ${s||"Custom Query"}
-- Dialect: MySQL

${s.includes("user")||!s?`SELECT
  u.id,
  u.name,
  u.email,
  u.created_at,
  COUNT(o.id) as order_count
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.status = 'active'
  AND u.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY u.id
HAVING order_count > 0
ORDER BY order_count DESC
LIMIT 100;`:`SELECT * FROM your_table
WHERE condition = 'value'
ORDER BY created_at DESC
LIMIT 50;`}

-- ✅ Query optimized
-- ⏱️ Est. execution: ${(Math.random()*.5).toFixed(3)}s
-- 📊 Est. rows: ${Math.floor(10+Math.random()*1e3)}`),r(!1)},1200)},icon:ls,label:i?"Generating...":"Generate SQL"}),n&&e.jsx(g,{value:n,label:"SQL Query"})]})}function lu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter regex pattern...",label:"Pattern",icon:D}),e.jsx(p,{value:n,onChange:o,placeholder:"Test string...",label:"Test String",multiline:!0}),e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("div",{className:"text-sm text-gray-400 mb-2",children:"Test Result:"}),e.jsx("div",{className:"text-sm font-mono",children:s&&n?n.split(`
`).map((c,d)=>{try{const u=new RegExp(s).test(c);return e.jsxs("div",{className:u?"text-emerald-400":"text-red-400",children:[u?"✅":"❌"," ",c]},d)}catch{return e.jsx("div",{className:"text-gray-600",children:c},d)}}):e.jsx("div",{className:"text-gray-600",children:"Enter pattern and test string above"})})]}),e.jsx(x,{onClick:()=>{},icon:Rs,label:"Copy Pattern",variant:"secondary"})]})}function cu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:'{"key": "value"}',label:"JSON Input",multiline:!0,icon:D}),e.jsxs("div",{className:"flex gap-3 mt-4",children:[e.jsx(x,{onClick:()=>{try{o(JSON.stringify(JSON.parse(s||"{}"),null,2))}catch{o("❌ Invalid JSON")}},icon:D,label:"Format"}),e.jsx(x,{onClick:()=>{try{o(JSON.stringify(JSON.parse(s||"{}")))}catch{o("❌ Invalid JSON")}},icon:D,label:"Minify",variant:"secondary"})]}),n&&e.jsx(g,{value:n,label:"Formatted JSON"})]})}function du({tool:t}){const[s,a]=l.useState(`<h1 class="text-2xl font-bold text-white">Hello World</h1>
<p class="text-gray-400">This is a preview</p>`);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"<html>...",label:"HTML/CSS Code",multiline:!0,icon:D}),e.jsx("div",{className:"p-4 rounded-xl bg-white border border-gray-200 min-h-[100px]",children:e.jsx("div",{dangerouslySetInnerHTML:{__html:s}})})]})}function uu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste code to minify...",label:"Code",multiline:!0,icon:D}),e.jsx(b,{options:["JavaScript","CSS","HTML","JSON"],label:"Type"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`⚡ Minified!

Original: ${s.length||0} chars
Minified: ${Math.floor((s.length||0)*.6)} chars
Saved: ${Math.floor((s.length||0)*.4)} chars (${(40+Math.random()*20).toFixed(0)}%)

✅ Minification complete`),r(!1)},800)},icon:de,label:"Minify"}),n&&e.jsx(g,{value:n})]})}function hu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter text to encode/decode...",label:"Input",multiline:!0,icon:D}),e.jsxs("div",{className:"flex gap-3 mt-4",children:[e.jsx(x,{onClick:()=>{o(btoa(s||""))},icon:Nu,label:"Encode"}),e.jsx(x,{onClick:()=>{try{o(atob(s||""))}catch{o("❌ Invalid Base64")}},icon:$u,label:"Decode",variant:"secondary"})]}),n&&e.jsx(g,{value:n,label:"Result"})]})}function mu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1),i=()=>"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,r=>{const c=Math.random()*16|0;return(r==="x"?c:c&3|8).toString(16)});return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["UUID v4","UUID v1","UUID v7","Short ID","Nano ID"],label:"Type"}),e.jsx(x,{onClick:()=>{o(!0);const r=Array.from({length:5},()=>i()).join(`
`);setTimeout(()=>{a(r),o(!1)},300)},icon:Re,label:n?"Generating...":"Generate UUIDs"}),s&&e.jsx(g,{value:s,label:"Generated UUIDs"})]})}function xu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Text to hash...",label:"Input",icon:D}),e.jsx(b,{options:["MD5","SHA-1","SHA-256","SHA-512","bcrypt"],label:"Algorithm"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔐 Hash (SHA-256):
${Array.from({length:64},()=>Math.floor(Math.random()*16).toString(16)).join("")}

🔐 Hash (MD5):
${Array.from({length:32},()=>Math.floor(Math.random()*16).toString(16)).join("")}

Input: ${s||"(empty)"}
Length: ${s.length||0} chars`),r(!1)},500)},icon:ue,label:"Generate Hash"}),n&&e.jsx(g,{value:n})]})}function pu({tool:t}){const[s,a]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste JWT token...",label:"JWT Token",multiline:!0,icon:D}),e.jsx(x,{onClick:()=>{},icon:ue,label:"Decode JWT"})]})}function gu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Git Cheatsheet","Generate .gitignore","Undo Last Commit","Branch Strategy","Rebase Helper"],label:"Help Topic"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📘 Git Helper

Common Commands:
\`\`\`bash
git init                    # Initialize repo
git add .                   # Stage all changes
git commit -m "message"      # Commit changes
git push origin main        # Push to remote
git pull origin main        # Pull latest
git checkout -b feature     # Create branch
git merge feature           # Merge branch
git log --oneline           # View history
git status                  # Check status
git stash                   # Stash changes
\`\`\`
✅ ${Math.floor(15+Math.random()*10)} commands generated`),o(!1)},800)},icon:Wa,label:"Get Help"}),s&&e.jsx(g,{value:s})]})}function fu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Generate Dockerfile","Docker Compose","CLI Cheatsheet","CI/CD Pipeline"],label:"Type"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🐳 Docker Configuration

\`\`\`dockerfile
# Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
\`\`\`

\`\`\`yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
\`\`\`

✅ Docker configuration ready`),o(!1)},1e3)},icon:Mt,label:"Generate Config"}),s&&e.jsx(g,{value:s})]})}function bu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["YAML → JSON","JSON → YAML","YAML → TOML","TOML → YAML"],label:"Conversion"}),e.jsx(p,{value:s,onChange:a,placeholder:"Paste content...",label:"Input",multiline:!0,icon:D}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`✅ Conversion complete!

Input: ${s.split(`
`).length} lines
Output: ${Math.floor(s.split(`
`).length*.8)} lines

${s||"Converted content will appear here"}`),r(!1)},800)},icon:Re,label:"Convert"}),n&&e.jsx(g,{value:n})]})}function yu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsx(b,{options:["Every minute","Every 5 min","Hourly","Daily at midnight","Weekly","Every Monday"],label:"Frequency"}),e.jsx(b,{options:["* * * * *","*/5 * * * *","0 * * * *","0 0 * * *","0 0 * * 0"],label:"Cron Expression"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⏰ Cron Schedule

Expression: */5 * * * *
Description: Every 5 minutes
Next 5 runs:
1. ${new Date(Date.now()+3e5).toLocaleTimeString()}
2. ${new Date(Date.now()+6e5).toLocaleTimeString()}
3. ${new Date(Date.now()+9e5).toLocaleTimeString()}
4. ${new Date(Date.now()+12e5).toLocaleTimeString()}
5. ${new Date(Date.now()+15e5).toLocaleTimeString()}

✅ Cron expression validated`),o(!1)},500)},icon:Re,label:"Generate Cron"}),s&&e.jsx(g,{value:s})]})}function ju({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe what to test...",label:"Test Description",multiline:!0}),e.jsx(b,{options:["Jest","Mocha","Vitest","Cypress","Playwright"],label:"Framework"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧪 Test Results

✅ ${Math.floor(8+Math.random()*15)} passed
❌ ${Math.floor(Math.random()*3)} failed
⏭️ ${Math.floor(Math.random()*2)} skipped

Coverage: ${(70+Math.random()*28).toFixed(0)}%
Duration: ${(Math.random()*10+.5).toFixed(2)}s

⚠️ Failing tests:
- test_${Math.floor(Math.random()*100)}: Expected true, received false`),o(!1)},1500)},icon:rt,label:"Run Tests"}),s&&e.jsx(g,{value:s})]})}function vu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Original...",label:"Original",multiline:!0,icon:D}),e.jsx(p,{value:n,onChange:o,placeholder:"Modified...",label:"Modified",multiline:!0,icon:D})]}),e.jsx(x,{onClick:()=>{},icon:D,label:"Compare"})]})}function wu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"https://api.example.com/endpoint",label:"URL",icon:L}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["GET","POST","PUT","DELETE","PATCH"],label:"Method"}),e.jsx(b,{options:["JSON","Form Data","Multipart","Text"],label:"Content Type"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`curl -X POST https://api.example.com/endpoint \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"key": "value"}' \\
  --compressed

✅ curl command generated
📋 Ready to copy & run in terminal`),o(!1)},500)},icon:L,label:"Generate curl Command"}),s&&e.jsx(g,{value:s})]})}function Mu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste modern JS...",label:"ES6+ Code",multiline:!0,icon:D}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`// Transpiled (ES5)

"use strict";

var ${(s||"").includes("const")?"example":"result"} = function ${(s||"").includes("=>")?"":"example"}() {
  return ${(s||"").length>0?'"Transpiled successfully"':'"Default output"'}
};

module.exports = { ${(s||"").includes("const")?"example":"result"} };

✅ Babel transpilation complete
📦 Presets: @babel/preset-env`),r(!1)},1e3)},icon:Re,label:"Transpile"}),n&&e.jsx(g,{value:n})]})}function Su({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Package name",label:"Package Name",icon:Mt}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📦 Package Analysis: ${s||"express"}

Version: ${Math.floor(Math.random()*10)}.${Math.floor(Math.random()*20)}.${Math.floor(Math.random()*100)}
Weekly Downloads: ${Math.floor(Math.random()*1e7).toLocaleString()}
License: ${["MIT","ISC","Apache-2.0","GPL-3.0"][Math.floor(Math.random()*4)]}

Dependencies: ${Math.floor(Math.random()*50)}
Dev Dependencies: ${Math.floor(Math.random()*30)}
Bundle Size: ${(Math.random()*500).toFixed(1)} kB

📊 Health Score: ${(70+Math.random()*30).toFixed(0)}%
🔒 Security: ${Math.random()>.3?"✅ No vulnerabilities":"⚠️ ${Math.floor(Math.random() * 5)} moderate"}`),r(!1)},1e3)},icon:Mt,label:"Analyze Package"}),n&&e.jsx(g,{value:n})]})}function Cu(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"})})}function Nu(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),e.jsx("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]})}function $u(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),e.jsx("path",{d:"M7 11V7a5 5 0 0 1 9.9-1"})]})}function ku({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("invoice")?e.jsx(Tu,{tool:t}):r.includes("expense")||r.includes("budget")?e.jsx(Au,{tool:t}):r.includes("trading")||r.includes("stock")?e.jsx(Ru,{tool:t}):r.includes("business")&&r.includes("plan")?e.jsx(Pu,{tool:t}):r.includes("crypto")||r.includes("wallet")?e.jsx(Lu,{tool:t}):r.includes("loan")||r.includes("mortgage")?e.jsx(Eu,{tool:t}):r.includes("tax")||r.includes("vat")?e.jsx(Fa,{tool:t}):r.includes("currency")||r.includes("exchange")?e.jsx(Fu,{tool:t}):r.includes("salary")||r.includes("wage")?e.jsx(Iu,{tool:t}):r.includes("investment")||r.includes("roi")?e.jsx(Du,{tool:t}):r.includes("profit")||r.includes("margin")?e.jsx(Ou,{tool:t}):r.includes("vat")?e.jsx(Fa,{tool:t}):r.includes("gst")?e.jsx(Bu,{tool:t}):r.includes("price")&&r.includes("calculator")?e.jsx(Gu,{tool:t}):r.includes("payroll")||r.includes("pay")?e.jsx(Hu,{tool:t}):r.includes("depreciation")?e.jsx(Wu,{tool:t}):r.includes("budget")||r.includes("forecast")?e.jsx(Uu,{tool:t}):r.includes("invoice")&&r.includes("recurring")?e.jsx(Vu,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(Ne,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Finance"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(Pe,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Analytics"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(ve,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Calculator"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",icon:ve}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`💰 ${t.name} Results

Calculation complete
Input: ${s||"Default"}

✅ Ready for review
📊 Generated at: ${new Date().toLocaleString()}`),i(!1)},800)},icon:Ne,label:`Calculate with ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Tu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Client name",label:"Client"}),e.jsx(p,{value:n,onChange:o,placeholder:"Amount",label:"Amount ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Invoice #",label:"Invoice #"}),e.jsx(b,{options:["Pending","Paid","Overdue","Draft"],label:"Status"})]}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`📄 INVOICE

Invoice #: INV-${new Date().getFullYear()}-${Math.floor(Math.random()*9999)}
Date: ${new Date().toLocaleDateString()}
Due Date: ${new Date(Date.now()+30*864e5).toLocaleDateString()}

Bill To:
${s||"[Client Name]"}

Description: Professional Services
Amount: $${parseFloat(n||"0").toFixed(2)}
Tax (10%): $${(parseFloat(n||"0")*.1).toFixed(2)}
Total: $${(parseFloat(n||"0")*1.1).toFixed(2)}

Payment Terms: Net 30

Thank you for your business!`),d(!1)},1e3)},icon:O,label:"Generate Invoice"}),i&&e.jsx(g,{value:i,label:"Invoice"})]})}function Au({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState([]),c=i.reduce((d,h)=>d+h.a,0);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Amount",type:"number"}),e.jsx(p,{value:n,onChange:o,placeholder:"Category (Food, Transport...)"})]}),e.jsx(x,{onClick:()=>{s&&(r([...i,{a:parseFloat(s),c:n||"General"}]),a(""),o(""))},icon:Ne,label:"Add Expense",variant:"secondary"}),e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsxs("div",{className:"flex justify-between items-center mb-2",children:[e.jsx("span",{className:"text-sm text-gray-400",children:"Today's Expenses"}),e.jsxs("span",{className:"text-xl font-bold text-white",children:["$$",c.toFixed(2)]})]}),i.length===0&&e.jsx("div",{className:"text-sm text-gray-600",children:"No expenses recorded"}),i.map((d,h)=>e.jsxs("div",{className:"flex justify-between text-sm py-1 border-b border-white/5 last:border-0",children:[e.jsx("span",{className:"text-gray-400",children:d.c}),e.jsxs("span",{className:"text-white",children:["$$",d.a.toFixed(2)]})]},h))]}),i.length>0&&e.jsx(x,{onClick:()=>{r([])},icon:Re,label:"Reset",variant:"danger"})]})}function Ru({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., BTC",label:"Asset"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 1000",label:"Capital ($)"})]}),e.jsx(b,{options:["Conservative","Moderate","Aggressive","Scalping"],label:"Strategy"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📈 Trading Analysis

Asset: BTC/USD
Strategy: ${["Conservative","Moderate","Aggressive"][Math.floor(Math.random()*3)]}

📊 Signal: ${["BUY","SELL","HOLD"][Math.floor(Math.random()*3)]}
Entry: $${(4e4+Math.random()*2e4).toFixed(2)}
Stop Loss: $${(38e3+Math.random()*15e3).toFixed(2)}
Take Profit: $${(45e3+Math.random()*25e3).toFixed(2)}

📈 Confidence: ${(60+Math.random()*35).toFixed(0)}%
🎯 Risk/Reward: ${(1+Math.random()*3).toFixed(2)}:1
📅 Timeframe: ${["15m","1h","4h","1d"][Math.floor(Math.random()*4)]}`),o(!1)},1500)},icon:Ge,label:n?"Analyzing...":"Generate Signal"}),s&&e.jsx(g,{value:s})]})}function Pu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your business idea...",label:"Business Idea",multiline:!0,icon:et}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 BUSINESS PLAN: ${s||"Your Business"}

## Executive Summary
${s||"Your company"} is a innovative venture addressing key market needs.

## Market Analysis
• Target Market: ${["SME","Enterprise","Consumer","B2B"][Math.floor(Math.random()*4)]}
• Market Size: $${Math.floor(Math.random()*50+10)}B
• Growth Rate: ${(10+Math.random()*30).toFixed(0)}% YoY

## Revenue Model
• Primary: Subscription ($${(10+Math.random()*100).toFixed(0)}/mo)
• Secondary: One-time fees

## Financial Projections
• Year 1 Revenue: $${Math.floor(Math.random()*500+100)}K
• Year 2 Revenue: $${Math.floor(Math.random()*2e3+500)}K
• Break-even: Month ${Math.floor(6+Math.random()*12)}

## Funding Required
• Amount: $${Math.floor(Math.random()*2e3+500)}K
• Use: Product development + Marketing`),r(!1)},2e3)},icon:et,label:i?"Generating...":"Generate Business Plan"}),n&&e.jsx(g,{value:n})]})}function Lu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"e.g., BTC, ETH, SOL",label:"Coin/Ticker",icon:Ne}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`💰 ${(s||"BTC").toUpperCase()} Wallet Tracker

Balance: ${(Math.random()*10).toFixed(4)} ${(s||"BTC").toUpperCase()}
Value: $${(Math.random()*5e5).toFixed(2)}

📊 24h Change: ${Math.random()>.5?"+":"-"}${(Math.random()*10).toFixed(2)}%
📈 7d Change: ${Math.random()>.5?"+":"-"}${(Math.random()*25).toFixed(2)}%
📉 30d Change: ${Math.random()>.5?"+":"-"}${(Math.random()*40).toFixed(2)}%

Transactions: ${Math.floor(Math.random()*50)}
Network: ${["Ethereum","Solana","Bitcoin"][Math.floor(Math.random()*3)]}

✅ Portfolio updated`),r(!1)},1200)},icon:Cr,label:"Track Portfolio"}),n&&e.jsx(g,{value:n})]})}function Eu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Loan amount",label:"Loan Amount ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Interest rate %",label:"Interest Rate (%)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Loan term (years)",label:"Term (Years)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{const d=.005833333333333334,h=360,u=1e5*d*Math.pow(1+d,h)/(Math.pow(1+d,h)-1);a(`🏦 Loan Calculator

Loan Amount: $${1e5.toLocaleString()}
Interest Rate: 7%
Term: 30 years

📊 Monthly Payment: $${u.toFixed(2)}
💰 Total Interest: $${(u*h-1e5).toFixed(2)}
📈 Total Payment: $${(u*h).toFixed(2)}

📅 First Payment: ${new Date(Date.now()+30*864e5).toLocaleDateString()}
📅 Last Payment: ${new Date(Date.now()+30*365*864e5).toLocaleDateString()}`),o(!1)},800)},icon:ve,label:"Calculate Loan"}),s&&e.jsx(g,{value:s})]})}function Fa({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Annual income",label:"Annual Income ($)"}),e.jsx(b,{options:["Single","Married Filing Jointly","Head of Household","Self-Employed"],label:"Filing Status"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧾 Tax Calculator

Gross Income: $75,000

Deductions:
• Standard Deduction: $13,850
• Taxable Income: $61,150

Tax Breakdown:
• 10% Bracket: $1,100
• 12% Bracket: $5,045
• Total Tax: $6,145

Effective Tax Rate: ${(6145/75e3*100).toFixed(1)}%
Marginal Rate: 22%

📋 Refund/Amount Due: $${Math.random()>.5?"+":"-"}$${Math.floor(Math.random()*3e3).toLocaleString()}`),o(!1)},1e3)},icon:en,label:"Calculate Tax"}),s&&e.jsx(g,{value:s})]})}function Fu({tool:t}){const[s,a]=l.useState("1"),[n,o]=l.useState(""),i={USD:1,EUR:.92,GBP:.79,INR:83.5,JPY:151.7,AUD:1.53,CAD:1.36,CNY:7.24},[r,c]=l.useState("USD"),[d,h]=l.useState("INR"),u=(parseFloat(s||"0")*i[d]/i[r]).toFixed(4);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Amount",label:"Amount",type:"number"}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:r,onChange:c,options:Object.keys(i),label:"From"}),e.jsx(b,{value:d,onChange:h,options:Object.keys(i),label:"To"})]}),e.jsxs("div",{className:"mt-4 p-6 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 text-center",children:[e.jsxs("div",{className:"text-3xl font-bold text-white",children:[s||"1"," ",r," = ",u," ",d]}),e.jsxs("div",{className:"text-sm text-gray-500 mt-1",children:["Rate: 1 ",r," = ",(i[d]/i[r]).toFixed(4)," ",d]})]})]})}function Iu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 75000",label:"Annual Salary ($)"}),e.jsx(b,{options:["Monthly","Bi-weekly","Weekly"],label:"Pay Frequency"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💼 Salary Breakdown

Annual: $75,000
Monthly: $6,250
Bi-weekly: $2,884
Weekly: $1,442
Daily: $288
Hourly: $36.06

💰 Net Monthly (est.): $4,688
🧾 Tax Rate (est.): 25%
📈 Take-home: 75%`),o(!1)},800)},icon:ve,label:"Calculate Salary"}),s&&e.jsx(g,{value:s})]})}function Du({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 10000",label:"Investment ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 15000",label:"Return ($)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 ROI Analysis

Investment: $10,000
Return: $15,000
Profit: $5,000

📈 ROI: 50.0%
📅 Annualized ROI: ${(15+Math.random()*25).toFixed(1)}%
⏱️ Payback Period: ${Math.floor(1+Math.random()*3)} years

🎯 Verdict: ${Math.random()>.3?"✅ Profitable investment":"⚠️ Moderate return"}`),o(!1)},800)},icon:ze,label:"Calculate ROI"}),s&&e.jsx(g,{value:s})]})}function Ou({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Revenue",label:"Revenue ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Costs",label:"Total Costs ($)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 Profit Analysis

Revenue: $50,000
Total Costs: $35,000

Gross Profit: $15,000
Gross Margin: ${(15e3/5e4*100).toFixed(1)}%

Net Profit: $11,250
Net Margin: ${(11250/5e4*100).toFixed(1)}%

💡 Recommendation: ${["Increase prices by 5%","Reduce operational costs","Scale marketing efforts"][Math.floor(Math.random()*3)]}`),o(!1)},800)},icon:Pe,label:"Calculate Profit"}),s&&e.jsx(g,{value:s})]})}function Bu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Amount",label:"Amount ($)"}),e.jsx(b,{options:["5%","12%","18%","28%"],label:"GST Rate"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧾 GST Calculation

Original Amount: $1,000
GST Rate: 18%

GST Amount: $180
Total (incl. GST): $1,180

💰 GST Paid: $180
📋 Invoice Ready`),o(!1)},500)},icon:en,label:"Calculate GST"}),s&&e.jsx(g,{value:s})]})}function Gu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Cost per unit",label:"Cost ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Desired margin %",label:"Margin (%)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{const c=83.33333333333334;a(`📊 Price Calculator

Cost: $50.00
Desired Margin: 40%

💰 Selling Price: $${c.toFixed(2)}
📈 Profit: $${(c-50).toFixed(2)}
📊 Margin: 40%

✅ Price set for profitability`),o(!1)},500)},icon:ve,label:"Calculate Price"}),s&&e.jsx(g,{value:s})]})}function Hu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Employee count",label:"Employees",type:"number"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💼 Payroll Summary

Employees: 10
Total Gross: $75,000/mo

Withholdings:
• Federal Tax: $11,250
• State Tax: $3,750
• Social Security: $4,650
• Medicare: $1,087
• 401(k): $3,000

Net Payroll: $51,263
Employer Taxes: $5,737

✅ Payroll processed`),o(!1)},1e3)},icon:O,label:"Process Payroll"}),s&&e.jsx(g,{value:s})]})}function Wu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Asset value",label:"Asset Value ($)"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Useful life (years)",label:"Life (Years)"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📉 Depreciation Schedule

Method: Straight-Line
Asset Value: $50,000
Useful Life: 10 Years
Salvage Value: $5,000

Annual Depreciation: $4,500

Year 1: $4,500 | Book: $45,500
Year 2: $4,500 | Book: $41,000
Year 3: $4,500 | Book: $36,500
...
Year 10: $4,500 | Book: $5,000

✅ Schedule generated`),o(!1)},800)},icon:Pe,label:"Calculate Depreciation"}),s&&e.jsx(g,{value:s})]})}function Uu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Current budget",label:"Current Budget ($)"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 Budget Forecast

Current Budget: $100,000
Forecast Period: 12 Months

Projections:
• Q1: $25,000 (+2% vs plan)
• Q2: $27,500 (+10% vs plan)
• Q3: $26,000 (+4% vs plan)
• Q4: $28,500 (+14% vs plan)

Total Forecast: $107,000
Variance: +7.0%

⚠️ Alert: Q2 and Q4 over budget
💡 Optimize: Reduce Q4 by 5%`),o(!1)},1e3)},icon:Ge,label:"Forecast Budget"}),s&&e.jsx(g,{value:s})]})}function Vu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Client",label:"Client"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Amount",label:"Amount ($)"})]}),e.jsx(b,{options:["Weekly","Monthly","Quarterly","Yearly"],label:"Frequency"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔄 Recurring Invoice Setup

Client: [Client]
Amount: $1,000
Frequency: Monthly
Next Invoice: ${new Date(Date.now()+30*864e5).toLocaleDateString()}

📅 Annual Value: $12,000
📊 Invoice #: INV-REC-${Math.floor(Math.random()*9999)}

✅ Auto-payment: Enabled
📧 Email notification: Weekly`),o(!1)},800)},icon:Re,label:"Setup Recurring"}),s&&e.jsx(g,{value:s})]})}function zu({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("tutor")||r.includes("learn")?e.jsx(qu,{tool:t}):r.includes("flashcard")?e.jsx(Qu,{tool:t}):r.includes("exam")||r.includes("test")||r.includes("quiz")?e.jsx(_u,{tool:t}):r.includes("lesson")||r.includes("plan")&&r.includes("lesson")?e.jsx(Ku,{tool:t}):r.includes("course")&&r.includes("builder")?e.jsx(Yu,{tool:t}):r.includes("grade")||r.includes("gpa")?e.jsx(Ju,{tool:t}):r.includes("study")||r.includes("study planner")?e.jsx(Xu,{tool:t}):r.includes("dictionary")||r.includes("vocabulary")?e.jsx(Zu,{tool:t}):r.includes("spelling")||r.includes("spell")?e.jsx(eh,{tool:t}):r.includes("math")||r.includes("algebra")?e.jsx(th,{tool:t}):r.includes("science")&&!r.includes("generative")?e.jsx(sh,{tool:t}):r.includes("reading")||r.includes("read")?e.jsx(ah,{tool:t}):r.includes("writing")||r.includes("essay")?e.jsx(nh,{tool:t}):r.includes("homework")||r.includes("assignment")?e.jsx(rh,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-center",children:[e.jsx(Ls,{className:"w-6 h-6 text-indigo-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Learn"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(ge,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Practice"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(Ft,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Assess"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter your ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:A}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`📚 ${t.name}

Input received: ${s||"Standard"}
Category: Educational

✅ Ready for review
📊 Learning outcomes generated`),i(!1)},800)},icon:$,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function qu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("General"),[i,r]=l.useState(""),[c,d]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Ask any question...",label:"Your Question",multiline:!0,icon:ge}),e.jsx(b,{value:n,onChange:o,options:["General","Mathematics","Science","History","English","Computer Science","Physics","Chemistry"],label:"Subject"}),e.jsx(x,{onClick:()=>{d(!0),setTimeout(()=>{r(`🎓 AI Tutor Response

Subject: ${n}
Question: ${s||"How does learning work?"}

Let me explain this step by step:

1️⃣ First, we need to understand the basic concept:
${s?s.split(" ").slice(0,10).join(" "):"The fundamental principle"} involves several key components that work together.

2️⃣ Key Points to Remember:
• Core concept A — This is the foundation
• Core concept B — Builds upon the previous
• Core concept C — Practical application

3️⃣ Example:
\`\`\`
Here's a practical example to illustrate:
Input → Process → Output
\`\`\`

4️⃣ Practice Question:
Try this: How would you apply ${(s||"this concept").toLowerCase()} in a real scenario?

💡 Pro Tip: Practice regularly to master this topic!
📚 Related topics: ${["Advanced concepts","Related theory","Practical applications"][Math.floor(Math.random()*3)]}`),d(!1)},1800)},icon:Ls,label:c?"Thinking...":"Ask AI Tutor"}),i&&e.jsx(g,{value:i,label:"AI Tutor Response"})]})}function Qu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1),[c,d]=l.useState(0);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter topic for flashcards...",label:"Topic",icon:A}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📇 Flashcards: ${s||"General Knowledge"}

Card 1/10:
Q: What is ${s||"this concept"}?
A: It is a fundamental concept in ${(s||"the subject").toLowerCase()}.

Card 2/10:
Q: Why is ${s||"this"} important?
A: It helps us understand and apply key principles.

Card 3/10:
Q: How does ${s||"this"} work?
A: Through a systematic process of analysis and application.

Card 4/10:
Q: What are the main components?
A: Component A, Component B, and Component C.

Card 5/10:
Q: Give an example of ${s||"this"}.
A: Real-world example demonstrating the concept.

📚 Total: 10 flashcards
🎯 Study mode: Ready
⏱️ Estimated review: 10 min`),r(!1)},1200)},icon:ge,label:i?"Generating...":"Generate Flashcards"}),n&&e.jsx(g,{value:n,label:"Flashcards"})]})}function _u({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Subject",label:"Subject"}),e.jsx(b,{options:["10 Questions","20 Questions","30 Questions","50 Questions"],label:"Length"})]}),e.jsx(b,{options:["Multiple Choice","True/False","Mix","Short Answer"],label:"Question Type"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📝 ${s||"General"} Exam

Total Questions: ${Math.floor(10+Math.random()*20)}
Time Allowed: ${Math.floor(30+Math.random()*60)} minutes

Sample Questions:

1. What is the primary concept of ${s||"this subject"}?
   A) Option A
   B) Option B
   C) Option C
   D) Option D

2. Which of the following best describes...?
   A) Description A
   B) Description B
   C) Description C
   D) Description D

3. True or False: [Statement about ${s||"topic"}]

...

Answer Key:
1. B
2. C
3. True
...

📊 Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}
🏆 Pass Score: ${Math.floor(40+Math.random()*20)}%`),r(!1)},1500)},icon:O,label:i?"Generating...":"Generate Exam"}),n&&e.jsx(g,{value:n})]})}function Ku({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Lesson topic",label:"Lesson Topic",icon:A}),e.jsx(b,{options:["30 min","45 min","60 min","90 min"],label:"Duration"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 Lesson Plan: ${s||"Your Topic"}

Duration: 60 minutes
Grade Level: ${["Elementary","Middle School","High School","College"][Math.floor(Math.random()*4)]}

📌 Learning Objectives:
• Understand core concepts of ${s||"the topic"}
• Apply knowledge in practical scenarios
• Analyze and evaluate key ideas

📖 Lesson Structure:
1️⃣ Opening (5 min): Hook & engagement activity
2️⃣ Introduction (10 min): Key concepts overview
3️⃣ Main Activity (25 min): Interactive learning
4️⃣ Practice (10 min): Hands-on exercise
5️⃣ Assessment (5 min): Quick check for understanding
6️⃣ Closing (5 min): Review & homework

📎 Materials Needed:
• Presentation slides
• Worksheets
• Interactive tools

✅ Lesson ready for delivery`),r(!1)},1200)},icon:Nr,label:i?"Planning...":"Generate Lesson Plan"}),n&&e.jsx(g,{value:n})]})}function Yu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Course topic",label:"Course Topic",multiline:!0,icon:A}),e.jsx(b,{options:["Beginner","Intermediate","Advanced","All Levels"],label:"Level"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📚 Course: ${s||"Your Course"}

Level: ${["Beginner","Intermediate","Advanced"][Math.floor(Math.random()*3)]}
Total Modules: ${Math.floor(6+Math.random()*10)}
Total Duration: ${Math.floor(10+Math.random()*30)} hours

Module 1: Introduction to ${s||"Topic"}
• Welcome & overview
• Key concepts
• Setting up

Module 2: Fundamentals
• Core principles
• Essential skills
• Practice exercises

Module 3: Intermediate Topics
• Advanced concepts
• Real-world applications
• Case studies

Module 4: Mastery
• Expert techniques
• Projects
• Capstone

📊 Quizzes: ${Math.floor(5+Math.random()*10)}
🎯 Projects: ${Math.floor(2+Math.random()*4)}
🏆 Certificate: Included`),r(!1)},1500)},icon:Ls,label:i?"Building...":"Build Course"}),n&&e.jsx(g,{value:n})]})}function Ju({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Score",label:"Score (%)"}),e.jsx(b,{options:["A-F (Standard)","1-100 (Percentage)","Pass/Fail"],label:"Grading Scale"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📊 Grade Calculation

Score: 85%

Letter Grade: A-
GPA: 3.7 / 4.0

🏆 Performance: Excellent
📈 Percentile: 85th

✅ Status: Passing
💡 Improvement: ${5+Math.floor(Math.random()*10)}% to reach A+`),o(!1)},500)},icon:ve,label:"Calculate Grade"}),s&&e.jsx(g,{value:s})]})}function Xu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"What do you need to study?",label:"Study Goal"}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{options:["1 week","2 weeks","1 month","3 months"],label:"Timeline"}),e.jsx(b,{options:["30 min/day","1 hour/day","2 hours/day","3+ hours/day"],label:"Daily Time"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📅 Study Plan

🎯 Goal: [Your Goal]
📆 Timeline: 1 month
⏱️ Daily: 1 hour

Weekly Schedule:

Week 1: Foundation
• Day 1-2: Core concepts
• Day 3-4: Key terms
• Day 5-6: Practice
• Day 7: Review

Week 2: Building Knowledge
• Day 8-10: Advanced topics
• Day 11-12: Application
• Day 13-14: Self-test

Week 3: Mastery
• Day 15-19: Complex concepts
• Day 20-21: Mock tests

Week 4: Final Prep
• Day 22-26: Review all
• Day 27-28: Final practice

⏰ Total Study: ${Math.floor(20+Math.random()*20)} hours
📊 Progress Tracking: Built-in`),o(!1)},1200)},icon:ze,label:"Create Study Plan"}),s&&e.jsx(g,{value:s})]})}function Zu({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter a word...",label:"Word",icon:A}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📖 ${s||"example"}

Pronunciation: /ɪɡˈzæmpəl/
Part of Speech: ${["noun","verb","adjective","adverb"][Math.floor(Math.random()*4)]}

Definition:
A thing characteristic of its kind; a thing that demonstrates a quality or type.

Synonyms:
• Instance, specimen, sample, illustration

Antonyms:
• Exception, anomaly

Usage:
"This is a ${s||"perfect example"} of the concept."

📚 Word Origin: Latin (exemplum)
🎯 Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}`),r(!1)},800)},icon:A,label:"Look Up"}),n&&e.jsx(g,{value:n})]})}function eh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter text to check spelling...",label:"Text",multiline:!0,icon:O}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`✓ Spelling Check Complete

Words Checked: ${(s||"").split(/\s+/).filter(Boolean).length||0}

✏️ Suggestions:
• No spelling errors found ✓
${s&&s.length>20?`
🔍 Did you mean: "${s.split(" ").slice(0,3).join(" ")}"?`:""}

📊 Score: ${(90+Math.random()*10).toFixed(0)}/100
✅ ${(s||"").split(" ").filter(Boolean).length||0} words, 0 errors`),r(!1)},800)},icon:rt,label:"Check Spelling"}),n&&e.jsx(g,{value:n})]})}function th({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter math problem...",label:"Problem",multiline:!0,icon:ve}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🧮 Math Solution

Problem: ${s||"2x + 5 = 13"}

Step 1: ${s?"Analyze the equation":"2x + 5 = 13"}
Step 2: ${s?"Isolate the variable":"2x = 13 - 5"}
Step 3: ${s?"Solve for x":"2x = 8"}
Step 4: ${s?"Verify solution":"x = 4"}

✅ Solution: ${s?"Solved!":"x = 4"}

📊 Verification:
${s?"":`2(4) + 5 = 13 ✓
8 + 5 = 13 ✓`}

📝 Steps shown: ${Math.floor(3+Math.random()*4)}`),r(!1)},1e3)},icon:ve,label:"Solve"}),n&&e.jsx(g,{value:n})]})}function sh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe experiment...",label:"Experiment",multiline:!0}),e.jsx(b,{options:["Physics","Chemistry","Biology","General Science"],label:"Branch"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔬 Science Lab

Experiment: [Your Experiment]
Branch: ${["Physics","Chemistry","Biology"][Math.floor(Math.random()*3)]}

📋 Procedure:
1. Gather materials
2. Set up equipment
3. Record initial measurements
4. Conduct experiment
5. Collect data
6. Analyze results

📊 Expected Results:
• Observation A: ${(Math.random()*100).toFixed(1)}%
• Observation B: ${(Math.random()*50).toFixed(1)}%
• Margin of Error: ±${(Math.random()*5).toFixed(2)}%

⚠️ Safety Precautions:
• Wear protective equipment
• Follow lab protocols
• Dispose properly`),o(!1)},1200)},icon:ge,label:"Run Experiment"}),s&&e.jsx(g,{value:s})]})}function ah({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Paste reading passage...",label:"Reading Passage",multiline:!0}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📖 Reading Comprehension

Reading Level: Grade ${Math.floor(5+Math.random()*8)}
Word Count: ${Math.floor(200+Math.random()*500)}
Est. Reading Time: ${Math.floor(1+Math.random()*5)} min

Comprehension Questions:

1. What is the main idea of this passage?
   A) [Option A]
   B) [Option B]
   C) [Option C]
   D) [Option D]

2. According to the passage, which of the following is true?
   A) [Option A]
   B) [Option B]
   C) [Option C]
   D) [Option D]

3. What can be inferred from paragraph 2?

📊 Vocabulary words: ${Math.floor(5+Math.random()*10)}
🎯 Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}`),o(!1)},1e3)},icon:A,label:"Generate Questions"}),s&&e.jsx(g,{value:s})]})}function nh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Paste essay here...",label:"Essay",multiline:!0}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`✏️ Essay Grading

Score: ${(70+Math.random()*25).toFixed(0)}/100
Grade: ${["B+","A-","B","A","B-"][Math.floor(Math.random()*5)]}

📊 Rubric:
• Content: ${(70+Math.random()*30).toFixed(0)}%
• Structure: ${(70+Math.random()*30).toFixed(0)}%
• Grammar: ${(70+Math.random()*30).toFixed(0)}%
• Vocabulary: ${(70+Math.random()*30).toFixed(0)}%

💬 Feedback:
• Strong thesis statement
• Good supporting evidence
• Consider adding more examples
• Minor grammar improvements needed

📝 Word Count: ${Math.floor(200+Math.random()*800)}
✅ Plagiarism Check: Original`),o(!1)},1e3)},icon:G,label:"Grade Essay"}),s&&e.jsx(g,{value:s})]})}function rh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Paste your homework question...",label:"Question",multiline:!0,icon:$e}),e.jsx(b,{options:["Math","Science","English","History","Computer Science"],label:"Subject"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📚 Homework Help

Question: ${s||"Sample question"}
Subject: [Subject]

✅ Step-by-step solution:

1. First, let's understand what the question asks.
2. Identify the key concepts involved.
3. Apply the relevant formulas/methods.
4. Work through the solution systematically.
5. Verify the answer.

💡 Hint: Think about the relationship between the given information and what's being asked.

📝 Answer: [Complete solution with explanation]

📊 Similar problems for practice available`),r(!1)},1200)},icon:$e,label:"Get Help"}),n&&e.jsx(g,{value:n})]})}function oh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("symptom")||r.includes("checker")?e.jsx(ih,{tool:t}):r.includes("telemedicine")||r.includes("telehealth")?e.jsx(lh,{tool:t}):r.includes("medical")&&(r.includes("transcri")||r.includes("note"))?e.jsx(ch,{tool:t}):r.includes("nutrition")||r.includes("diet")||r.includes("meal")?e.jsx(dh,{tool:t}):r.includes("bmi")||r.includes("bmi calculator")?e.jsx(uh,{tool:t}):r.includes("calorie")||r.includes("calories")?e.jsx(hh,{tool:t}):r.includes("water")||r.includes("hydration")?e.jsx(mh,{tool:t}):r.includes("sleep")||r.includes("insomnia")?e.jsx(xh,{tool:t}):r.includes("heart")||r.includes("cardio")?e.jsx(ph,{tool:t}):r.includes("blood")&&(r.includes("pressure")||r.includes("bp"))?e.jsx(gh,{tool:t}):r.includes("medication")||r.includes("medicine")||r.includes("pill")?e.jsx(fh,{tool:t}):r.includes("fitness")||r.includes("exercise")||r.includes("workout")?e.jsx(bh,{tool:t}):r.includes("yoga")||r.includes("meditation")||r.includes("mindful")?e.jsx(yh,{tool:t}):r.includes("vision")||r.includes("eye")||r.includes("sight")?e.jsx(jh,{tool:t}):r.includes("vaccine")||r.includes("vaccination")?e.jsx(vh,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center",children:[e.jsx(me,{className:"w-6 h-6 text-red-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Health"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(we,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Fitness"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(ge,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Wellness"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:we}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🏥 ${t.name}

Status: Completed
Input: ${s||"Default"}

✅ Analysis ready
📊 Health metrics processed`),i(!1)},800)},icon:me,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function ih({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your symptoms in detail...",label:"Your Symptoms",multiline:!0,icon:O}),e.jsx(b,{options:["Adult (18-65)","Child (2-17)","Senior (65+)","Infant (0-2)"],label:"Age Group"}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🔍 Symptom Analysis

Symptoms: ${s||"General discomfort"}

Possible Conditions:
1. ${["Common Cold (40%)","Seasonal Allergies (35%)","Mild Infection (15%)","Stress Related (10%)"][Math.floor(Math.random()*4)]}
2. Monitor for additional symptoms

Recommendations:
✅ Rest and hydrate
✅ Monitor temperature
✅ Consult doctor if persists >3 days
🔴 Emergency: If breathing difficulty occurs

⚠️ Disclaimer: This is not a medical diagnosis. Consult a healthcare professional.
📊 Confidence: ${(60+Math.random()*35).toFixed(0)}%`),r(!1)},1500)},icon:ge,label:i?"Analyzing...":"Check Symptoms"}),n&&e.jsx(g,{value:n})]})}function lh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"p-6 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 text-center",children:[e.jsx(wh,{className:"w-12 h-12 text-blue-400 mx-auto mb-2"}),e.jsx("div",{className:"text-white font-medium",children:"Ready for Virtual Consultation"}),e.jsx("div",{className:"text-sm text-gray-500",children:"Your doctor is available"}),e.jsx("button",{className:"mt-4 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all font-medium",children:"📹 Start Video Call"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center text-sm text-gray-400",children:"📅 Schedule"}),e.jsx("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5 text-center text-sm text-gray-400",children:"💬 Chat"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{o(!1)},500)},icon:Ae,label:"View History",variant:"secondary"})]})}function ch({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Dictate or type medical notes...",label:"Medical Notes",multiline:!0,icon:O}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`📋 Medical Transcription

Processed Notes:
${s||"Patient presents with standard symptoms. Vital signs normal. No significant findings."}

Extracted Information:
• Patient: [From context]
• Date: ${new Date().toLocaleDateString()}
• Diagnosis: ${["General examination","Routine checkup","Symptom management","Preventive care"][Math.floor(Math.random()*4)]}
• Notes: ${Math.floor(10+Math.random()*40)} words transcribed

📊 Confidence: ${(90+Math.random()*9).toFixed(1)}%
✅ Added to patient record`),r(!1)},1e3)},icon:O,label:"Transcribe Notes"}),n&&e.jsx(g,{value:n})]})}function dh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter food item (e.g., 1 cup rice, 100g chicken)",label:"Food Item",icon:cs}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🥗 Nutrition Analysis: ${s||"Sample Meal"}

Serving Size: ${s?"Custom":"100g"}

Calories: ${Math.floor(100+Math.random()*600)} kcal
Protein: ${(10+Math.random()*30).toFixed(1)}g
Carbohydrates: ${(20+Math.random()*50).toFixed(1)}g
Fat: ${(5+Math.random()*25).toFixed(1)}g
Fiber: ${(2+Math.random()*10).toFixed(1)}g
Sugar: ${(1+Math.random()*15).toFixed(1)}g
Sodium: ${(100+Math.random()*800).toFixed(0)}mg

🥇 Health Score: ${(55+Math.random()*40).toFixed(0)}/100
💡 ${["Good protein source!","High in fiber!","Moderate calories.","Watch the sugar content."][Math.floor(Math.random()*4)]}`),r(!1)},1e3)},icon:cs,label:"Analyze Nutrition"}),n&&e.jsx(g,{value:n})]})}function uh({tool:t}){const[s,a]=l.useState("170"),[n,o]=l.useState("70"),i=parseFloat(s||"170")/100,c=parseFloat(n||"70")/(i*i),d=c<18.5?"Underweight":c<25?"Normal":c<30?"Overweight":"Obese",h=c<18.5?"text-blue-400":c<25?"text-emerald-400":c<30?"text-amber-400":"text-red-400";return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"170",label:"Height (cm)",type:"number"}),e.jsx(p,{value:n,onChange:o,placeholder:"70",label:"Weight (kg)",type:"number"})]}),e.jsxs("div",{className:"mt-4 p-6 rounded-xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 text-center",children:[e.jsx("div",{className:`text-4xl font-bold ${h}`,children:c.toFixed(1)}),e.jsx("div",{className:`text-lg font-medium ${h}`,children:d}),e.jsx("div",{className:"text-sm text-gray-500 mt-1",children:"BMI Category"}),e.jsx("div",{className:"mt-2 h-2 rounded-full bg-white/10 overflow-hidden",children:e.jsx("div",{className:`h-full rounded-full transition-all ${c<18.5?"bg-blue-500":c<25?"bg-emerald-500":c<30?"bg-amber-500":"bg-red-500"}`,style:{width:`${Math.min(100,c/40*100)}%`}})})]})]})}function hh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState([]),c=i.reduce((d,h)=>d+h.c,0);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Food item",label:"Food"}),e.jsx(p,{value:n,onChange:o,placeholder:"Calories",label:"Calories",type:"number"})]}),e.jsx(x,{onClick:()=>{n&&(r([...i,{f:s||"Snack",c:parseInt(n)}]),a(""),o(""))},icon:Qs,label:"Log Food",variant:"secondary"}),e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsxs("div",{className:"flex justify-between items-center mb-2",children:[e.jsx("span",{className:"text-sm text-gray-400",children:"Today"}),e.jsxs("span",{className:"text-lg font-bold text-white",children:[c," kcal"]})]}),i.map((d,h)=>e.jsxs("div",{className:"flex justify-between text-sm py-1 border-b border-white/5 last:border-0",children:[e.jsx("span",{className:"text-gray-400",children:d.f}),e.jsxs("span",{className:"text-white",children:[d.c," kcal"]})]},h)),i.length===0&&e.jsx("div",{className:"text-sm text-gray-600",children:"Log your meals"})]})]})}function mh({tool:t}){const[s,a]=l.useState(0);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:"w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30 flex items-center justify-center mb-4",children:e.jsx(it,{className:"w-10 h-10 text-blue-400"})}),e.jsxs("div",{className:"text-3xl font-bold text-white",children:[s,"/8"]}),e.jsx("div",{className:"text-sm text-gray-500",children:"glasses of water today"}),e.jsx("div",{className:"w-48 h-2 mx-auto mt-3 rounded-full bg-white/10 overflow-hidden",children:e.jsx("div",{className:"h-full bg-blue-500 transition-all",style:{width:`${s/8*100}%`}})})]}),e.jsxs("div",{className:"flex justify-center gap-3",children:[e.jsx(x,{onClick:()=>a(Math.max(0,s-1)),icon:Mh,label:"-",variant:"secondary"}),e.jsx(x,{onClick:()=>a(Math.min(8,s+1)),icon:Qs,label:"+"})]})]})}function xh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 text-center",children:[e.jsx(vt,{className:"w-8 h-8 text-indigo-400 mx-auto mb-2"}),e.jsxs("div",{className:"text-2xl font-bold text-white",children:["$",(5+Math.random()*4).toFixed(1),"h"]}),e.jsx("div",{className:"text-sm text-gray-500",children:"Last Night's Sleep"})]}),e.jsx(b,{options:["Good","Fair","Poor","Excellent"],label:"Sleep Quality"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`😴 Sleep Analysis

Duration: 7.2 hours
Quality: ${["Good","Excellent","Fair","Restful"][Math.floor(Math.random()*4)]}
Deep Sleep: ${(1+Math.random()*2).toFixed(1)}h
REM: ${(1+Math.random()*2).toFixed(1)}h
Light Sleep: ${(2+Math.random()*2).toFixed(1)}h

📊 Score: ${(70+Math.random()*30).toFixed(0)}/100
💡 Tip: Maintain consistent bedtime`),o(!1)},800)},icon:vt,label:"Analyze Sleep"}),s&&e.jsx(g,{value:s})]})}function ph({tool:t}){const[s,a]=l.useState(72);return e.jsx(m,{tool:t,children:e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:`w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-red-500/20 to-pink-500/20 border border-red-500/30 flex items-center justify-center mb-4 ${s>0?"animate-pulse":""}`,children:e.jsx(me,{className:`w-10 h-10 ${s>100?"text-red-400":"text-emerald-400"}`})}),e.jsx("div",{className:"text-4xl font-bold text-white",children:s}),e.jsx("div",{className:"text-sm text-gray-500",children:"BPM — Resting Heart Rate"}),e.jsx("div",{className:"flex gap-2 justify-center mt-4",children:["60","72","80","100"].map(n=>e.jsx("button",{onClick:()=>a(parseInt(n)),className:`px-4 py-2 rounded-xl text-sm ${s===parseInt(n)?"bg-red-600 text-white":"bg-white/5 text-gray-400"} transition-all`,children:n},n))})]})})}function gh({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 120",label:"Systolic",type:"number"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 80",label:"Diastolic",type:"number"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-r from-amber-500/10 to-red-500/10 border border-amber-500/20 text-center",children:[e.jsx("div",{className:"text-3xl font-bold text-white",children:"120/80"}),e.jsx("div",{className:"text-emerald-400 font-medium",children:"✅ Normal Range"})]})]})}function fh({tool:t}){const[s,a]=l.useState([]),[n,o]=l.useState(""),[i,r]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsx(p,{value:n,onChange:o,placeholder:"Medicine name",label:"Medication"}),e.jsx(p,{value:i,onChange:r,placeholder:"09:00",label:"Time",type:"time"})]}),e.jsx(x,{onClick:()=>{n&&(a([...s,{n,t:i||"09:00"}]),o(""),r(""))},icon:ea,label:"Add Reminder",variant:"secondary"}),s.map((c,d)=>e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5 flex items-center gap-3",children:[e.jsx(ea,{className:"w-4 h-4 text-red-400"}),e.jsx("span",{className:"text-sm text-white",children:c.n}),e.jsx("span",{className:"text-xs text-gray-500 ml-auto",children:c.t})]},d))]})}function bh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx("div",{className:"text-xl font-bold text-white",children:"0"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Steps"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx("div",{className:"text-xl font-bold text-white",children:"0"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Min"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx("div",{className:"text-xl font-bold text-white",children:"0"}),e.jsx("div",{className:"text-xs text-gray-500",children:"kcal"})]})]}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe your workout...",label:"Workout"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{o(!1)},500)},icon:we,label:"Log Workout"})]})}function yh({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-4",children:[e.jsx("div",{className:"w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center mb-4",children:e.jsx(ge,{className:"w-10 h-10 text-purple-400"})}),e.jsx("div",{className:"text-white font-medium",children:"🧘 Guided Wellness Session"}),e.jsx("div",{className:"text-gray-500 text-sm",children:"5 min • Mindfulness • Relaxation"})]}),e.jsx(b,{options:["5 min - Quick Calm","10 min - Deep Focus","15 min - Full Relaxation"],label:"Duration"}),e.jsx(x,{onClick:()=>{},icon:Oe,label:"Start Session"})]})}function jh({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:"text-6xl font-bold text-white mb-4",children:"E"}),e.jsx("div",{className:"text-4xl font-bold text-white mb-3",children:"F P"}),e.jsx("div",{className:"text-2xl font-bold text-white mb-3",children:"T O Z"}),e.jsx("div",{className:"text-xl font-bold text-white mb-3",children:"L P E D"}),e.jsx("div",{className:"text-base text-white mb-3",children:"P E C F D"}),e.jsx("div",{className:"text-sm text-white",children:"E D F C Z P"}),e.jsx("div",{className:"text-xs text-white mt-2",children:"F E L O P Z D"})]}),e.jsx(b,{options:["3 meters","6 meters","20 feet"],label:"Distance"}),e.jsx(x,{onClick:()=>{},icon:Te,label:"Check Results",variant:"secondary"})]})}function vh({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"space-y-3",children:[["COVID-19","✅ Complete","emerald"],["Flu","⚠️ Due","amber"],["Hepatitis B","✅ Complete","emerald"],["Tetanus","🔴 Overdue","red"]].map(([s,a,n])=>e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("span",{className:"text-white text-sm",children:s}),e.jsx("span",{className:`text-xs px-2 py-0.5 rounded-full bg-${n}-500/10 text-${n}-400`,children:a})]},s))}),e.jsx(x,{onClick:()=>{},icon:Qs,label:"Add Vaccine",variant:"secondary"})]})}function wh(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polygon",{points:"23 7 16 12 23 17 23 7"}),e.jsx("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"})]})}function Mh(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"})})}function Qs(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("line",{x1:"12",y1:"5",x2:"12",y2:"19"}),e.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"})]})}function Sh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("meditation")||r.includes("mindfulness")?e.jsx(Ch,{tool:t}):r.includes("workout")||r.includes("exercise")?e.jsx(Nh,{tool:t}):r.includes("diet")||r.includes("meal")||r.includes("food")?e.jsx($h,{tool:t}):r.includes("travel")||r.includes("trip")||r.includes("vacation")?e.jsx(kh,{tool:t}):r.includes("translator")||r.includes("translate")||r.includes("language")?e.jsx(Th,{tool:t}):r.includes("habit")||r.includes("tracker")?e.jsx(Ah,{tool:t}):r.includes("journal")||r.includes("diary")?e.jsx(Rh,{tool:t}):r.includes("mood")||r.includes("emotion")?e.jsx(Ph,{tool:t}):r.includes("timer")||r.includes("pomodoro")||r.includes("focus")?e.jsx(Lh,{tool:t}):r.includes("yoga")||r.includes("flexible")?e.jsx(Eh,{tool:t}):r.includes("skincare")||r.includes("beauty")||r.includes("cosmetic")?e.jsx(Fh,{tool:t}):r.includes("wardrobe")||r.includes("closet")||r.includes("fashion")?e.jsx(Ih,{tool:t}):r.includes("gift")||r.includes("present")?e.jsx(Dh,{tool:t}):r.includes("budget")&&r.includes("personal")?e.jsx(Oh,{tool:t}):r.includes("goal")||r.includes("ambition")||r.includes("dream")?e.jsx(Bh,{tool:t}):r.includes("recipe")||r.includes("cook")||r.includes("kitchen")?e.jsx(Gh,{tool:t}):r.includes("party")||r.includes("event")||r.includes("celebration")?e.jsx(Hh,{tool:t}):r.includes("learning")||r.includes("skill")?e.jsx(Wh,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(Oe,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Lifestyle"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center",children:[e.jsx(me,{className:"w-6 h-6 text-purple-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Wellness"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(G,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Personal"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:me}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`✨ ${t.name} Results

Input: ${s||"Default"}
Status: Completed

✅ Ready for you
📊 Personalized results generated`),i(!1)},800)},icon:$,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Ch({tool:t}){const[s,a]=l.useState("5 min");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:"w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center mb-4",children:e.jsx(ge,{className:"w-12 h-12 text-purple-400"})}),e.jsx("div",{className:"text-white font-medium",children:"🧘 Guided Meditation"}),e.jsxs("div",{className:"text-gray-500 text-sm",children:[s," • Calm • Peace"]})]}),e.jsx("div",{className:"flex justify-center gap-2 mb-4",children:["3 min","5 min","10 min","15 min"].map(n=>e.jsx("button",{onClick:()=>a(n),className:`px-4 py-2 rounded-xl text-sm ${s===n?"bg-purple-600 text-white":"bg-white/5 text-gray-400"} transition-all`,children:n},n))}),e.jsx(b,{options:["Calm & Peaceful","Stress Relief","Sleep Better","Focus & Energy","Gratitude"],label:"Theme"}),e.jsx(x,{onClick:()=>{},icon:ge,label:`Start ${s} Meditation`})]})}function Nh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(b,{options:["Beginner","Intermediate","Advanced"],label:"Level"}),e.jsx(b,{options:["30 min","45 min","60 min","90 min"],label:"Duration"})]}),e.jsx(b,{options:["Full Body","Upper Body","Lower Body","Core","Cardio","HIIT","Strenght"],label:"Focus"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💪 Workout Plan Generated

Level: ${["Beginner","Intermediate","Advanced"][Math.floor(Math.random()*3)]}
Duration: ${["30","45","60"][Math.floor(Math.random()*3)]} min

Exercises:
1. Warm-up (5 min)
   • Jumping jacks
   • Arm circles
   • Leg swings

2. Main Circuit (${Math.floor(15+Math.random()*15)} min)
   • Push-ups: 3x12
   • Squats: 3x15
   • Plank: 3x30s
   • Lunges: 3x10 each
   • Rows: 3x12

3. Cardio (${Math.floor(8+Math.random()*7)} min)
   • Burpees: 3x10
   • Mountain climbers: 3x20
   • Jump rope: 3x30s

4. Cool-down (5 min)
   • Stretching
   • Deep breathing

🔥 Est. Calories: ${Math.floor(200+Math.random()*400)}
🏆 Difficulty: ${["Easy","Moderate","Challenging"][Math.floor(Math.random()*3)]}`),o(!1)},1200)},icon:$r,label:n?"Generating...":"Generate Workout"}),s&&e.jsx(g,{value:s,label:"Workout Plan"})]})}function $h({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(b,{options:["Balanced","High Protein","Low Carb","Keto","Vegeterian","Vegan","Mediterranean"],label:"Diet Type"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"e.g., 2000",label:"Daily Calories",type:"number"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🥗 Diet Plan: ${["Balanced","High Protein","Low Carb"][Math.floor(Math.random()*3)]}

Daily Calories: ${Math.floor(1500+Math.random()*1e3)} kcal

🍳 Breakfast (${Math.floor(300+Math.random()*200)} kcal)
• Oatmeal with berries (${Math.floor(200+Math.random()*100)} kcal)
• Greek yogurt (${Math.floor(Math.random()*100+50)} kcal)

🥗 Lunch (${Math.floor(400+Math.random()*300)} kcal)
• Grilled chicken salad
• Quinoa bowl

🥘 Dinner (${Math.floor(400+Math.random()*300)} kcal)
• Salmon with vegetables
• Brown rice

🥤 Snacks (${Math.floor(150+Math.random()*150)} kcal)
• Almonds
• Protein shake
• Fruit

💧 Water: 8 glasses/day
🥦 Fiber: ${Math.floor(20+Math.random()*15)}g
🥩 Protein: ${Math.floor(80+Math.random()*60)}g`),o(!1)},1200)},icon:cs,label:n?"Planning...":"Generate Diet Plan"}),s&&e.jsx(g,{value:s,label:"Diet Plan"})]})}function kh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Destination",label:"Destination",icon:et}),e.jsx(b,{options:["7 days","14 days","21 days","30 days"],label:"Duration"})]}),e.jsx(b,{options:["Budget","Mid-Range","Luxury","Backpacker"],label:"Budget Level"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`✈️ Travel Plan: [Destination]

Duration: ${["7","14","21"][Math.floor(Math.random()*3)]} days
Budget: $${(500+Math.random()*5e3).toFixed(0)}

Day-by-Day:

Day 1: Arrival & Check-in
• Morning: Arrive at airport
• Afternoon: Hotel check-in
• Evening: Welcome dinner

Day 2: Explore City
• Morning: City tour
• Afternoon: Museum visit
• Evening: Local cuisine

Day 3: Adventure
• Morning: Hiking/Outdoor
• Afternoon: Beach/Pool
• Evening: Night market

[+ days 4-${["7","14","21"][Math.floor(Math.random()*3)]}...]

💰 Budget Breakdown:
• Flights: $${Math.floor(200+Math.random()*800)}
• Hotel: $${Math.floor(300+Math.random()*1500)}
• Food: $${Math.floor(200+Math.random()*800)}
• Activities: $${Math.floor(100+Math.random()*500)}
• Total: $${Math.floor(800+Math.random()*4e3)}

✅ Ready to book!`),o(!1)},1500)},icon:et,label:n?"Planning...":"Plan Trip"}),s&&e.jsx(g,{value:s,label:"Travel Plan"})]})}function Th({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState("English"),[i,r]=l.useState("Hindi"),[c,d]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter text to translate...",label:"Text",multiline:!0,icon:A}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:["English","Hindi","Spanish","French","German","Arabic","Portuguese","Russian","Japanese","Chinese"],label:"From"}),e.jsx(b,{value:i,onChange:r,options:["Hindi","English","Spanish","French","German","Arabic","Portuguese","Russian","Japanese","Chinese"],label:"To"})]}),s&&e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-emerald-500/20",children:[e.jsxs("div",{className:"text-sm text-gray-500 mb-1",children:[n," → ",i]}),e.jsx("div",{className:"text-white",children:s.split("").reverse().join("")})]}),e.jsx(x,{onClick:()=>{d(`Translation ready from ${n} to ${i}`)},icon:A,label:"Translate"})]})}function Ah({tool:t}){const[s,a]=l.useState([]),[n,o]=l.useState(""),[i,r]=l.useState(new Set);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx(p,{value:n,onChange:o,placeholder:"New habit...",label:"Add Habit"}),e.jsx("div",{className:"pt-6",children:e.jsx(x,{onClick:()=>{n&&(a([...s,n]),o(""))},icon:$,label:"+",variant:"secondary"})})]}),e.jsxs("div",{className:"space-y-2 mt-4",children:[s.map((c,d)=>e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("span",{className:`text-sm ${i.has(d)?"line-through text-gray-600":"text-white"}`,children:c}),e.jsx("button",{onClick:()=>{const h=new Set(i);h.has(d)?h.delete(d):h.add(d),r(h)},className:`w-6 h-6 rounded-lg border ${i.has(d)?"bg-emerald-500 border-emerald-500":"border-white/20"} transition-all`,children:i.has(d)&&"✓"})]},d)),s.length===0&&e.jsx("div",{className:"text-sm text-gray-600 text-center py-4",children:"Add your daily habits to track"})]})]})}function Rh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState([]);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Write your thoughts...",label:"Journal Entry",multiline:!0,icon:A}),e.jsx(x,{onClick:()=>{s&&(o([{text:s,date:new Date().toLocaleDateString()},...n]),a(""))},icon:Uh,label:"Save Entry"}),e.jsxs("div",{className:"mt-4 space-y-2 max-h-40 overflow-y-auto",children:[n.map((i,r)=>e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5 text-sm",children:[e.jsx("span",{className:"text-gray-500 text-xs block mb-1",children:i.date}),e.jsx("span",{className:"text-gray-300",children:i.text})]},r)),n.length===0&&e.jsx("div",{className:"text-sm text-gray-600 text-center py-2",children:"No entries yet"})]})]})}function Ph({tool:t}){const[s,a]=l.useState([]),n=["😊 Great","🙂 Good","😐 Okay","😞 Bad","😢 Awful"];return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"flex justify-center gap-2 mb-4",children:n.map(o=>e.jsx("button",{onClick:()=>a([{mood:o,note:""},...s]),className:"p-3 rounded-xl bg-white/5 border border-white/10 text-lg hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all",children:o},o))}),e.jsx("div",{className:"space-y-1",children:s.slice(0,7).map((o,i)=>e.jsxs("div",{className:"flex items-center gap-2 p-2 rounded-lg bg-white/[0.02]",children:[e.jsx("span",{className:"text-sm",children:o.mood}),e.jsx("span",{className:"text-xs text-gray-600",children:new Date(Date.now()-i*864e5).toLocaleDateString()})]},i))})]})}function Lh({tool:t}){const[s,a]=l.useState(25),[n,o]=l.useState(!1),[i,r]=l.useState(null),c=()=>{if(!n){o(!0);const h=setInterval(()=>{a(u=>u<=1?(clearInterval(h),o(!1),25):u-1)},1e3);r(h)}},d=()=>{clearInterval(i),o(!1)};return e.jsx(m,{tool:t,children:e.jsxs("div",{className:"text-center py-6",children:[e.jsx("div",{className:"w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 flex items-center justify-center mb-4",children:e.jsxs("div",{className:"text-4xl font-bold text-white",children:[Math.floor(s/60),":",String(s%60).padStart(2,"0")]})}),e.jsx("div",{className:"text-gray-500 text-sm mb-4",children:"Focus Session"}),e.jsx("div",{className:"flex justify-center gap-2 mb-4",children:[25,30,45,60].map(h=>e.jsxs("button",{onClick:()=>{n||a(h)},className:`px-4 py-2 rounded-xl text-sm ${s===h?"bg-indigo-600 text-white":"bg-white/5 text-gray-400"} transition-all`,children:[h," min"]},h))}),e.jsx(x,{onClick:n?d:c,icon:n?we:Ae,label:n?"⏹ Stop":"▶ Start Focus"})]})})}function Eh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"text-center py-4",children:e.jsx("div",{className:"w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-orange-500/20 to-pink-500/20 border border-orange-500/30 flex items-center justify-center mb-4",children:e.jsxs("svg",{className:"w-10 h-10 text-orange-400",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M12 2a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"}),e.jsx("path",{d:"M12 10v10"}),e.jsx("path",{d:"M8 18h8"})]})})}),e.jsx(b,{options:["Beginner","Intermediate","Advanced"],label:"Level"}),e.jsx(b,{options:["Morning Flow","Stress Relief","Flexibility","Strength","Bedtime Yoga"],label:"Style"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧘 Yoga Session

Level: ${["Beginner","Intermediate"][Math.floor(Math.random()*2)]}
Duration: ${Math.floor(15+Math.random()*30)} min

Poses:
1. Mountain Pose (5 breaths)
2. Downward Dog (5 breaths)
3. Warrior I (5 breaths each side)
4. Tree Pose (5 breaths each side)
5. Cobra Pose (5 breaths)
6. Child's Pose (10 breaths)
7. Savasana (5 min)

🔥 Calories: ${Math.floor(50+Math.random()*100)}
🧠 Focus: Mind-body connection`),o(!1)},1e3)},icon:$,label:"Generate Yoga Routine"}),s&&e.jsx(g,{value:s})]})}function Fh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Normal","Dry","Oily","Combination","Sensitive"],label:"Skin Type"}),e.jsx(b,{options:["Morning","Evening","Weekly"],label:"Routine"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧴 Skincare Routine: ${["Normal","Oily","Combination"][Math.floor(Math.random()*3)]}

🌅 Morning Routine:
1. Gentle cleanser
2. Toner
3. Vitamin C serum
4. Moisturizer
5. SPF 50 sunscreen

🌙 Evening Routine:
1. Oil cleanser
2. Water-based cleanser
3. Exfoliant (2-3x/week)
4. Serum / Treatment
5. Night cream

📅 Weekly:
• Mask: 2x/week
• Exfoliate: 2-3x/week
• Sheet mask: 1x/week

💡 Tips:
• Use lukewarm water
• Pat dry (don't rub)
• Apply sunscreen even indoors
• Change pillowcase weekly`),o(!1)},1e3)},icon:$,label:"Generate Routine"}),s&&e.jsx(g,{value:s})]})}function Ih({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Casual","Business","Formal","Sporty","Bohemian","Minimalist"],label:"Style"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`👔 Wardrobe Capsule

Style: ${["Casual","Business","Minimalist"][Math.floor(Math.random()*3)]}
Seasons: All seasons

Essential Pieces:
1. White t-shirt (2-3)
2. Blue jeans (1-2)
3. Black trousers
4. Blazer/Jacket
5. Little black dress / Suit
6. Comfortable sneakers
7. Loafers
8. White shirt
9. Knitwear/Sweater
10. Trench coat

🧥 Outerwear: 3 pieces
👗 Dresses: 2-3
👖 Bottoms: 4-5
👕 Tops: 6-8
👟 Shoes: 3-4 pairs

🎯 Total: ${Math.floor(20+Math.random()*15)} pieces
📦 Mix & match: ${Math.floor(30+Math.random()*50)} outfits`),o(!1)},1e3)},icon:G,label:"Plan Wardrobe"}),s&&e.jsx(g,{value:s})]})}function Dh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Birthday","Anniversary","Christmas","Wedding","Graduation","Thanksgiving"],label:"Occasion"}),e.jsx(b,{options:["$0-25","$25-50","$50-100","$100-200","$200+"],label:"Budget"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"Their interests...",label:"Their Interests"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎁 Gift Ideas

For: [Recipient]
Occasion: ${["Birthday","Anniversary","Christmas"][Math.floor(Math.random()*3)]}
Budget: $${Math.floor(15+Math.random()*200)}

Top Picks:

⭐⭐⭐ Personalized gift:
• Custom photo album
• Engraved jewelry
• Personalized art print

⭐⭐ Experience gift:
• Cooking class voucher
• Spa day
• Concert tickets

⭐ Practical gift:
• Smart home device
• Premium subscription
• Quality accessories

💡 Tip: ${["Add a handwritten note","Wrap creatively","Include a small extra gift"][Math.floor(Math.random()*3)]}
🎯 Match Score: ${(80+Math.random()*20).toFixed(0)}%`),o(!1)},1e3)},icon:G,label:"Find Gifts"}),s&&e.jsx(g,{value:s})]})}function Oh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Monthly income",label:"Monthly Income ($)",type:"number"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💰 Personal Budget

Monthly Income: $${(3e3+Math.random()*7e3).toFixed(0)}

📊 Budget Allocation:
🏠 Housing: $${(800+Math.random()*1500).toFixed(0)} (30%)
🍽️ Food: $${(400+Math.random()*600).toFixed(0)} (15%)
🚗 Transport: $${(200+Math.random()*400).toFixed(0)} (10%)
💡 Utilities: $${(150+Math.random()*250).toFixed(0)} (5%)
🎯 Savings: $${(600+Math.random()*1400).toFixed(0)} (20%)
🎉 Fun: $${(200+Math.random()*400).toFixed(0)} (10%)
📚 Other: $${(200+Math.random()*500).toFixed(0)} (10%)

✅ Total: 100%
💰 Savings Goal: $${(5e3+Math.random()*15e3).toFixed(0)}/year
📈 Projected Growth: +${(5+Math.random()*10).toFixed(1)}%`),o(!1)},1e3)},icon:ze,label:"Generate Budget"}),s&&e.jsx(g,{value:s})]})}function Bh({tool:t}){const[s,a]=l.useState([]),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:n,onChange:o,placeholder:"Enter a goal...",label:"New Goal"}),e.jsx(x,{onClick:()=>{n&&(a([...s,{g:n,p:0}]),o(""))},icon:ze,label:"Add Goal",variant:"secondary"}),e.jsx("div",{className:"space-y-2 mt-4",children:s.map((i,r)=>e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsxs("div",{className:"flex justify-between items-center mb-2",children:[e.jsx("span",{className:"text-sm text-white",children:i.g}),e.jsxs("span",{className:"text-xs text-gray-500",children:[i.p,"%"]})]}),e.jsx("div",{className:"h-1.5 rounded-full bg-white/10",children:e.jsx("div",{className:"h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all",style:{width:`${i.p}%`}})}),e.jsx("button",{onClick:()=>{const c=[...s];c[r]={...c[r],p:Math.min(100,c[r].p+10)},a(c)},className:"mt-2 text-xs text-indigo-400 hover:text-indigo-300",children:"+ Update Progress"})]},r))})]})}function Gh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Ingredients you have...",label:"Available Ingredients"}),e.jsx(b,{options:["Breakfast","Lunch","Dinner","Dessert","Snack"],label:"Meal Type"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🍳 Recipe: [Based on your ingredients]

⏱️ Prep: ${Math.floor(5+Math.random()*15)} min
🔥 Cook: ${Math.floor(10+Math.random()*30)} min
📊 Difficulty: ${["Easy","Medium"][Math.floor(Math.random()*2)]}

Ingredients:
• Ingredient 1: 2 cups
• Ingredient 2: 1 tbsp
• Ingredient 3: 3 cloves
• Ingredient 4: to taste

Instructions:
1. Prep all ingredients
2. Heat pan over medium heat
3. Cook until golden brown
4. Season to taste
5. Serve hot

🍽️ Serving: 2 portions
💡 Tip: Garnish with fresh herbs
📊 Nutrition: ${Math.floor(200+Math.random()*400)} cal/serving`),o(!1)},1e3)},icon:kr,label:"Find Recipe"}),s&&e.jsx(g,{value:s})]})}function Hh({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Event type & size",label:"Event Description"}),e.jsx(b,{options:["Upcoming","Social","Corporate","Family","Online"],label:"Category"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎉 Event Plan: [Your Event]

📅 Date: ${new Date(Date.now()+30*864e5).toLocaleDateString()}
👥 Guests: ${Math.floor(10+Math.random()*90)}
📍 Venue: ${["Indoor","Outdoor","Virtual"][Math.floor(Math.random()*3)]}

📋 Checklist:
✅ Venue booked
✅ Guest list created
✅ Catering arranged
✅ Decorations planned
✅ Entertainment organized
✅ Photo/video booked
✅ Invitations sent

💰 Budget: $${(500+Math.random()*5e3).toFixed(0)}
🎯 Timeline: ${Math.floor(2+Math.random()*5)} weeks prep`),o(!1)},1e3)},icon:Ct,label:"Plan Event"}),s&&e.jsx(g,{value:s})]})}function Wh({tool:t}){const[s,a]=l.useState([]),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:n,onChange:o,placeholder:"Skill name...",label:"New Skill"}),e.jsx(x,{onClick:()=>{n&&(a([...s,{s:n,l:10}]),o(""))},icon:$,label:"Add Skill",variant:"secondary"}),e.jsx("div",{className:"space-y-2 mt-4",children:s.map((i,r)=>e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsxs("div",{className:"flex justify-between items-center mb-2",children:[e.jsx("span",{className:"text-sm text-white",children:i.s}),e.jsxs("span",{className:"text-xs text-gray-500",children:["Level $",i.l]})]}),e.jsx("div",{className:"h-1.5 rounded-full bg-white/10",children:e.jsx("div",{className:"h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500",style:{width:`${i.l}%`}})})]},r))})]})}function Uh(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"})})}function Vh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("quantum")?e.jsx(zh,{tool:t}):r.includes("blockchain")||r.includes("contract")?e.jsx(qh,{tool:t}):r.includes("metaverse")||r.includes("avatar")||r.includes("vr")?e.jsx(Qh,{tool:t}):r.includes("robot")||r.includes("automation")?e.jsx(_h,{tool:t}):r.includes("neural")||r.includes("brain")||r.includes("mind")?e.jsx(Kh,{tool:t}):r.includes("hologram")||r.includes("holo")?e.jsx(Yh,{tool:t}):r.includes("nanotech")||r.includes("nano")?e.jsx(Jh,{tool:t}):r.includes("drone")||r.includes("uav")?e.jsx(Xh,{tool:t}):r.includes("gene")||r.includes("dna")||r.includes("genetic")?e.jsx(Zh,{tool:t}):r.includes("fusion")||r.includes("nuclear")?e.jsx(em,{tool:t}):r.includes("solar")||r.includes("renewable")?e.jsx(tm,{tool:t}):r.includes("cyber")||r.includes("security")?e.jsx(sm,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-violet-500/10 border border-violet-500/20 text-center",children:[e.jsx(He,{className:"w-6 h-6 text-violet-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Future"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center",children:[e.jsx(Xn,{className:"w-6 h-6 text-cyan-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Science"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(L,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Tech"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:He}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🚀 ${t.name} executed!

Advanced computation complete
Status: Successful
Futuristic technology analysis ready

✅ Results generated`),i(!1)},1200)},icon:$,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function zh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border border-purple-500/20 text-center",children:[e.jsx("div",{className:"text-2xl font-bold text-purple-400",children:"32"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Qubits"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 text-center",children:[e.jsx("div",{className:"text-2xl font-bold text-emerald-400",children:"1000x"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Speedup"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter quantum circuit or algorithm...",label:"Quantum Input",multiline:!0,icon:Da}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`⚛️ Quantum Computing Simulation

Algorithm: ${s||"Shor's Algorithm"}
Qubits: 32
Simulation Mode: Quantum Circuit

Results:
• Superposition states: Active
• Quantum entanglement: True
• Interference pattern: Detected
• Decoherence rate: 0.001%

Execution Time: ${(Math.random()*100+10).toFixed(0)}ms
Classical Equivalent: ${(Math.random()*1e3+500).toFixed(0)}ms
Speedup: ${(Math.random()*50+10).toFixed(0)}x`),i(!1)},2e3)},icon:Da,label:"Run Quantum Simulation"}),n&&e.jsx(g,{value:n,label:"Simulation Results"})]})}function qh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your smart contract...",label:"Contract Description",multiline:!0,icon:D}),e.jsx(b,{options:["Ethereum","Solana","Polygon","Arbitrum","Avalanche"],label:"Blockchain"}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🔗 Smart Contract Generated

Contract: ${s||"Custom Contract"}
Blockchain: Ethereum
Network: Sepolia Testnet

pragma solidity ^0.8.19;
contract ${(s||"MyContract").replace(/\s+/g,"")} {
    address public owner;
    constructor() {
        owner = msg.sender;
    }
}

✅ Contract verified
📊 Gas estimate: 245,000 units`),i(!1)},1800)},icon:D,label:"Generate Smart Contract"}),n&&e.jsx(g,{value:n})]})}function Qh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your metaverse avatar...",label:"Avatar Description",multiline:!0}),e.jsx("div",{className:"grid grid-cols-3 gap-2 mt-4",children:["Human","Fantasy","Cyberpunk","Cartoon","Realistic","Minimal"].map(r=>e.jsx("button",{className:"px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:border-indigo-500/30 transition-all",children:r},r))}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌐 Metaverse Avatar Created

Style: ${s||"Custom"}
Polygons: 24,500
Textures: 4K PBR
Rigging: Full body IK

📥 Ready for: VRChat, Decentraland, Meta Horizon
🎮 File size: 12.5 MB`),i(!1)},1500)},icon:L,label:"Create Avatar"}),n&&e.jsx(g,{value:n})]})}function _h({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3 mb-4",children:["🦾","⚡","🔋"].map((r,c)=>e.jsx("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center text-3xl",children:r},c))}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter robot command or sequence...",label:"Robot Command",multiline:!0,icon:ye}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🤖 Robot Control

Command Received: ${s||"STANDARD_SEQUENCE"}
Motor Status: ✅ All systems online
Battery: 85%

Executing Movement Sequence:
1. Forward 10cm ✓
2. Rotate 90° ✓
3. Sensor scan ✓
4. Object detected (${(Math.random()*10).toFixed(1)}m)
5. Return to origin ✓

🗺️ Environment mapped: ${(Math.random()*100).toFixed(1)}%
✅ Sequence complete`),i(!1)},1e3)},icon:ye,label:"Send Command"}),n&&e.jsx(g,{value:n})]})}function Kh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe neural network task...",label:"Network Description",multiline:!0,icon:Ia}),e.jsx(b,{options:["Image Recognition","NLP","Time Series","Reinforcement Learning","GAN"],label:"Architecture"}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🧠 Neural Network Analysis

Architecture: Deep Neural Network
Layers: ${Math.floor(5+Math.random()*30)}
Parameters: ${(Math.random()*100+1).toFixed(1)}M

Training Results:
• Accuracy: ${(85+Math.random()*14).toFixed(1)}%
• Loss: ${(Math.random()*.5).toFixed(3)}
• Epochs: ${Math.floor(10+Math.random()*90)}

📊 Model Size: ${(Math.random()*500).toFixed(0)}MB
⚡ Inference: ${(Math.random()*50+1).toFixed(1)}ms`),i(!1)},1500)},icon:Ia,label:"Run Neural Network"}),n&&e.jsx(g,{value:n})]})}function Yh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"p-6 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 text-center",children:[e.jsx("div",{className:"text-6xl mb-2",children:"🌐"}),e.jsx("div",{className:"text-indigo-400 font-medium",children:"Holographic Projection Ready"})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Describe hologram content...",label:"Hologram Content",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🪄 Hologram Generated!

Content: ${s||"3D Display"}
Resolution: 8K
Format: Volumetric

Depth: Full 3D
Interaction: Gesture-enabled
Viewing Angle: 360°

📊 Quality: ${(85+Math.random()*15).toFixed(0)}%`),i(!1)},1e3)},icon:L,label:"Generate Hologram"}),n&&e.jsx(g,{value:n})]})}function Jh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe nanostructure...",label:"Design Description",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🧬 Nanotechnology Design

Design: ${s||"Molecular Structure"}
Scale: ${(Math.random()*100).toFixed(1)} nm
Material: ${["Carbon","Gold","Silicon","Graphene"][Math.floor(Math.random()*4)]}

Properties:
• Strength: ${(70+Math.random()*30).toFixed(0)}%
• Conductivity: ${(80+Math.random()*20).toFixed(0)}%
• Reactivity: ${(Math.random()*50).toFixed(0)}%

✅ Design validated
🔬 Synthesis: Feasible`),i(!1)},1e3)},icon:Xn,label:"Simulate"}),n&&e.jsx(g,{value:n})]})}function Xh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-sm text-emerald-400 font-bold",children:"✅ Connected"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Drone Status"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-sm text-white font-bold",children:"85%"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Battery"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter flight path or mission...",label:"Mission",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🚁 Drone Mission Plan

Mission: ${s||"Aerial Survey"}
Altitude: ${Math.floor(30+Math.random()*100)}m
Range: ${Math.floor(1+Math.random()*5)}km
Duration: ${Math.floor(10+Math.random()*30)} min

Waypoints:
1. Takeoff →
2. Survey area A
3. Survey area B
4. Return to base

📡 Signal: Excellent
🔒 GPS: Locked (12 satellites)
✅ Mission ready`),i(!1)},1e3)},icon:Xa,label:"Plan Mission"}),n&&e.jsx(g,{value:n})]})}function Zh({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter gene sequence or description...",label:"Genetic Input",multiline:!0,icon:Oa}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🧬 Gene Analysis Complete

Sequence: ${s||"Standard Reference"}
Length: ${Math.floor(100+Math.random()*900)} base pairs

Analysis:
• Gene type: ${["Coding","Regulatory","Non-coding"][Math.floor(Math.random()*3)]}
• Function: ${["Protein synthesis","Cell regulation","Immune response"][Math.floor(Math.random()*3)]}
• Expression level: ${(Math.random()*100).toFixed(1)}%

✅ Analysis complete
🔬 Confidence: ${(90+Math.random()*10).toFixed(0)}%`),i(!1)},1500)},icon:Oa,label:"Analyze Gene"}),n&&e.jsx(g,{value:n})]})}function em({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter fusion parameters...",label:"Fusion Parameters",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`⚡ Fusion Simulation

Reactor: Tokamak
Temperature: ${(100+Math.random()*50).toFixed(1)} million °C
Plasma Pressure: ${(Math.random()*10).toFixed(2)} atm

Energy Output: ${(Math.random()*500).toFixed(0)} MW
Efficiency: ${(Math.random()*30+5).toFixed(1)}%
Plasma Stability: ${(70+Math.random()*30).toFixed(0)}%

✅ Simulation running
⏱️ Confinement time: ${(Math.random()*10+1).toFixed(1)}s`),i(!1)},2e3)},icon:Zn,label:"Run Simulation"}),n&&e.jsx(g,{value:n})]})}function tm({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Location or energy parameters...",label:"Input"}),e.jsx(b,{options:["Solar","Wind","Hydropower","Geothermal","Biomass"],label:"Energy Type"}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`☀️ Renewable Energy Analysis

Type: ${["Solar","Wind","Geothermal"][Math.floor(Math.random()*3)]}
Capacity: ${Math.floor(1+Math.random()*100)} MW

Generation:
• Daily: ${Math.floor(Math.random()*1e3)+100} MWh
• Monthly: ${Math.floor(Math.random()*3e4)+3e3} MWh
• CO₂ Saved: ${Math.floor(Math.random()*5e4+5e3)} tons/yr

Efficiency: ${(75+Math.random()*20).toFixed(0)}%
ROI: ${(5+Math.random()*20).toFixed(1)} years

✅ Green energy ready`),i(!1)},1e3)},icon:Zn,label:"Analyze Energy"}),n&&e.jsx(g,{value:n})]})}function sm({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter target/system to analyze...",label:"System Input",multiline:!0,icon:ue}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🛡️ Cybersecurity Analysis

Target: ${s||"Network"}

Vulnerabilities Found: ${Math.floor(Math.random()*10)}
• Port scan: ${Math.floor(Math.random()*100)} open ports
• ${Math.floor(Math.random()*5)} critical issues
• ${Math.floor(Math.random()*8)} medium issues

Risk Score: ${(Math.random()*100).toFixed(0)}/100
Threat Level: ${["Low","Medium","High","Critical"][Math.floor(Math.random()*4)]}

✅ Security report generated
🔒 Recommendations: ${Math.floor(3+Math.random()*8)}`),i(!1)},1500)},icon:ue,label:"Run Security Scan"}),n&&e.jsx(g,{value:n})]})}function Ia(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"}),e.jsx("path",{d:"M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"})]})}function Da(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 12c-2-2.5-4-4-6-4s-4 1.5-4 4 1.5 4 4 4 4-1.5 6-4zm0 0c2 2.5 4 4 6 4s4-1.5 4-4-1.5-4-4-4-4 1.5-6 4z"})})}function Xn(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"1"}),e.jsx("path",{d:"M20.2 20.2c-4.5 4.5-11.9 4.5-16.4 0s-4.5-11.9 0-16.4 11.9-4.5 16.4 0"}),e.jsx("path",{d:"M3.8 20.2c4.5 4.5 11.9 4.5 16.4 0s4.5-11.9 0-16.4-11.9-4.5-16.4 0"})]})}function Oa(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"2",r:"1.5"}),e.jsx("circle",{cx:"12",cy:"22",r:"1.5"}),e.jsx("path",{d:"M8 5c0 2 0 4 4 6s4 4 4 6"}),e.jsx("path",{d:"M8 19c0-2 0-4 4-6s4-4 4-6"}),e.jsx("path",{d:"M4 4c4-2 8 0 8 4"}),e.jsx("path",{d:"M4 20c4 2 8 0 8-4"})]})}function Zn(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"4"}),e.jsx("path",{d:"M12 2v2"}),e.jsx("path",{d:"M12 20v2"}),e.jsx("path",{d:"m4.93 4.93 1.41 1.41"}),e.jsx("path",{d:"m17.66 17.66 1.41 1.41"}),e.jsx("path",{d:"M2 12h2"}),e.jsx("path",{d:"M20 12h2"}),e.jsx("path",{d:"m6.34 17.66-1.41 1.41"}),e.jsx("path",{d:"m19.07 4.93-1.41 1.41"})]})}function am({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("weather")||r.includes("temperature")||r.includes("climate")?e.jsx(nm,{tool:t}):r.includes("carbon")||r.includes("footprint")?e.jsx(rm,{tool:t}):r.includes("air")||r.includes("air quality")||r.includes("pollution")?e.jsx(om,{tool:t}):r.includes("water")&&!r.includes("drink")&&!r.includes("track")?e.jsx(im,{tool:t}):r.includes("recycling")||r.includes("recycle")||r.includes("waste")?e.jsx(lm,{tool:t}):r.includes("solar")||r.includes("solar energy")?e.jsx(cm,{tool:t}):r.includes("wind")||r.includes("wind energy")?e.jsx(dm,{tool:t}):r.includes("forest")||r.includes("tree")||r.includes("deforest")?e.jsx(um,{tool:t}):r.includes("ocean")||r.includes("marine")||r.includes("sea")?e.jsx(hm,{tool:t}):r.includes("earthquake")||r.includes("seismic")?e.jsx(mm,{tool:t}):r.includes("biodiversity")||r.includes("wildlife")||r.includes("species")?e.jsx(xm,{tool:t}):r.includes("greenhouse")||r.includes("emission")?e.jsx(pm,{tool:t}):r.includes("noise")||r.includes("sound")&&r.includes("level")?e.jsx(gm,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(L,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Climate"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(Tr,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Weather"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-center",children:[e.jsx(It,{className:"w-6 h-6 text-green-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Nature"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:L}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌍 ${t.name} Results

Analysis complete
Input: ${s||"Global"}
Environmental metrics processed
✅ Results ready`),i(!1)},1e3)},icon:ds,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function nm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(Oe,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsxs("div",{className:"text-xs text-gray-500",children:["$",(20+Math.random()*15).toFixed(0),"°C"]})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(it,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsxs("div",{className:"text-xs text-gray-500",children:["$",(40+Math.random()*50).toFixed(0),"%"]})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center",children:[e.jsx(tn,{className:"w-6 h-6 text-cyan-400 mx-auto"}),e.jsxs("div",{className:"text-xs text-gray-500",children:["$",(5+Math.random()*25).toFixed(0)," km/h"]})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter location...",label:"Location",icon:zt}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🌤️ Weather: ${s||"Current Location"}

Temperature: ${(20+Math.random()*15).toFixed(1)}°C
Feels Like: ${(18+Math.random()*17).toFixed(1)}°C
Humidity: ${(40+Math.random()*50).toFixed(0)}%
Wind: ${(5+Math.random()*25).toFixed(1)} km/h
Precipitation: ${(Math.random()*100).toFixed(0)}%
UV Index: ${Math.floor(Math.random()*11)}

📅 Forecast:
Today: ${["Sunny","Partly Cloudy","Cloudy","Rain","Clear"][Math.floor(Math.random()*5)]}
Tomorrow: ${["Sunny","Cloudy","Rain","Clear"][Math.floor(Math.random()*4)]}

🌅 Sunrise: ${String(Math.floor(Math.random()*5+5)).padStart(2,"0")}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}
🌇 Sunset: ${String(Math.floor(Math.random()*3+17)).padStart(2,"0")}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}`),r(!1)},1e3)},icon:Oe,label:i?"Fetching...":"Get Weather"}),n&&e.jsx(g,{value:n,label:"Weather Report"})]})}function rm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"km/month",label:"Car Travel",type:"number"}),e.jsx(p,{value:"",onChange:()=>{},placeholder:"kWh/month",label:"Electricity",type:"number"})]}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌱 Carbon Footprint Calculator

Your Annual Footprint: ${(2+Math.random()*8).toFixed(1)} tons CO₂

Breakdown:
🚗 Car Travel: ${(Math.random()*3).toFixed(1)} tons
⚡ Electricity: ${(Math.random()*2).toFixed(1)} tons
🍽️ Food: ${(Math.random()*2).toFixed(1)} tons
✈️ Flights: ${(Math.random()*2).toFixed(1)} tons

🌍 vs Global Avg: ${Math.random()>.5?"+":"-"}${(Math.random()*30).toFixed(0)}%

💡 Reduction Tips:
1. Use public transport (save ${(Math.random()*1).toFixed(1)} tons)
2. Switch to LED bulbs
3. Reduce food waste
4. Plant ${Math.floor(5+Math.random()*20)} trees`),o(!1)},1e3)},icon:It,label:n?"Calculating...":"Calculate Footprint"}),s&&e.jsx(g,{value:s})]})}function om({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter location...",label:"Location",icon:zt}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🌬️ Air Quality: ${s||"Your Area"}

AQI: ${Math.floor(20+Math.random()*180)}
Status: ${["Good","Moderate","Unhealthy for Sensitive","Unhealthy"][Math.floor(Math.random()*4)]}

PM2.5: ${(5+Math.random()*100).toFixed(0)} µg/m³
PM10: ${(10+Math.random()*150).toFixed(0)} µg/m³
NO₂: ${(10+Math.random()*50).toFixed(0)} ppb
O₃: ${(20+Math.random()*60).toFixed(0)} ppb

😷 Health Recommendation:
${Math.random()>.5?"Good for outdoor activities":"Limit outdoor activities"}`),r(!1)},1e3)},icon:Te,label:"Check Air Quality"}),n&&e.jsx(g,{value:n})]})}function im({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Water source description",label:"Water Source"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💧 Water Analysis

Source: [Sample]
pH Level: ${(6.5+Math.random()*2).toFixed(1)}
TDS: ${(50+Math.random()*400).toFixed(0)} ppm
Turbidity: ${(Math.random()*5).toFixed(1)} NTU
Hardness: ${(50+Math.random()*200).toFixed(0)} mg/L

✅ Potable: ${Math.random()>.3?"Yes":"Needs Treatment"}
🔬 Contaminants: ${Math.random()>.7?"Trace detected":"None detected"}

📊 Quality Score: ${(60+Math.random()*40).toFixed(0)}/100`),o(!1)},1e3)},icon:it,label:"Analyze Water"}),s&&e.jsx(g,{value:s})]})}function lm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"What do you want to recycle?",label:"Item",icon:ds}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`♻️ Recycling Guide for: ${s||"Example Item"}

Category: ${["Plastic","Paper","Glass","Metal","Electronic","Organic"][Math.floor(Math.random()*6)]}
Recyclable: ${Math.random()>.3?"✅ Yes":"❌ No - Special handling"}

Instructions:
1. Clean the item thoroughly
2. Remove non-recyclable parts
3. Separate by material type
4. Place in appropriate bin

📍 Nearest center: ${Math.floor(Math.random()*10+1)} km away
🌱 Environmental impact: ${(Math.random()*5+.1).toFixed(1)} kg CO₂ saved

💡 Eco Tip: Reduce first, then reuse, then recycle`),r(!1)},800)},icon:ds,label:"Check Recycling"}),n&&e.jsx(g,{value:n})]})}function cm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Location or address",label:"Location",icon:zt}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`☀️ Solar Energy Calculator

Location: [Your Roof]
Solar Irradiance: ${(4+Math.random()*3).toFixed(1)} kWh/m²/day

Recommended System: ${(3+Math.random()*7).toFixed(1)} kW
Panels Needed: ${Math.floor(8+Math.random()*16)}
Roof Area: ${(20+Math.random()*30).toFixed(0)} m²

🌞 Annual Generation: ${(3e3+Math.random()*7e3).toFixed(0)} kWh
💰 Annual Savings: $${(300+Math.random()*1200).toFixed(0)}
📈 Payback Period: ${(3+Math.random()*10).toFixed(1)} years
🌱 CO₂ Offset: ${(2+Math.random()*6).toFixed(1)} tons/year

✅ Great potential for solar!`),o(!1)},1e3)},icon:Oe,label:"Calculate Solar"}),s&&e.jsx(g,{value:s})]})}function dm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Location",label:"Location"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`💨 Wind Energy Assessment

Location: [Your Area]
Avg. Wind Speed: ${(5+Math.random()*10).toFixed(1)} m/s
Wind Class: ${["Class 3","Class 4","Class 5","Class 6"][Math.floor(Math.random()*4)]}

Turbine Specs:
• Capacity: ${Math.floor(1+Math.random()*5)} MW
• Hub Height: ${Math.floor(80+Math.random()*40)} m
• Annual Output: ${(2e3+Math.random()*8e3).toFixed(0)} MWh

💰 Revenue: $${(200+Math.random()*800).toFixed(0)}K/year
🌱 CO₂ Avoided: ${(1e3+Math.random()*4e3).toFixed(0)} tons/year

📊 Feasibility: ${["Good","Excellent","Moderate"][Math.floor(Math.random()*3)]}`),o(!1)},1e3)},icon:tn,label:"Assess Wind Energy"}),s&&e.jsx(g,{value:s})]})}function um({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Region or country",label:"Region"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌲 Forest Cover Analysis

Region: [Selected Area]
Forest Cover: ${(20+Math.random()*60).toFixed(0)}%
Tree Density: ${(100+Math.random()*400).toFixed(0)} trees/hectare

📊 Change Over Time:
• Last Year: ${Math.random()>.5?"+":"-"}${(Math.random()*5).toFixed(1)}%
• Last 5 Years: ${Math.random()>.5?"+":"-"}${(Math.random()*15).toFixed(1)}%

⚠️ Deforestation Risk: ${["Low","Moderate","High"][Math.floor(Math.random()*3)]}
🌱 Reforestation Potential: ${(Math.floor(Math.random()*1e3)+100).toLocaleString()} hectares

✅ Monitoring active`),o(!1)},1e3)},icon:It,label:"Track Forest"}),s&&e.jsx(g,{value:s})]})}function hm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Ocean region",label:"Region"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌊 Ocean Health Report

Region: [Ocean Region]
Sea Temperature: ${(15+Math.random()*15).toFixed(1)}°C
pH Level: ${(7.8+Math.random()*.5).toFixed(2)}
Salinity: ${(32+Math.random()*5).toFixed(1)} ppt

🦈 Biodiversity Index: ${(Math.random()*10).toFixed(1)}
♻️ Plastic Concentration: ${(Math.random()*10).toFixed(1)} particles/L
🌡️ Coral Bleaching Risk: ${["Low","Moderate","High","Critical"][Math.floor(Math.random()*4)]}

📈 Sea Level Rise: ${(Math.random()*10).toFixed(1)} mm/yr
✅ Analysis complete`),o(!1)},1e3)},icon:fm,label:"Analyze Ocean"}),s&&e.jsx(g,{value:s})]})}function mm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Region",label:"Region",icon:zt}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌋 Seismic Activity Report

Region: [Selected Region]

Latest Activity:
• Magnitude: ${(1+Math.random()*8).toFixed(1)}
• Depth: ${Math.floor(Math.random()*100)+2} km
• Time: ${new Date().toLocaleString()}
• Status: ${["Normal","Watch","Advisory","Warning"][Math.floor(Math.random()*4)]}

📊 30-Day Summary:
• Total Events: ${Math.floor(Math.random()*50)}
• Largest: ${(4+Math.random()*4).toFixed(1)}
• Smallest: ${(Math.random()*3).toFixed(1)}

✅ Monitoring active
🔔 Alerts configured`),o(!1)},1e3)},icon:we,label:"Monitor Earthquakes"}),s&&e.jsx(g,{value:s})]})}function xm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Ecosystem or region",label:"Ecosystem"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🦋 Biodiversity Report

Ecosystem: [Selected Region]

Species Count:
• Plants: ${Math.floor(100+Math.random()*900)}
• Birds: ${Math.floor(20+Math.random()*180)}
• Mammals: ${Math.floor(10+Math.random()*90)}
• Reptiles: ${Math.floor(5+Math.random()*45)}
• Insects: ${Math.floor(500+Math.random()*4500)}

🌿 Endemic Species: ${Math.floor(5+Math.random()*50)}
⚠️ Threatened: ${Math.floor(2+Math.random()*20)}

📊 Health Index: ${(50+Math.random()*50).toFixed(0)}/100
✅ Assessment complete`),o(!1)},1e3)},icon:It,label:"Assess Biodiversity"}),s&&e.jsx(g,{value:s})]})}function pm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Country or industry",label:"Target"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🏭 Greenhouse Gas Emissions

Target: [Selected Entity]
Total Emissions: ${(100+Math.random()*1e4).toFixed(0)} kt CO₂e

Breakdown:
• CO₂: ${(50+Math.random()*5e3).toFixed(0)} kt
• CH₄: ${(5+Math.random()*500).toFixed(0)} kt
• N₂O: ${(1+Math.random()*100).toFixed(0)} kt

📈 Trend: ${["Rising","Stable","Declining","Paris Target"][Math.floor(Math.random()*4)]}
🎯 Net Zero Target: ${["2030","2040","2050","2060"][Math.floor(Math.random()*4)]}

✅ Tracking active`),o(!1)},1e3)},icon:bm,label:"Track Emissions"}),s&&e.jsx(g,{value:s})]})}function gm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Location",label:"Location"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔊 Noise Level Monitoring

Location: [Selected]
Current Level: ${(30+Math.random()*60).toFixed(0)} dB

Classification: ${["Quiet","Moderate","Loud","Very Loud"][Math.floor(Math.random()*4)]}

📊 24h Profile:
• Morning: ${(30+Math.random()*20).toFixed(0)} dB
• Afternoon: ${(40+Math.random()*30).toFixed(0)} dB
• Evening: ${(35+Math.random()*25).toFixed(0)} dB
• Night: ${(20+Math.random()*15).toFixed(0)} dB

✅ Safe Limit: ${Math.random()>.4?"✅ Within limits":"⚠️ Exceeds recommendations"}
💡 Tip: ${["Use ear protection","Consider soundproofing","Move away from source"][Math.floor(Math.random()*3)]}`),o(!1)},800)},icon:we,label:"Monitor Noise"}),s&&e.jsx(g,{value:s})]})}function zt(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"})})}function fm(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c.5 0 .9.2 1.3.5"}),e.jsx("path",{d:"M2 12c.6.5 1.2 1 2.5 1 1.3 0 2.5-1 4.5-1s3.2 1 4.5 1c1.3 0 2.5-1 4.5-1 1.3 0 2.5 1 3.5 1"}),e.jsx("path",{d:"M2 18c.6.5 1.2 1 2.5 1 1.3 0 2.5-1 4.5-1s3.2 1 4.5 1c1.3 0 2.5-1 4.5-1 1.3 0 2.5 1 3.5 1"})]})}function bm(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M21.73 18l-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"}),e.jsx("path",{d:"M12 9v4"}),e.jsx("path",{d:"M12 17h.01"})]})}function ym({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("movie")||r.includes("film")||r.includes("show")||r.includes("tv")?e.jsx(jm,{tool:t}):r.includes("music")||r.includes("song")||r.includes("playlist")||r.includes("audio")?e.jsx(vm,{tool:t}):r.includes("game")||r.includes("gaming")||r.includes("play")?e.jsx(wm,{tool:t}):r.includes("book")||r.includes("novel")||r.includes("read")?e.jsx(Mm,{tool:t}):r.includes("ticket")||r.includes("event")||r.includes("concert")?e.jsx(Sm,{tool:t}):r.includes("stream")||r.includes("watcher")||r.includes("media")?e.jsx(Cm,{tool:t}):r.includes("photo")||r.includes("photography")||r.includes("camera")?e.jsx(Nm,{tool:t}):r.includes("podcast")||r.includes("radio")?e.jsx($m,{tool:t}):r.includes("dance")||r.includes("choreo")?e.jsx(km,{tool:t}):r.includes("karaoke")||r.includes("sing")?e.jsx(Tm,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-pink-500/10 border border-pink-500/20 text-center",children:[e.jsx(us,{className:"w-6 h-6 text-pink-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Movies"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center",children:[e.jsx(pe,{className:"w-6 h-6 text-purple-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Music"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(We,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Games"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:J}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎬 ${t.name} Results

Content processed
Status: Ready
Entertainment data generated
✅ Enjoy!`),i(!1)},800)},icon:G,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function jm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Search movies...",label:"Movie Search",icon:us}),e.jsx(b,{options:["Action","Comedy","Drama","Sci-Fi","Horror","Romance","Thriller","Documentary"],label:"Genre"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎬 Movie Recommendations

Found: ${Math.floor(20+Math.random()*80)} movies

Top Picks:

1. ⭐ ${["The Last Horizon (2026)","Digital Dreams (2026)","Echoes of Time (2025)","Quantum Shift (2026)"][Math.floor(Math.random()*4)]}
   Rating: ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(120+Math.random()*30)} min

2. ⭐ ${["City Lights (2025)","Mountain Echo (2026)","Starlight Express (2025)","Urban Legends (2026)"][Math.floor(Math.random()*4)]}
   Rating: ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(100+Math.random()*40)} min

3. ⭐ ${["The Final Chapter (2026)","Neon Nights (2025)","Timeless (2026)","Beyond (2025)"][Math.floor(Math.random()*4)]}
   Rating: ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(110+Math.random()*30)} min

🎯 Match: ${(80+Math.random()*20).toFixed(0)}%
📺 Where to watch: ${["Netflix","Prime Video","Disney+","HBO Max"][Math.floor(Math.random()*4)]}`),o(!1)},1e3)},icon:us,label:n?"Searching...":"Browse Movies"}),s&&e.jsx(g,{value:s})]})}function vm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Search songs, artist...",label:"Music Search",icon:pe}),e.jsx(b,{options:["Pop","Rock","Hip Hop","Electronic","Classical","Jazz","R&B","Country"],label:"Genre"}),e.jsx("div",{className:"grid grid-cols-4 gap-2 mt-4",children:["🎵","🎶","🎤","🎧"].map((i,r)=>e.jsx("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center text-2xl hover:bg-indigo-500/10 transition-all cursor-pointer",children:i},r))}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎵 Music Explorer

Trending: ${["Pop Hits 2026","Electronic Vibes","Acoustic Sessions"][Math.floor(Math.random()*3)]}

Playlist Stats:
• Songs: ${Math.floor(20+Math.random()*30)}
• Duration: ${Math.floor(60+Math.random()*60)} min
• Followers: ${Math.floor(1e3+Math.random()*999e3).toLocaleString()}

Top Tracks:
1. 🎵 Track One (${(3+Math.random()*3).toFixed(1)} min)
2. 🎵 Track Two (${(3+Math.random()*3).toFixed(1)} min)
3. 🎵 Track Three (${(3+Math.random()*3).toFixed(1)} min)

🎧 Genre: ${["Pop","Electronic","Alternative"][Math.floor(Math.random()*3)]}`),o(!1)},1e3)},icon:pe,label:"Explore Music"}),s&&e.jsx(g,{value:s})]})}function wm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-4 gap-2 mb-4",children:["🎮","🎲","🎯","🏆"].map((i,r)=>e.jsx("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center text-2xl hover:bg-amber-500/10 transition-all",children:i},r))}),e.jsx(b,{options:["Action","RPG","Strategy","Simulation","Sports","Puzzle","Adventure"],label:"Genre"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎮 Gaming Hub

Hot Games Right Now:

1. 🏆 CyberQuest 2026
   Rating: ${(8+Math.random()*2).toFixed(1)}/10 • Open World RPG

2. 🏆 Battle Arena X
   Rating: ${(8+Math.random()*2).toFixed(1)}/10 • Multiplayer FPS

3. 🏆 Kingdom Builders
   Rating: ${(8+Math.random()*2).toFixed(1)}/10 • Strategy Sim

4. 🏆 Speed Racer Pro
   Rating: ${(8+Math.random()*2).toFixed(1)}/10 • Racing

📊 Your Stats:
🏅 Games Played: ${Math.floor(10+Math.random()*100)}
⭐ Achievements: ${Math.floor(50+Math.random()*500)}
⏱️ Playtime: ${Math.floor(50+Math.random()*500)} hours`),o(!1)},1e3)},icon:We,label:"Discover Games"}),s&&e.jsx(g,{value:s})]})}function Mm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Search books...",label:"Book Search",icon:A}),e.jsx(b,{options:["Fiction","Non-Fiction","Sci-Fi","Mystery","Biography","Self-Help","Romance"],label:"Genre"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📚 Book Recommendations

Found: ${Math.floor(50+Math.random()*200)} books

Top Picks:

1. 📖 "The Art of Tomorrow" — ${["John Smith","Sarah Lee","Alex Chen"][Math.floor(Math.random()*3)]}
   ⭐ ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(200+Math.random()*200)} pages

2. 📖 "Digital Horizons" — ${["Emily Park","David Brown","Lisa Wang"][Math.floor(Math.random()*3)]}
   ⭐ ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(250+Math.random()*150)} pages

3. 📖 "The Last Chapter" — ${["Michael Scott","Anna James","Tom Lee"][Math.floor(Math.random()*3)]}
   ⭐ ${(7+Math.random()*3).toFixed(1)}/10 • ${Math.floor(180+Math.random()*200)} pages

📚 Reading Stats:
• Books Read: ${Math.floor(5+Math.random()*50)}
• Pages Read: ${Math.floor(1e3+Math.random()*1e4).toLocaleString()}
• Reading Streak: ${Math.floor(1+Math.random()*30)} days`),o(!1)},1e3)},icon:A,label:"Browse Books"}),s&&e.jsx(g,{value:s})]})}function Sm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"City or location",label:"Location"}),e.jsx(b,{options:["Concerts","Sports","Theatre","Comedy","Festivals","Exhibitions"],label:"Category"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎪 Events Near You

Found: ${Math.floor(10+Math.random()*30)} events

Upcoming:

1. 🎵 ${["Summer Music Fest","Rock Concert","Jazz Night"][Math.floor(Math.random()*3)]}
   📍 Venue • ${new Date(Date.now()+Math.floor(Math.random()*30)*864e5).toLocaleDateString()}
   🎫 From $${Math.floor(25+Math.random()*100)}

2. 🎭 ${["Comedy Show","Broadway Play","Dance Performance"][Math.floor(Math.random()*3)]}
   📍 Theater • ${new Date(Date.now()+Math.floor(Math.random()*30)*864e5).toLocaleDateString()}
   🎫 From $${Math.floor(30+Math.random()*80)}

3. 🏆 ${["Basketball Game","Football Match","Tennis Open"][Math.floor(Math.random()*3)]}
   📍 Stadium • ${new Date(Date.now()+Math.floor(Math.random()*30)*864e5).toLocaleDateString()}
   🎫 From $${Math.floor(15+Math.random()*150)}`),o(!1)},1e3)},icon:Am,label:"Find Events"}),s&&e.jsx(g,{value:s})]})}function Cm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Search content...",label:"Search",icon:Ps}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📺 Streaming Guide

Trending Now:

1. 🔥 ${["The Crown S6","Stranger Things 5","House of Dragons"][Math.floor(Math.random()*3)]}
   ${["Netflix","Prime Video","Disney+","HBO"][Math.floor(Math.random()*4)]} • ${(8+Math.random()*2).toFixed(1)}/10

2. 🔥 ${["The Last of Us","Wednesday S2","The Bear S3"][Math.floor(Math.random()*3)]}
   ${["Netflix","Prime Video","Disney+","HBO"][Math.floor(Math.random()*4)]} • ${(8+Math.random()*2).toFixed(1)}/10

3. 🔥 ${["Squid Game S2","Bridgerton S4","The Witcher S4"][Math.floor(Math.random()*3)]}
   ${["Netflix","Prime Video","Disney+","HBO"][Math.floor(Math.random()*4)]} • ${(8+Math.random()*2).toFixed(1)}/10

📊 Total: ${Math.floor(100+Math.random()*900)} shows available
🎯 Personalized picks ready`),o(!1)},1e3)},icon:Pm,label:"Browse Streaming"}),s&&e.jsx(g,{value:s})]})}function Nm({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3 mb-4",children:["📷","📸","🎥"].map((s,a)=>e.jsx("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center text-3xl hover:bg-indigo-500/10 transition-all cursor-pointer",children:s},a))}),e.jsx(b,{options:["Portrait","Landscape","Street","Macro","Night","Wildlife"],label:"Genre"}),e.jsx(b,{options:["Beginner","Intermediate","Advanced","Professional"],label:"Level"}),e.jsx(x,{onClick:()=>{},icon:Lm,label:"Get Photography Tips"})]})}function $m({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Technology","Business","True Crime","Comedy","Science","Education","Health"],label:"Category"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎙️ Podcast Discovery

Top Episodes:

1. 🎧 "The Future of AI"
   Tech Weekly • ${Math.floor(30+Math.random()*30)} min • ★${(8+Math.random()*2).toFixed(1)}

2. 🎧 "Success Stories"
   Business Hour • ${Math.floor(30+Math.random()*30)} min • ★${(8+Math.random()*2).toFixed(1)}

3. 🎧 "The Mystery Files"
   True Crime • ${Math.floor(30+Math.random()*30)} min • ★${(8+Math.random()*2).toFixed(1)}

📊 ${Math.floor(1e3+Math.random()*99e3).toLocaleString()} episodes available
⏱️ Listen time: ${Math.floor(10+Math.random()*200)} hours
🎯 Recommendations ready`),o(!1)},1e3)},icon:Em,label:"Discover Podcasts"}),s&&e.jsx(g,{value:s})]})}function km({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-4 gap-2 mb-4",children:["💃","🕺","🩰","🔥"].map((s,a)=>e.jsx("div",{className:"p-3 rounded-xl bg-pink-500/10 border border-pink-500/20 text-center text-2xl hover:bg-pink-500/20 cursor-pointer",children:s},a))}),e.jsx(b,{options:["Hip Hop","Contemporary","Ballet","Salsa","Breakdance","Jazz","Tap"],label:"Style"}),e.jsx(b,{options:["Beginner","Intermediate","Advanced"],label:"Level"}),e.jsx(x,{onClick:()=>{},icon:pe,label:"Learn Dance Moves"})]})}function Tm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-4",children:[e.jsx("div",{className:"w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center mb-2",children:e.jsx(pe,{className:"w-8 h-8 text-purple-400"})}),e.jsx("div",{className:"text-white font-medium",children:"🎤 Karaoke"})]}),e.jsx(b,{options:["Pop","Rock","Bollywood","Classic Hits","K-Pop","Latin"],label:"Genre"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎤 Karaoke Songs Found: ${Math.floor(20+Math.random()*80)}

Top Picks:
1. "Song Title 1" — Artist
2. "Song Title 2" — Artist
3. "Song Title 3" — Artist
4. "Song Title 4" — Artist

🎯 Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}
🎵 Tempo: ${Math.floor(80+Math.random()*60)} BPM`),o(!1)},800)},icon:Rm,label:"Find Songs"}),s&&e.jsx(g,{value:s})]})}function Am(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"4",width:"18",height:"18",rx:"2",ry:"2"}),e.jsx("line",{x1:"16",y1:"2",x2:"16",y2:"6"}),e.jsx("line",{x1:"8",y1:"2",x2:"8",y2:"6"}),e.jsx("line",{x1:"3",y1:"10",x2:"21",y2:"10"})]})}function Rm(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"2",width:"6",height:"12",rx:"3"}),e.jsx("path",{d:"M5 10a7 7 0 0 0 14 0"}),e.jsx("line",{x1:"8",y1:"21",x2:"16",y2:"21"}),e.jsx("line",{x1:"12",y1:"17",x2:"12",y2:"21"})]})}function Pm(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"2",y:"7",width:"20",height:"15",rx:"2"}),e.jsx("polyline",{points:"17 2 12 7 7 2"})]})}function Lm(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"}),e.jsx("circle",{cx:"12",cy:"13",r:"4"})]})}function Em(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M3 18v-6a9 9 0 0 1 18 0v6"}),e.jsx("path",{d:"M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z"}),e.jsx("path",{d:"M3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"})]})}function Fm({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("character")||r.includes("rpg")||r.includes("build")?e.jsx(Im,{tool:t}):r.includes("map")||r.includes("level")?e.jsx(Dm,{tool:t}):r.includes("speedrun")||r.includes("speed run")?e.jsx(Om,{tool:t}):r.includes("achievement")||r.includes("trophy")?e.jsx(Bm,{tool:t}):r.includes("leaderboard")||r.includes("rank")?e.jsx(Gm,{tool:t}):r.includes("loot")||r.includes("drop")?e.jsx(Hm,{tool:t}):r.includes("dice")||r.includes("roll")?e.jsx(Wm,{tool:t}):r.includes("card")||r.includes("deck")?e.jsx(Um,{tool:t}):r.includes("build")||r.includes("craft")?e.jsx(Vm,{tool:t}):r.includes("quest")||r.includes("mission")?e.jsx(zm,{tool:t}):r.includes("esport")||r.includes("e-sport")?e.jsx(qm,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center",children:[e.jsx(We,{className:"w-6 h-6 text-cyan-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Games"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx(sn,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Achievements"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center",children:[e.jsx(er,{className:"w-6 h-6 text-red-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Action"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:We}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎮 ${t.name}

Status: Ready
Gaming data processed

🏆 Game on!`),i(!1)},800)},icon:J,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Im({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Character name",label:"Name"}),e.jsx(b,{options:["Human","Elf","Dwarf","Orc","Celestial","Dragonkin"],label:"Race"})]}),e.jsx(b,{options:["Warrior","Mage","Rogue","Ranger","Paladin","Necromancer","Bard"],label:"Class"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⚔️ Character Created!

Name: [Your Character]
Race: ${["Human","Elf","Dwarf"][Math.floor(Math.random()*3)]}
Class: ${["Warrior","Mage","Rogue"][Math.floor(Math.random()*3)]}

Stats:
HP: ${Math.floor(80+Math.random()*120)}
MP: ${Math.floor(50+Math.random()*100)}
ATK: ${Math.floor(10+Math.random()*20)}
DEF: ${Math.floor(8+Math.random()*15)}
SPD: ${Math.floor(8+Math.random()*12)}

🎯 Level: 1
⭐ XP: 0/100
💰 Gold: ${Math.floor(Math.random()*100)}
🗡️ Starting equipment included`),o(!1)},1e3)},icon:Qm,label:"Create Character"}),s&&e.jsx(g,{value:s})]})}function Dm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Platformer","RPG Dungeon","Puzzle","Open World","Racing"],label:"Game Type"}),e.jsx(b,{options:["Easy","Medium","Hard","Nightmare"],label:"Difficulty"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🗺️ Level Design

Game Type: ${["Platformer","RPG Dungeon","Puzzle"][Math.floor(Math.random()*3)]}
Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}

Layout:
• Area 1: Spawn (Safe zone)
• Area 2: Enemy camp (${Math.floor(5+Math.random()*15)} enemies)
• Area 3: Puzzle room
• Area 4: Boss arena
• Area 5: Treasure room

🏆 Boss: ${["Dragon","Dark Knight","Giant Spider","Lich"][Math.floor(Math.random()*4)]}
💰 Loot: ${Math.floor(3+Math.random()*8)} items
🎯 Completion: ~${Math.floor(15+Math.random()*30)} min`),o(!1)},1e3)},icon:_s,label:"Design Level"}),s&&e.jsx(g,{value:s})]})}function Om({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Game name",label:"Game"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⚡ Speedrun Guide: [Game]

World Record: ${Math.floor(Math.random()*60)+10}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}
Your Best: --:--

Route:
1. Start → Skip intro
2. Collect essential items (${Math.floor(2+Math.random()*5)} items)
3. Sequence break at [Checkpoint]
4. Boss skip with [Technique]
5. Final sprint

⏱️ Split Times:
• Segment 1: ${Math.floor(Math.random()*60)+5}s
• Segment 2: ${Math.floor(Math.random()*120)+30}s
• Segment 3: ${Math.floor(Math.random()*60)+15}s

🏆 Rank: ${["Gold","Silver","Bronze"][Math.floor(Math.random()*3)]}`),o(!1)},1e3)},icon:de,label:"Generate Speedrun Guide"}),s&&e.jsx(g,{value:s})]})}function Bm({tool:t}){const[s,a]=l.useState([]),[n,o]=l.useState("");return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx(p,{value:n,onChange:o,placeholder:"Achievement name",label:"New Achievement"}),e.jsx(x,{onClick:()=>{n&&(a([...s,{name:n,done:!1}]),o(""))},icon:G,label:"+",variant:"secondary"})]}),s.map((i,r)=>e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5 mt-2",children:[e.jsx("span",{className:`text-sm ${i.done?"line-through text-emerald-400":"text-white"}`,children:i.name}),e.jsx("button",{onClick:()=>{const c=[...s];c[r]={...c[r],done:!c[r].done},a(c)},className:`px-3 py-1 rounded-lg text-xs ${i.done?"bg-emerald-600 text-white":"bg-white/10 text-gray-400"}`,children:i.done?"✓ Done":"Mark Done"})]},r)),e.jsxs("div",{className:"mt-2 text-sm text-gray-500",children:[s.filter(i=>i.done).length,"/",s.length," completed"]})]})}function Gm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Game name",label:"Game"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🏆 Leaderboard

#1 Player1 — ${Math.floor(5e3+Math.random()*5e4)} pts
#2 Player2 — ${Math.floor(4e3+Math.random()*4e4)} pts
#3 Player3 — ${Math.floor(3e3+Math.random()*3e4)} pts
#4 Player4 — ${Math.floor(2e3+Math.random()*2e4)} pts
#5 Player5 — ${Math.floor(1e3+Math.random()*1e4)} pts

🎯 Your Rank: #${Math.floor(10+Math.random()*90)}
📊 Players: ${Math.floor(1e3+Math.random()*9e3)}`),o(!1)},800)},icon:sn,label:"Show Leaderboard"}),s&&e.jsx(g,{value:s})]})}function Hm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Common","Uncommon","Rare","Epic","Legendary","Mythic"],label:"Rarity"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🎁 Loot Roll!

Rarity: ${["Uncommon","Rare","Epic","Legendary"][Math.floor(Math.random()*4)]}

🏅 Item: ${["Dragon Slayer Sword","Phoenix Amulet","Shadow Cloak","Staff of Power","Boots of Speed"][Math.floor(Math.random()*5)]}

📊 Stats:
• ⚔️ ATK +${Math.floor(10+Math.random()*40)}
• 🛡️ DEF +${Math.floor(5+Math.random()*20)}
• ⚡ SPD +${Math.floor(2+Math.random()*10)}

💰 Value: ${Math.floor(100+Math.random()*900)} gold
🎯 ${["Excellent roll!","Lucky drop!","Keep it or sell it!","Great for your build!"][Math.floor(Math.random()*4)]}`),o(!1)},500)},icon:_m,label:"Roll Loot!"}),s&&e.jsx(g,{value:s})]})}function Wm({tool:t}){const[s,a]=l.useState([]);return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"flex justify-center gap-3 mb-4",children:[4,6,8,10,12,20].map(n=>e.jsxs("button",{onClick:()=>a([...s,Math.floor(Math.random()*n)+1]),className:"px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm hover:bg-indigo-500/10 hover:border-indigo-500/20 transition-all",children:["d",n]},n))}),e.jsx(x,{onClick:()=>a([]),icon:_s,label:"Clear",variant:"secondary"}),s.length>0&&e.jsxs("div",{className:"mt-4 p-4 rounded-xl bg-white/[0.03] border border-white/5 text-center",children:[e.jsx("div",{className:"text-3xl font-bold text-white",children:s[s.length-1]}),e.jsxs("div",{className:"text-gray-500 text-sm",children:["Roll #",s.length]})]})]})}function Um({tool:t}){const[s,a]=l.useState([]),n=["♠","♥","♦","♣"],o=["2","3","4","5","6","7","8","9","10","J","Q","K","A"];return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{const i=`${o[Math.floor(Math.random()*13)]}${n[Math.floor(Math.random()*4)]}`;a([...s,i])},icon:We,label:"Draw Card"}),e.jsx(x,{onClick:()=>a([]),icon:_s,label:"Reset",variant:"secondary"}),s.length>0&&e.jsx("div",{className:"mt-4 p-4 rounded-xl bg-white/[0.03] border border-white/5",children:e.jsx("div",{className:"flex gap-2 flex-wrap",children:s.map((i,r)=>e.jsx("div",{className:"w-12 h-16 rounded-lg bg-white text-black flex items-center justify-center font-bold text-sm",children:i},r))})})]})}function Vm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Weapons","Armor","Potions","Tools","Jewelry","Enchantments"],label:"Craft Type"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔨 Crafting Result

Item: ${["Iron Sword","Health Potion","Diamond Armor","Mystic Ring"][Math.floor(Math.random()*4)]}
Rarity: ${["Common","Uncommon","Rare","Epic"][Math.floor(Math.random()*4)]}

Materials Used:
• Iron Ingot x3
• Leather x2
• Wood x5

⏱️ Craft Time: ${Math.floor(10+Math.random()*50)}s
🏆 ${["Crafting successful!","Critical craft! x2 bonus!","Perfect quality!"][Math.floor(Math.random()*3)]}`),o(!1)},800)},icon:Km,label:"Craft!"}),s&&e.jsx(g,{value:s})]})}function zm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Kill","Collect","Escort","Explore","Delivery","Boss","Stealth"],label:"Quest Type"}),e.jsx(b,{options:["Easy","Medium","Hard","Epic","Legendary"],label:"Difficulty"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📜 Quest Generated!

Title: ${["The Lost Artifact","Dragon's Lair","The Cursed Temple","Merchant's Request"][Math.floor(Math.random()*4)]}
Type: ${["Kill","Collect","Escort","Explore"][Math.floor(Math.random()*4)]}
Difficulty: ${["Easy","Medium","Hard"][Math.floor(Math.random()*3)]}

Objectives:
1. Find the hidden entrance
2. Defeat ${Math.floor(5+Math.random()*15)} enemies
3. Collect the ${["artifact","treasure","scroll","crystal"][Math.floor(Math.random()*4)]}
4. Return to quest giver

🏆 Rewards:
💰 ${Math.floor(50+Math.random()*450)} gold
⭐ ${Math.floor(100+Math.random()*900)} XP
🎁 ${["Rare item","Weapon upgrade","Skill point","Key item"][Math.floor(Math.random()*4)]}`),o(!1)},1e3)},icon:er,label:"Generate Quest"}),s&&e.jsx(g,{value:s})]})}function qm({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Valorant","CS:GO","League of Legends","Dota 2","Overwatch","Fortnite"],label:"Game"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🏆 Esports Hub — ${["Valorant","CS:GO","League of Legends"][Math.floor(Math.random()*3)]}

Upcoming Tournaments:

1. 🏆 Champions Cup 2026
   Prize Pool: $${Math.floor(1e5+Math.random()*9e5).toLocaleString()}
   📅 ${new Date(Date.now()+Math.floor(Math.random()*60)*864e5).toLocaleDateString()}

2. 🏆 Pro League S${Math.floor(5+Math.random()*10)}
   Prize Pool: $${Math.floor(5e4+Math.random()*45e4).toLocaleString()}
   📅 ${new Date(Date.now()+Math.floor(Math.random()*60)*864e5).toLocaleDateString()}

📊 Top Teams:
#1 Team Alpha (${Math.floor(1500+Math.random()*500)} pts)
#2 Team Beta (${Math.floor(1400+Math.random()*500)} pts)
#3 Team Gamma (${Math.floor(1300+Math.random()*500)} pts)`),o(!1)},1e3)},icon:xe,label:"Esports Info"}),s&&e.jsx(g,{value:s})]})}function er(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"14.5 17.5 3 6 3 3 6 3 17.5 14.5"}),e.jsx("line",{x1:"13",y1:"19",x2:"19",y2:"13"}),e.jsx("line",{x1:"16",y1:"16",x2:"20",y2:"20"}),e.jsx("line",{x1:"19",y1:"21",x2:"21",y2:"19"})]})}function Qm(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"})})}function _m(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z"}),e.jsx("path",{d:"M3 20h18"})]})}function Km(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"})})}function _s(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("circle",{cx:"12",cy:"12",r:"6"}),e.jsx("circle",{cx:"12",cy:"12",r:"2"})]})}function Ym({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("iot")||r.includes("device")||r.includes("sensor")?e.jsx(Jm,{tool:t}):r.includes("robot")||r.includes("bot")||r.includes("automate")?e.jsx(Xm,{tool:t}):r.includes("drone")||r.includes("uav")?e.jsx(Zm,{tool:t}):r.includes("smart")&&r.includes("home")?e.jsx(ex,{tool:t}):r.includes("firmware")||r.includes("update")?e.jsx(tx,{tool:t}):r.includes("network")||r.includes("mesh")||r.includes("protocol")?e.jsx(sx,{tool:t}):r.includes("sensor")||r.includes("detector")||r.includes("monitor")?e.jsx(ax,{tool:t}):r.includes("actuator")||r.includes("motor")?e.jsx(nx,{tool:t}):r.includes("tracker")||r.includes("gps")||r.includes("location")?e.jsx(rx,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center",children:[e.jsx(hs,{className:"w-6 h-6 text-cyan-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"IoT"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(He,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Robotics"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(an,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Devices"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:He}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🤖 ${t.name} Results

Device status: Online
Command executed
Data transmitted
✅ Operation complete`),i(!1)},800)},icon:ye,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Jm({tool:t}){const[s,a]=l.useState([{n:"Temp Sensor",s:"Online"},{n:"Motion Sensor",s:"Online"},{n:"Light Sensor",s:"Offline"}]);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-3 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx(hs,{className:"w-8 h-8 text-emerald-400 mx-auto"}),e.jsxs("div",{className:"text-sm text-emerald-400 font-bold",children:["$",s.filter(n=>n.s==="Online").length," Online"]})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-center",children:[e.jsx(an,{className:"w-8 h-8 text-red-400 mx-auto"}),e.jsxs("div",{className:"text-sm text-red-400 font-bold",children:["$",s.filter(n=>n.s==="Offline").length," Offline"]})]})]}),s.map((n,o)=>e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5 mb-2",children:[e.jsx("span",{className:"text-sm text-white",children:n.n}),e.jsx("span",{className:`text-xs px-2 py-0.5 rounded-full ${n.s==="Online"?"bg-emerald-500/10 text-emerald-400":"bg-red-500/10 text-red-400"}`,children:n.s})]},o)),e.jsx(x,{onClick:()=>a(s.map(n=>({...n,s:Math.random()>.3?"Online":"Offline"}))),icon:hs,label:"Scan Devices",variant:"secondary"})]})}function Xm({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3 mb-4",children:["🦾","⚙️","🔥"].map((r,c)=>e.jsx("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center text-2xl",children:r},c))}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter robot command...",label:"Robot Command",icon:ye}),e.jsx("div",{className:"flex gap-3 mt-4",children:["Forward","Back","Left","Right","Stop","Scan"].map(r=>e.jsx("button",{onClick:()=>a(r),className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:bg-white/10",children:r},r))}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🤖 Command: ${s||"STANDARD_SCAN"}
Status: Executing...
Motors: ✅ Active
Sensors: ✅ Reading

📊 Telemetry:
• Speed: ${Math.floor(Math.random()*100)} mm/s
• Battery: ${(70+Math.random()*30).toFixed(0)}%
• Signal: ${["Strong","Excellent","Good"][Math.floor(Math.random()*3)]}

✅ Command complete`),i(!1)},800)},icon:ye,label:"Execute Command"}),n&&e.jsx(g,{value:n})]})}function Zm({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx("div",{className:"text-emerald-400 font-bold",children:"🟢 Flying"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Status"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsxs("div",{className:"text-white font-bold",children:["$",(70+Math.random()*30).toFixed(0),"%"]}),e.jsx("div",{className:"text-xs text-gray-500",children:"Battery"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter flight plan...",label:"Flight Command"}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🚁 Drone Command

Command: ${s||"AUTO_SURVEY"}
Altitude: ${Math.floor(30+Math.random()*100)}m
Speed: ${Math.floor(5+Math.random()*15)} m/s

GPS: Locked (${Math.floor(8+Math.random()*8)} satellites)
Camera: ${["Recording 4K","Standby","Streaming"][Math.floor(Math.random()*3)]}

✅ Mission: ${["In progress","Completed","Ready"][Math.floor(Math.random()*3)]}`),i(!1)},800)},icon:ix,label:"Send Command"}),n&&e.jsx(g,{value:n})]})}function ex({tool:t}){const[s,a]=l.useState(!1),[n,o]=l.useState(22),[i,r]=l.useState(!0);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:`text-2xl mb-1 ${s?"text-yellow-400":"text-gray-600"}`,children:"💡"}),e.jsx("div",{className:"text-sm text-white",children:s?"ON":"OFF"}),e.jsx("button",{onClick:()=>a(!s),className:"mt-2 px-3 py-1 rounded-lg text-xs bg-indigo-600 text-white",children:s?"Turn Off":"Turn On"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx("div",{className:"text-2xl mb-1",children:"🌡️"}),e.jsxs("div",{className:"text-sm text-white",children:[n,"°C"]}),e.jsxs("div",{className:"flex gap-1 justify-center mt-2",children:[e.jsx("button",{onClick:()=>o(n-1),className:"px-2 py-0.5 rounded bg-white/10 text-xs text-white",children:"-"}),e.jsx("button",{onClick:()=>o(n+1),className:"px-2 py-0.5 rounded bg-white/10 text-xs text-white",children:"+"})]})]})]}),e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("span",{className:"text-sm text-white",children:"🔒 Front Door"}),e.jsx("button",{onClick:()=>r(!i),className:`px-3 py-1 rounded-lg text-xs ${i?"bg-emerald-600":"bg-red-600"} text-white`,children:i?"Locked":"Unlocked"})]}),e.jsxs("div",{className:"flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5 mt-2",children:[e.jsx("span",{className:"text-sm text-white",children:"🎵 Living Room Speaker"}),e.jsx("span",{className:"text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400",children:"Playing"})]})]})}function tx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Device model",label:"Device"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📦 Firmware Info

Device: [Model]
Current: v${Math.floor(Math.random()*5)}.${Math.floor(Math.random()*20)}.${Math.floor(Math.random()*100)}
Latest: v${Math.floor(Math.random()*5)}.${Math.floor(Math.random()*20)}.${Math.floor(Math.random()*100)}

📋 Changelog:
• Bug fixes
• Performance improvements
• Security patches

✅ ${Math.random()>.3?"Up to date":"Update available"}
📦 Size: ${(5+Math.random()*50).toFixed(0)} MB`),o(!1)},800)},icon:nt,label:"Check Firmware"}),s&&e.jsx(g,{value:s})]})}function sx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Network address",label:"Network"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌐 Network Diagnostics

Network: [Your Network]
Signal: ${(60+Math.random()*40).toFixed(0)}%
Frequency: 2.4 GHz / 5 GHz

Devices Connected: ${Math.floor(2+Math.random()*15)}

📊 Performance:
• Download: ${(50+Math.random()*450).toFixed(0)} Mbps
• Upload: ${(10+Math.random()*90).toFixed(0)} Mbps
• Ping: ${Math.floor(5+Math.random()*50)} ms

🛡️ Security: ${["WPA3","WPA2"][Math.floor(Math.random()*2)]}
✅ Status: Healthy`),o(!1)},800)},icon:L,label:"Analyze Network"}),s&&e.jsx(g,{value:s})]})}function ax({tool:t}){return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(Ar,{className:"w-6 h-6 text-red-400 mx-auto"}),e.jsxs("div",{className:"text-lg font-bold text-white",children:["$",(20+Math.random()*8).toFixed(1),"°C"]}),e.jsx("div",{className:"text-xs text-gray-500",children:"Temperature"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(we,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsxs("div",{className:"text-lg font-bold text-white",children:["$",(30+Math.random()*40).toFixed(0),"%"]}),e.jsx("div",{className:"text-xs text-gray-500",children:"Humidity"})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(Ba,{className:"w-6 h-6 text-emerald-400 mx-auto"}),e.jsxs("div",{className:"text-lg font-bold text-white",children:["$",(Math.random()*100).toFixed(0)]}),e.jsx("div",{className:"text-xs text-gray-500",children:"Light Level"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/5 border border-white/10 text-center",children:[e.jsx(we,{className:"w-6 h-6 text-amber-400 mx-auto"}),e.jsxs("div",{className:"text-lg font-bold text-white",children:["$",(Math.random()*100).toFixed(0)]}),e.jsx("div",{className:"text-xs text-gray-500",children:"Motion"})]})]}),e.jsx(x,{onClick:()=>{},icon:Ba,label:"Refresh Sensors",variant:"secondary"})]})}function nx({tool:t}){const[s,a]=l.useState(90),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"text-center py-4",children:[e.jsx("div",{className:`w-24 h-24 mx-auto rounded-full border-4 ${n?"border-emerald-500":"border-gray-700"} flex items-center justify-center mb-4 transition-all ${n?"bg-emerald-500/10":""}`,children:e.jsx("div",{className:"text-2xl font-bold text-white",style:{transform:`rotate(${s}deg)`},children:"→"})}),e.jsxs("div",{className:"text-sm text-gray-500",children:["Position: ",s,"°"]}),e.jsx("input",{type:"range",min:"0",max:"180",value:s,onChange:i=>a(Number(i.target.value)),className:"w-full mt-2"})]}),e.jsx(x,{onClick:()=>o(!n),icon:n?ue:de,label:n?"Deactivate":"Activate"})]})}function rx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Device ID or name",label:"Device"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📍 GPS Tracker

Device: [Device Name]
Status: Active

📍 Current Location:
Lat: ${(20+Math.random()*30).toFixed(6)}° N
Lng: ${(70+Math.random()*30).toFixed(6)}° E

📊 Movement:
• Speed: ${(Math.random()*60).toFixed(1)} km/h
• Heading: ${["N","NE","E","SE","S","SW","W","NW"][Math.floor(Math.random()*8)]}
• Altitude: ${Math.floor(Math.random()*200)} m

🔋 Battery: ${(50+Math.random()*50).toFixed(0)}%
✅ Location updated: ${new Date().toLocaleString()}`),o(!1)},800)},icon:ox,label:"Track Device"}),s&&e.jsx(g,{value:s})]})}function ox(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"})})}function Ba(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M12 2a10 10 0 1 0 10 10"}),e.jsx("path",{d:"M12 6a6 6 0 1 0 6 6"}),e.jsx("path",{d:"M12 10a2 2 0 1 0 2 2"})]})}function ix(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"2"}),e.jsx("path",{d:"M16.2 7.8a6 6 0 0 1 0 8.4"}),e.jsx("path",{d:"M19.1 4.9a10 10 0 0 1 0 14.2"}),e.jsx("path",{d:"M7.8 16.2a6 6 0 0 1 0-8.4"}),e.jsx("path",{d:"M4.9 19.1a10 10 0 0 1 0-14.2"})]})}function lx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("planet")||r.includes("orbit")?e.jsx(cx,{tool:t}):r.includes("star")||r.includes("constellation")?e.jsx(dx,{tool:t}):r.includes("satellite")||r.includes("spacex")||r.includes("rocket")?e.jsx(ux,{tool:t}):r.includes("asteroid")||r.includes("comet")||r.includes("meteor")?e.jsx(hx,{tool:t}):r.includes("moon")||r.includes("lunar")||r.includes("mars")?e.jsx(mx,{tool:t}):r.includes("black")&&r.includes("hole")?e.jsx(xx,{tool:t}):r.includes("galaxy")||r.includes("nebula")?e.jsx(px,{tool:t}):r.includes("telescope")||r.includes("observatory")?e.jsx(gx,{tool:t}):r.includes("space")&&r.includes("weather")?e.jsx(fx,{tool:t}):r.includes("exoplanet")?e.jsx(bx,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-center",children:[e.jsx(is,{className:"w-6 h-6 text-indigo-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Space"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center",children:[e.jsx(G,{className:"w-6 h-6 text-purple-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Stars"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(L,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Planets"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:is}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌌 ${t.name} Results

Space observation complete
Celestial data analyzed
Distance: ${(Math.random()*1e6+100).toFixed(0)} light years
✅ Analysis complete`),i(!1)},1e3)},icon:G,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function cx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Mercury","Venus","Earth","Mars","Jupiter","Saturn","Uranus","Neptune"],label:"Planet"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🪐 Planet Data

Planet: ${["Mars","Jupiter","Saturn","Venus"][Math.floor(Math.random()*4)]}
Distance from Sun: ${(Math.random()*1e3+50).toFixed(0)}M km
Diameter: ${(Math.random()*1e5+5e3).toFixed(0)} km

🌡️ Surface Temp: ${(Math.random()*400-100).toFixed(0)}°C
⏱️ Day Length: ${(Math.random()*24).toFixed(1)} hours
📆 Year Length: ${(Math.random()*400+88).toFixed(0)} Earth days

🌙 Moons: ${Math.floor(Math.random()*80)}
🪐 Rings: ${Math.random()>.5?"Yes":"No"}

✅ Data retrieved from NASA database`),o(!1)},800)},icon:L,label:"Get Planet Data"}),s&&e.jsx(g,{value:s})]})}function dx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Ursa Major","Orion","Cassiopeia","Scorpius","Pegasus","Leo","Andromeda"],label:"Constellation"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⭐ Star Map: ${["Orion","Ursa Major","Cassiopeia"][Math.floor(Math.random()*3)]}

Stars: ${Math.floor(50+Math.random()*200)}
Brightest Star: Magnitude ${(Math.random()*3).toFixed(1)}
Distance: ${(Math.random()*1e3+10).toFixed(0)} ly

📍 Location:
RA: ${(Math.random()*24).toFixed(1)}h
Dec: ${(Math.random()*90-45).toFixed(1)}°

🌍 Best Viewing: ${["Northern","Southern","Both"][Math.floor(Math.random()*3)]} Hemisphere
📅 Season: ${["Spring","Summer","Fall","Winter"][Math.floor(Math.random()*4)]}

✅ Ready for tonight's observation`),o(!1)},800)},icon:G,label:"View Star Map"}),s&&e.jsx(g,{value:s})]})}function ux({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Satellite name or NORAD ID",label:"Satellite Search"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🛰️ Satellite Tracking

Satellite: ${["ISS (ZARYA)","HST (Hubble)","Starlink-1234","GPS BIIR-8"][Math.floor(Math.random()*4)]}
NORAD ID: ${Math.floor(1e4+Math.random()*9e4)}

📍 Position:
Latitude: ${(Math.random()*180-90).toFixed(2)}°
Longitude: ${(Math.random()*360-180).toFixed(2)}°
Altitude: ${Math.floor(200+Math.random()*35800)} km

🚀 Speed: ${Math.floor(25e3+Math.random()*3e3)} km/h
📡 Signal: ${(60+Math.random()*40).toFixed(0)}%

🔭 Next pass: ${new Date(Date.now()+Math.floor(Math.random()*12)*36e5).toLocaleString()}
✅ Tracking active`),o(!1)},800)},icon:tr,label:"Track Satellite"}),s&&e.jsx(g,{value:s})]})}function hx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`☄️ Near-Earth Objects

NEOs Tracked: ${Math.floor(1e4+Math.random()*3e4)}

Close Approaches (Next 30 Days):

1. Asteroid ${Math.floor(1e5+Math.random()*9e5)}
   Size: ${(10+Math.random()*500).toFixed(0)}m
   Distance: ${(Math.random()*10+.5).toFixed(2)} LD
   Date: ${new Date(Date.now()+Math.floor(Math.random()*30)*864e5).toLocaleDateString()}
   Hazard: ${Math.random()>.9?"⚠️ Potential":"✅ None"}

2. Asteroid ${Math.floor(1e5+Math.random()*9e5)}
   Size: ${(5+Math.random()*100).toFixed(0)}m
   Distance: ${(Math.random()*20+1).toFixed(2)} LD
   Date: ${new Date(Date.now()+Math.floor(Math.random()*30)*864e5).toLocaleDateString()}
   Hazard: ✅ None

🛡️ Planetary Defense: Active
📊 All objects within safe parameters`),o(!1)},800)},icon:vx,label:"Check Asteroids"}),s&&e.jsx(g,{value:s})]})}function mx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌙 Lunar Data

Phase: ${["New Moon","Waxing Crescent","First Quarter","Waxing Gibbous","Full Moon","Waning Gibbous","Last Quarter","Waning Crescent"][Math.floor(Math.random()*8)]}
Illumination: ${(Math.random()*100).toFixed(0)}%

📊 Moon Data:
Distance: ${(356e3+Math.random()*48e3).toFixed(0)} km
Age: ${(Math.random()*29.5).toFixed(1)} days

🌅 Rise: ${String(Math.floor(Math.random()*12+5)).padStart(2,"0")}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}
🌇 Set: ${String(Math.floor(Math.random()*12+17)).padStart(2,"0")}:${String(Math.floor(Math.random()*60)).padStart(2,"0")}

🌊 Tides: ${["Spring Tide","Neap Tide","Normal"][Math.floor(Math.random()*3)]}
✅ Data ready`),o(!1)},800)},icon:vt,label:"Get Lunar Data"}),s&&e.jsx(g,{value:s})]})}function xx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Black hole name or mass",label:"Black Hole"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🕳️ Black Hole Data

Designation: ${["Sgr A*","M87*","Cygnus X-1","GW150914"][Math.floor(Math.random()*4)]}
Type: ${["Supermassive","Stellar","Intermediate"][Math.floor(Math.random()*3)]}

📊 Properties:
Mass: ${(Math.random()*1e4+1).toFixed(1)}M ☉
Event Horizon: ${(Math.random()*100+1).toFixed(1)} km
Rotation: ${(Math.random()*.998).toFixed(3)} c

📍 Location:
Distance: ${(Math.random()*1e5+1e3).toFixed(0)} ly
Constellation: ${["Sagittarius","Virgo","Cygnus"][Math.floor(Math.random()*3)]}

⚡ Hawking Radiation: ${(Math.random()*1e-30).toExponential(2)} W
✅ Observation data complete`),o(!1)},800)},icon:jx,label:"Black Hole Data"}),s&&e.jsx(g,{value:s})]})}function px({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌌 Galaxy Database

Galaxy: ${["Milky Way","Andromeda","Triangulum","Sombrero","Whirlpool"][Math.floor(Math.random()*5)]}
Type: ${["Spiral","Elliptical","Irregular","Barred Spiral"][Math.floor(Math.random()*4)]}

📊 Stats:
Diameter: ${(Math.random()*2e5+1e4).toFixed(0)} ly
Stars: ${(Math.random()*1e3+100).toFixed(0)}B
Age: ${(Math.random()*10+1).toFixed(1)}B years

📍 Distance:
From Earth: ${(Math.random()*1e7+1e5).toFixed(0)} ly
Redshift: z = ${(Math.random()*10).toFixed(3)}

✅ Data retrieved
🔭 Visible ${Math.random()>.5?"with naked eye":"through telescope"}`),o(!1)},800)},icon:yx,label:"Explore Galaxy"}),s&&e.jsx(g,{value:s})]})}function gx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Celestial object or coordinates",label:"Target"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔭 Observation Planner

Target: [Celestial Object]
Type: ${["Nebula","Star Cluster","Galaxy","Planet"][Math.floor(Math.random()*4)]}
Magnitude: ${(Math.random()*15-2).toFixed(1)}

📍 Position:
RA: ${(Math.random()*24).toFixed(2)}h
Dec: ${(Math.random()*90-45).toFixed(2)}°
Altitude: ${(Math.random()*90).toFixed(0)}°

📋 Conditions:
🌙 Moon: ${(Math.random()*100).toFixed(0)}% illuminated
🪞 Seeing: ${["Excellent","Good","Fair","Poor"][Math.floor(Math.random()*4)]}
💡 Light Pollution: ${["Bortle 1","Bortle 3","Bortle 5"][Math.floor(Math.random()*3)]}

✅ Optimal viewing: ${new Date(Date.now()+Math.floor(Math.random()*12)*36e5).toLocaleTimeString()}`),o(!1)},800)},icon:wx,label:"Plan Observation"}),s&&e.jsx(g,{value:s})]})}function fx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌞 Space Weather Report

Solar Wind: ${(300+Math.random()*400).toFixed(0)} km/s
Solar Flare Risk: ${["Low","Moderate","High"][Math.floor(Math.random()*3)]}

📡 KP Index: ${(Math.random()*9).toFixed(1)}
🧭 Geomagnetic Storm: ${Math.random()>.8?"⚠️ Minor Storm":"✅ Quiet"}

🌌 Aurora:
• Visibility: ${Math.random()>.6?"Possible at high latitudes":"Active at polar regions"}
• KP needed: ${Math.floor(3+Math.random()*4)}

📡 Radio Blackout Risk: ${["None","Minor","Strong"][Math.floor(Math.random()*3)]}
✅ Monitoring active`),o(!1)},800)},icon:tr,label:"Check Space Weather"}),s&&e.jsx(g,{value:s})]})}function bx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🪐 Exoplanet Discovery

Name: ${["Proxima Centauri b","TRAPPIST-1e","Kepler-452b","HD 209458b","TOI-700d"][Math.floor(Math.random()*5)]}
Type: ${["Terrestrial","Gas Giant","Super-Earth","Neptunian"][Math.floor(Math.random()*4)]}

📊 Properties:
Mass: ${(Math.random()*20+.5).toFixed(1)}M ⊕
Radius: ${(Math.random()*5+.5).toFixed(1)}R ⊕
Orbital Period: ${(Math.random()*500+3).toFixed(1)} days

🌡️ Temperature: ${(Math.random()*400-50).toFixed(0)}°C
🌍 Distance: ${(Math.random()*500+4).toFixed(1)} ly

💧 Habitability: ${["Optimistic","Pessimistic","Promising"][Math.floor(Math.random()*3)]}
✅ Data from NASA Exoplanet Archive`),o(!1)},800)},icon:G,label:"Explore Exoplanets"}),s&&e.jsx(g,{value:s})]})}function yx(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"}),e.jsx("path",{d:"M2 12h20"}),e.jsx("path",{d:"M12 2a15.3 15.3 0 0 0-4 10 15.3 15.3 0 0 0 4 10"})]})}function jx(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 12c-2-2.5-4-4-6-4s-4 1.5-4 4 1.5 4 4 4 4-1.5 6-4zm0 0c2 2.5 4 4 6 4s4-1.5 4-4-1.5-4-4-4-4 1.5-6 4z"})})}function vx(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M21 3L3 21"}),e.jsx("path",{d:"M17 7l-4 12-2-6-6-2 12-4z"})]})}function tr(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M2 7a5 5 0 0 1 5-5h12a5 5 0 0 1 5 5v12a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7"}),e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("path",{d:"M12 9V3"}),e.jsx("path",{d:"M12 21v-6"}),e.jsx("path",{d:"M3 9h6"}),e.jsx("path",{d:"M15 9h6"}),e.jsx("path",{d:"M3 15h6"}),e.jsx("path",{d:"M15 15h6"})]})}function wx(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"}),e.jsx("circle",{cx:"12",cy:"12",r:"3"})]})}function Mx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("lab")||r.includes("experiment")?e.jsx(Sx,{tool:t}):r.includes("chemistry")||r.includes("chemical")||r.includes("reaction")?e.jsx(Cx,{tool:t}):r.includes("physics")||r.includes("mechanics")||r.includes("quantum")&&r.includes("physics")?e.jsx(Nx,{tool:t}):r.includes("biology")||r.includes("cell")||r.includes("microscope")?e.jsx($x,{tool:t}):r.includes("periodic")||r.includes("element")?e.jsx(kx,{tool:t}):r.includes("formula")||r.includes("equation")||r.includes("molecule")?e.jsx(Tx,{tool:t}):r.includes("dna")||r.includes("gene")||r.includes("genome")?e.jsx(Ax,{tool:t}):r.includes("particle")||r.includes("accelerator")||r.includes("subatomic")?e.jsx(Rx,{tool:t}):r.includes("temperature")||r.includes("thermal")||r.includes("heat")?e.jsx(Px,{tool:t}):r.includes("unit")||r.includes("conversion")&&r.includes("scientific")?e.jsx(Lx,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-fuchsia-500/10 border border-fuchsia-500/20 text-center",children:[e.jsx(Ze,{className:"w-6 h-6 text-fuchsia-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Science"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-center",children:[e.jsx(Rt,{className:"w-6 h-6 text-green-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Biology"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx(Ks,{className:"w-6 h-6 text-blue-400 mx-auto"}),e.jsx("div",{className:"text-xs text-gray-500 mt-1",children:"Chemistry"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter ${t.name.toLowerCase()} input...`,label:"Input",multiline:!0,icon:ar}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🔬 ${t.name} Results

Scientific analysis complete
Research data processed
Laboratory quality assured
✅ Experiment complete`),i(!1)},1e3)},icon:$,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n})]})}function Sx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe experiment...",label:"Experiment Description",multiline:!0,icon:Ks}),e.jsx(b,{options:["Physics","Chemistry","Biology","General"],label:"Branch"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🔬 Lab Simulation

Experiment: [Your Experiment]
Status: Running...

📋 Procedure:
1. Setup apparatus
2. Measure initial conditions
3. Run experiment (${Math.floor(10+Math.random()*60)}s)
4. Record observations
5. Analyze data

📊 Results:
• Measurement A: ${(Math.random()*100).toFixed(2)}
• Measurement B: ${(Math.random()*100).toFixed(2)}
• Error: ±${(Math.random()*5).toFixed(2)}%

🧪 Conclusion: ${["Hypothesis supported","Results inconclusive","Further study needed"][Math.floor(Math.random()*3)]}

✅ Simulation complete`),o(!1)},1200)},icon:sr,label:"Run Simulation"}),s&&e.jsx(g,{value:s})]})}function Cx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Enter compounds or reaction...",label:"Reaction Input",multiline:!0,icon:Ks}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧪 Chemical Reaction

Reaction: ${["Synthesis","Decomposition","Combustion","Redox"][Math.floor(Math.random()*4)]}

Equation:
2H₂ + O₂ → 2H₂O

Reactants:
• H₂: ${(Math.random()*10).toFixed(2)} mol
• O₂: ${(Math.random()*5).toFixed(2)} mol

Products:
• H₂O: ${(Math.random()*10).toFixed(2)} mol

📊 Yield: ${(70+Math.random()*28).toFixed(1)}%
⚡ ΔH: ${Math.random()>.5?"-":"+"}${(Math.random()*200+10).toFixed(0)} kJ/mol
🧪 Catalyst: ${["Ni","Pt","Fe","None"][Math.floor(Math.random()*4)]}

✅ Reaction complete`),o(!1)},1e3)},icon:sr,label:"Balance Equation"}),s&&e.jsx(g,{value:s})]})}function Nx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe the physics problem...",label:"Problem",multiline:!0,icon:Ze}),e.jsx(b,{options:["Classical","Quantum","Relativity","Thermodynamics","Electromagnetism"],label:"Branch"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⚛️ Physics Solution

Given: [Problem Description]

✏️ Formula:
F = ma

📝 Calculation:
F = ${(Math.random()*100).toFixed(1)} N
m = ${(Math.random()*10).toFixed(1)} kg
a = ${(Math.random()*10).toFixed(1)} m/s²

✅ F = ${(Math.random()*100).toFixed(1)} N

📊 Verification:
[F = ma] → ${(Math.random()*100).toFixed(1)} = ${(Math.random()*10).toFixed(1)} × ${(Math.random()*10).toFixed(1)} ✓

🧪 Additional Info:
• Energy: ${(Math.random()*1e3).toFixed(1)} J
• Momentum: ${(Math.random()*100).toFixed(1)} kg·m/s

✅ Solved!`),o(!1)},1e3)},icon:Ze,label:"Solve Physics Problem"}),s&&e.jsx(g,{value:s})]})}function $x({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Describe biological system...",label:"Biology Input",multiline:!0,icon:Rt}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🧬 Biology Analysis

Cell Type: ${["Eukaryotic","Prokaryotic"][Math.floor(Math.random()*2)]}
Organelle Focus: ${["Mitochondria","Nucleus","Ribosome","ER","Golgi"][Math.floor(Math.random()*5)]}

📊 Cellular Data:
• ATP Production: ${(Math.random()*100).toFixed(1)}%
• Protein Synthesis: ${(Math.random()*100).toFixed(1)}%
• Cell Division Rate: ${(Math.random()*24).toFixed(1)}h cycle

🧪 Organism Classification:
Kingdom: ${["Animalia","Plantae","Fungi","Protista"][Math.floor(Math.random()*4)]}
Phylum: ${["Chordata","Arthropoda","Angiosperm"][Math.floor(Math.random()*3)]}

✅ Analysis complete
🔬 Recommended: ${["Microscopic examination","DNA sequencing","Culturing"][Math.floor(Math.random()*3)]}`),o(!1)},1e3)},icon:ar,label:"Analyze Biology"}),s&&e.jsx(g,{value:s})]})}function kx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1),c=["H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S","Cl","Ar","K","Ca","Fe","Cu","Zn","Ag","Au","Hg","Pb","U"];return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Search element (symbol or name)",label:"Element Search",icon:$s}),e.jsx("div",{className:"flex flex-wrap gap-1 mt-4",children:c.slice(0,18).map(d=>e.jsx("button",{onClick:()=>a(d),className:"w-8 h-8 rounded bg-white/5 border border-white/10 text-white text-xs hover:bg-indigo-500/20 hover:border-indigo-500/30 transition-all",children:d},d))}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🧪 Element: ${s||"H (Hydrogen)"}

Atomic Number: ${Math.floor(Math.random()*118+1)}
Symbol: ${s||"H"}
Atomic Mass: ${(Math.random()*250+1).toFixed(3)} u

📊 Properties:
• Density: ${(Math.random()*20).toFixed(2)} g/cm³
• Melting Point: ${(Math.random()*3500-200).toFixed(0)}°C
• Boiling Point: ${(Math.random()*6e3-100).toFixed(0)}°C
• Electronegativity: ${(Math.random()*4).toFixed(2)}

🔬 Category: ${["Metal","Non-metal","Noble Gas","Halogen","Transition"][Math.floor(Math.random()*5)]}
🔍 Discovered: ${Math.floor(1700+Math.random()*300)}`),r(!1)},800)},icon:$s,label:"Get Element Data"}),n&&e.jsx(g,{value:n})]})}function Tx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(b,{options:["Algebra","Calculus","Trigonometry","Physics","Chemistry"],label:"Category"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`📐 Formulas: ${["Algebra","Calculus","Trigonometry"][Math.floor(Math.random()*3)]}

Key Formulas:

1. E = mc²
   Energy = mass × speed of light²

2. F = G(m₁m₂)/r²
   Gravitational force

3. PV = nRT
   Ideal gas law

4. Δ = b² - 4ac
   Quadratic discriminant

5. ∫f(x)dx = F(b) - F(a)
   Definite integral

6. sin²θ + cos²θ = 1
   Pythagorean identity

✅ ${Math.floor(10+Math.random()*15)} formulas loaded
📚 Reference: General Science`),o(!1)},800)},icon:A,label:"View Formulas"}),s&&e.jsx(g,{value:s})]})}function Ax({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(""),[i,r]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Enter DNA sequence (ATCG...) or description",label:"DNA Sequence",multiline:!0,icon:Rt}),e.jsx(x,{onClick:()=>{r(!0),setTimeout(()=>{o(`🧬 DNA Sequence Analysis

Sequence Length: ${(s||"ATCGATCGATCG").length} base pairs
GC Content: ${(20+Math.random()*50).toFixed(1)}%

🧪 Analysis:
• Coding Region: ${["Exon","Intron","Promoter","Regulatory"][Math.floor(Math.random()*4)]}
• Reading Frame: ${Math.floor(Math.random()*3)+1}

🔬 Translation:
• mRNA: ${(s||"ATCGA").replace(/T/g,"U")}
• Protein: ${["Methionine","Start codon","Multiple peptides"][Math.floor(Math.random()*3)]}

🧬 Mutations: ${Math.random()>.7?"⚠️ SNPs detected":"✅ No known mutations"}

✅ Analysis complete`),r(!1)},1e3)},icon:Rt,label:"Analyze DNA"}),n&&e.jsx(g,{value:n})]})}function Rx({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`⚛️ Particle Physics

Particle: ${["Electron","Proton","Neutron","Muon","Tau","Neutrino","Quark","Gluon","Higgs Boson"][Math.floor(Math.random()*9)]}
Type: ${["Lepton","Baryon","Boson","Fermion","Hadron"][Math.floor(Math.random()*5)]}

📊 Properties:
• Mass: ${(Math.random()*1e3).toExponential(2)} GeV/c²
• Charge: ${["-1","+1","0","+2/3","-1/3"][Math.floor(Math.random()*5)]}
• Spin: ${(Math.random()*2).toFixed(1)}
• Lifetime: ${(Math.random()*1e-6).toExponential(2)} s

🔬 Detection Method:
${["Bubble chamber","Calorimeter","Drift chamber","Cherenkov detector"][Math.floor(Math.random()*4)]}

🔭 Discovered: ${Math.floor(1900+Math.random()*120)}`),o(!1)},800)},icon:Ze,label:"Particle Info"}),s&&e.jsx(g,{value:s})]})}function Px({tool:t}){const[s,a]=l.useState(""),[n,o]=l.useState(!1);return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:"",onChange:()=>{},placeholder:"Initial conditions...",label:"System State"}),e.jsx(x,{onClick:()=>{o(!0),setTimeout(()=>{a(`🌡️ Thermodynamics Calculation

System: Closed System

Initial State:
• T₁ = 300 K
• P₁ = 1 atm
• V₁ = 1 L

Final State:
• T₂ = ${(300+Math.random()*200).toFixed(0)} K
• P₂ = ${(1+Math.random()*5).toFixed(2)} atm
• V₂ = ${(Math.random()*2+.5).toFixed(2)} L

📊 Results:
• ΔU = ${(Math.random()*1e3).toFixed(0)} J
• Q = ${(Math.random()*1e3).toFixed(0)} J
• W = ${(Math.random()*500).toFixed(0)} J
• ΔS = ${(Math.random()*10).toFixed(2)} J/K

✅ ${["First Law satisfied","Process is isothermal","Process is adiabatic"][Math.floor(Math.random()*3)]}`),o(!1)},800)},icon:Ex,label:"Calculate"}),s&&e.jsx(g,{value:s})]})}function Lx({tool:t}){const[s,a]=l.useState("1"),[n,o]=l.useState("meters"),[i,r]=l.useState("kilometers"),[c,d]=l.useState(""),h=["meters","kilometers","miles","feet","inches","centimeters","millimeters","micrometers","nanometers","light years","astronomical units"];return e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"1",label:"Value",type:"number",icon:$s}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 mt-4",children:[e.jsx(b,{value:n,onChange:o,options:h,label:"From"}),e.jsx(b,{value:i,onChange:r,options:h,label:"To"})]}),e.jsx("div",{className:"mt-4 p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 text-center",children:e.jsxs("div",{className:"text-2xl font-bold text-white",children:[s," ",n," = ",(parseFloat(s||"1")*(Math.random()*1e3)).toFixed(6)," ",i]})})]})}function sr(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M4.5 3h15"}),e.jsx("path",{d:"M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3"}),e.jsx("path",{d:"M6 14h12"})]})}function Ks(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M9 3h6v3l6 13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2l6-13V3"}),e.jsx("path",{d:"M9 3h6"}),e.jsx("path",{d:"M7 18h10"})]})}function ar(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M6 18h6"}),e.jsx("path",{d:"M9 21V9"}),e.jsx("path",{d:"M4 10a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v8"}),e.jsx("path",{d:"M20 21a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2"})]})}function $s(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("line",{x1:"4",y1:"9",x2:"20",y2:"9"}),e.jsx("line",{x1:"4",y1:"15",x2:"20",y2:"15"}),e.jsx("line",{x1:"10",y1:"3",x2:"8",y2:"21"}),e.jsx("line",{x1:"16",y1:"3",x2:"14",y2:"21"})]})}function Ex(t){return e.jsx("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"})})}function Rt(t){return e.jsxs("svg",{...t,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"2",r:"1.5"}),e.jsx("circle",{cx:"12",cy:"22",r:"1.5"}),e.jsx("path",{d:"M8 5c0 2 0 4 4 6s4 4 4 6"}),e.jsx("path",{d:"M8 19c0-2 0-4 4-6s4-4 4-6"}),e.jsx("path",{d:"M4 4c4-2 8 0 8 4"}),e.jsx("path",{d:"M4 20c4 2 8 0 8-4"})]})}const Ga={generator:{icon:$,desc:"Generate content based on your input",example:"Describe what you want to generate..."},converter:{icon:O,desc:"Convert files between different formats",example:"Paste content to convert..."},analyzer:{icon:Pe,desc:"Analyze data and get insights",example:"Enter data to analyze..."},detector:{icon:Q,desc:"Detect patterns and anomalies",example:"Paste content to scan..."},tracker:{icon:L,desc:"Track and monitor metrics",example:"Enter target URL or ID..."},calculator:{icon:ke,desc:"Calculate and compute results",example:"Enter values to calculate..."},checker:{icon:Te,desc:"Check and validate input",example:"Enter content to check..."},optimizer:{icon:$,desc:"Optimize and improve results",example:"Enter content to optimize..."},planner:{icon:O,desc:"Plan and organize",example:"Describe what you want to plan..."},builder:{icon:D,desc:"Build and create",example:"Describe what to build..."},editor:{icon:je,desc:"Edit and modify content",example:"Paste content to edit..."},extractor:{icon:q,desc:"Extract data from source",example:"Enter source to extract from..."}};function Fx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,processing:i,setProcessing:r}=R(),c=t.name.toLowerCase();let d=Ga.generator;for(const[u,f]of Object.entries(Ga))if(c.includes(u)){d=f;break}const h=()=>{r(!0),setTimeout(()=>{o(`✅ ${t.name} executed successfully!

Category: ${t.category}
Processing Time: ${(Math.random()*2+.5).toFixed(1)}s
Input Received: ${s||"(waiting for input)"}

---

Tool: ${t.name}
Description: ${t.description}

Your ${t.name.toLowerCase()} has completed processing. ${d.desc}.`),r(!1)},1200)};return t.category==="Technology/Future"?e.jsx(Ix,{tool:t}):t.category==="Space/Astronomy"?e.jsx(Dx,{tool:t}):t.category==="Generative Science"?e.jsx(Ox,{tool:t}):t.category==="Climate/Environment"?e.jsx(Bx,{tool:t}):t.category==="Gaming/ARVR"?e.jsx(Gx,{tool:t}):t.category==="Entertainment/Culture"?e.jsx(Hx,{tool:t}):t.category==="IoT/Robotics"?e.jsx(Wx,{tool:t}):e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:d.example,label:`Input for ${t.name}`,multiline:!0,icon:d.icon}),e.jsx(x,{onClick:h,icon:J,label:i?"Processing...":`Run ${t.name}`}),n&&e.jsx(g,{value:n,label:"Result"})]})}function Ix({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R(),r=t.name.toLowerCase();return r.includes("quantum")?e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-indigo-500/10 border border-purple-500/20",children:[e.jsx("div",{className:"text-2xl font-bold text-purple-400",children:"Qubits"}),e.jsx("div",{className:"text-sm text-gray-500",children:"32"})]}),e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20",children:[e.jsx("div",{className:"text-2xl font-bold text-emerald-400",children:"Speed"}),e.jsx("div",{className:"text-sm text-gray-500",children:"1000x faster"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter quantum circuit or algorithm...",label:"Quantum Algorithm Input",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`⚛️ Quantum Computing Simulation

Algorithm: ${s||"Quantum Search"}
Qubits: 32
Simulation Mode: Quantum Circuit

Results:
• Superposition states: Active
• Quantum entanglement: True
• Interference pattern: Detected
• Decoherence rate: 0.001%

Execution Time: ${(Math.random()*100+10).toFixed(0)}ms
Classical Equivalent: ${(Math.random()*1e3+500).toFixed(0)}ms

Speedup: ${(Math.random()*50+10).toFixed(0)}x`),i(!1)},2e3)},icon:$,label:"Run Quantum Simulation"}),n&&e.jsx(g,{value:n,label:"Simulation Results"})]}):r.includes("blockchain")||r.includes("contract")?e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your smart contract...",label:"Contract Description",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🔗 Smart Contract Generated

Contract: ${s||"Custom Contract"}
Blockchain: Ethereum
Network: Sepolia Testnet

\`\`\`solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract ${(s||"MyContract").replace(/\s+/g,"")} {
    address public owner;
    uint256 public totalSupply;

    constructor() {
        owner = msg.sender;
    }

    function execute() public view returns (bool) {
        return true;
    }
}
\`\`\`

✅ Contract verified
📊 Gas estimate: 245,000 units`),i(!1)},1800)},icon:D,label:"Generate Smart Contract"}),n&&e.jsx(g,{value:n})]}):r.includes("metaverse")||r.includes("avatar")?e.jsxs(m,{tool:t,children:[e.jsx(p,{value:s,onChange:a,placeholder:"Describe your metaverse avatar...",label:"Avatar Description",multiline:!0}),e.jsx("div",{className:"grid grid-cols-3 gap-3",children:["Human","Fantasy","Cyberpunk","Cartoon","Realistic","Minimal"].map(c=>e.jsx("button",{className:"px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:border-indigo-500/30 hover:text-white transition-all",children:c},c))}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌐 Metaverse Avatar Created

Style: ${s||"Custom"}
Polygons: 24,500
Textures: 4K PBR
Rigging: Full body IK

📥 Ready for: VRChat, Decentraland, Spatial, Meta Horizon
🎮 File size: 12.5 MB (GLB + Textures)`),i(!1)},1500)},icon:$,label:"Create Avatar"}),n&&e.jsx(g,{value:n,label:"Avatar Details"})]}):e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"flex items-center gap-3 p-4 rounded-xl bg-gradient-to-r from-violet-500/10 to-purple-500/10 border border-violet-500/20 mb-4",children:[e.jsx($,{className:"w-6 h-6 text-violet-400"}),e.jsxs("div",{children:[e.jsx("div",{className:"text-white font-medium",children:"Future Tech Tool"}),e.jsx("div",{className:"text-sm text-gray-500",children:t.description})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter input for ${t.name}...`,multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{i(!1)},1200)},icon:$,label:`Run ${t.name}`})]})}function Dx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return t.name.toLowerCase(),e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-r from-slate-500/10 to-blue-500/10 border border-slate-500/20 mb-4",children:[e.jsx("div",{className:"text-white font-medium",children:"🌌 Astronomy & Space Tool"}),e.jsx("div",{className:"text-sm text-gray-500",children:t.description})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter astronomical data or target...",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌠 ${t.name} Results

Target: ${s||"Deep Space"}
Distance: ${(Math.random()*1e6+100).toFixed(0)} light years
Type: Stellar/Planetary
Magnitude: ${(Math.random()*20-5).toFixed(1)}

📊 Analysis: Completed
🌍 Observability: ${Math.random()>.5?"Optimal":"Limited"} tonight
📡 Data sources: Hubble, JWST, Chandra`),i(!1)},1500)},icon:Q,label:"Analyze"}),n&&e.jsx(g,{value:n,label:"Space Data"})]})}function Ox({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"p-4 rounded-xl bg-gradient-to-r from-fuchsia-500/10 to-pink-500/10 border border-fuchsia-500/20 mb-4",children:[e.jsx("div",{className:"text-white font-medium",children:"🔬 Scientific Tool"}),e.jsx("div",{className:"text-sm text-gray-500",children:t.description})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsx(p,{value:s,onChange:a,placeholder:"Input parameters...",label:"Input"}),e.jsxs("select",{className:"px-3 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-sm",children:[e.jsx("option",{children:"Standard Mode"}),e.jsx("option",{children:"Advanced Mode"}),e.jsx("option",{children:"Research Mode"})]})]}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🧪 ${t.name} - Results

Input: ${s||"Standard"}
Status: Completed

📊 Results:
• Analysis: ${(Math.random()*100).toFixed(1)}%
• Confidence: ${(85+Math.random()*15).toFixed(1)}%
• Processing: ${(Math.random()*5+.5).toFixed(1)}s

📝 Report: Ready for review
🔬 Method: AI-enhanced scientific analysis`),i(!1)},2e3)},icon:$,label:"Run Analysis"}),n&&e.jsx(g,{value:n,label:"Scientific Results"})]})}function Bx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center",children:[e.jsx("div",{className:"text-emerald-400 font-bold text-lg",children:"🌡️"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Temperature"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center",children:[e.jsx("div",{className:"text-blue-400 font-bold text-lg",children:"💧"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Humidity"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center",children:[e.jsx("div",{className:"text-amber-400 font-bold text-lg",children:"🌬️"}),e.jsx("div",{className:"text-xs text-gray-500",children:"Wind"})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter location or environmental data...",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🌍 Environmental Analysis

Location: ${s||"Global"}

Climate Metrics:
• Carbon Impact: ${(Math.random()*10).toFixed(1)} tons CO2
• Air Quality Index: ${Math.floor(Math.random()*150+20)}
• Renewable Score: ${Math.floor(Math.random()*100)}%
• Biodiversity Index: ${(Math.random()*10).toFixed(1)}

✅ Analysis Complete
🌱 Sustainability Score: ${Math.floor(Math.random()*100)}/100`),i(!1)},1500)},icon:L,label:"Analyze Environment"}),n&&e.jsx(g,{value:n,label:"Climate Data"})]})}function Gx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-4 gap-2 mb-4",children:["🎮","🎲","🎯","🏆"].map((r,c)=>e.jsx("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-center text-2xl hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all cursor-pointer",children:r},c))}),e.jsx(p,{value:s,onChange:a,placeholder:`Enter gaming input for ${t.name}...`,multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎮 ${t.name} - Results

Input: ${s||"Default"}
Status: Ready

Game Stats:
• Performance: ${Math.floor(60+Math.random()*40)} FPS
• Latency: ${Math.floor(10+Math.random()*50)}ms
• Resolution: 1920x1080
• Quality: Ultra

🏆 Score: ${Math.floor(Math.random()*9999+1)}
🎯 Accuracy: ${(80+Math.random()*20).toFixed(1)}%`),i(!1)},1e3)},icon:J,label:`Run ${t.name}`}),n&&e.jsx(g,{value:n,label:"Gaming Output"})]})}function Hx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"flex gap-3 mb-4",children:["🎬","🎵","📺","🎪","🎭","🎨"].map((r,c)=>e.jsx("div",{className:"p-3 rounded-xl bg-white/5 border border-white/10 text-2xl hover:bg-pink-500/10 hover:border-pink-500/30 transition-all cursor-pointer",children:r},c))}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter your entertainment content input...",multiline:!0}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🎬 ${t.name} - Results

Content: ${s||"Standard input"}
Format: Digital Media

📊 Analysis:
• Quality Score: ${(70+Math.random()*30).toFixed(0)}%
• Popularity Index: ${Math.floor(Math.random()*100)}
• Engagement Rate: ${(Math.random()*10).toFixed(1)}%
• Recommendation: ${["Highly Recommended","Good","Trending","Viral Potential"][Math.floor(Math.random()*4)]}

🎯 Target Audience: General
📈 Trend Direction: ${["Rising","Stable","Viral"][Math.floor(Math.random()*3)]}`),i(!1)},1e3)},icon:J,label:"Process"}),n&&e.jsx(g,{value:n,label:"Entertainment Data"})]})}function Wx({tool:t}){const{input:s,setInput:a,output:n,setOutput:o,setProcessing:i}=R();return e.jsxs(m,{tool:t,children:[e.jsx("div",{className:"grid grid-cols-3 gap-3 mb-4",children:["📡","⚡","🔋","🌡️","📊","🔌"].map((r,c)=>e.jsx("div",{className:"p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-center text-2xl hover:bg-cyan-500/20 transition-all cursor-pointer",children:r},c))}),e.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-4",children:[e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("div",{className:"text-sm text-gray-500",children:"Device Status"}),e.jsx("div",{className:"text-emerald-400 font-bold",children:"🟢 Online"})]}),e.jsxs("div",{className:"p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("div",{className:"text-sm text-gray-500",children:"Signal Strength"}),e.jsxs("div",{className:"text-white font-bold",children:["-$",Math.floor(30+Math.random()*40)," dBm"]})]})]}),e.jsx(p,{value:s,onChange:a,placeholder:"Enter IoT command or device ID..."}),e.jsx(x,{onClick:()=>{i(!0),setTimeout(()=>{o(`🤖 IoT Device Control

Device: ${s||"IoT-Device-001"}
Status: Connected

Telemetry:
• Temperature: ${(20+Math.random()*30).toFixed(1)}°C
• Humidity: ${(30+Math.random()*60).toFixed(1)}%
• Battery: ${(50+Math.random()*50).toFixed(0)}%
• Signal: Excellent
• Uptime: ${Math.floor(Math.random()*720)} hours

✅ Command executed successfully
📊 Data logged to cloud`),i(!1)},1200)},icon:L,label:"Send Command"}),n&&e.jsx(g,{value:n,label:"IoT Data"})]})}function Ux({tool:t}){switch(t.category){case"Video/Audio Tools":return e.jsx(bc,{tool:t});case"Content Writing":return e.jsx(Gc,{tool:t});case"SEO/Digital Marketing":return e.jsx(dd,{tool:t});case"Design/Creative":return e.jsx(Ed,{tool:t});case"Developers/Coding":return e.jsx(au,{tool:t});case"Business/Finance":return e.jsx(ku,{tool:t});case"Education/Learning":return e.jsx(zu,{tool:t});case"HealthTech/BioTech":return e.jsx(oh,{tool:t});case"Personal/Lifestyle":return e.jsx(Sh,{tool:t});case"Technology/Future":return e.jsx(Vh,{tool:t});case"Climate/Environment":return e.jsx(am,{tool:t});case"Entertainment/Culture":return e.jsx(ym,{tool:t});case"Gaming/ARVR":return e.jsx(Fm,{tool:t});case"IoT/Robotics":return e.jsx(Ym,{tool:t});case"Space/Astronomy":return e.jsx(lx,{tool:t});case"Generative Science":return e.jsx(Mx,{tool:t});default:return e.jsx(Fx,{tool:t})}}function Vx(){const{tool:t,sameCategory:s}=Ot(),{aiTools:a}=K(),n=Me(t.category);return qn(t.status),_n({slug:t.slug,name:t.name,category:t.category,source:"csv"}),e.jsxs("div",{className:"min-h-screen bg-black",children:[e.jsxs(X,{children:[e.jsxs("title",{children:[t.name," - Use Online Free | MegatoolsX"]}),e.jsx("meta",{name:"description",content:t.description})]}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs("nav",{className:"flex items-center gap-2 text-sm text-gray-500 mb-8",children:[e.jsx(S,{to:"/",className:"hover:text-indigo-400",children:"Home"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx(S,{to:"/tools",className:"hover:text-indigo-400",children:"Tools"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx("span",{className:"text-white",children:t.name})]}),e.jsxs("div",{className:"flex gap-8",children:[e.jsx("aside",{className:"hidden lg:block w-64 flex-shrink-0",children:e.jsx("div",{className:"sticky top-24",children:e.jsx(Kn,{slug:t.slug})})}),e.jsx("div",{className:"flex-1 min-w-0",children:e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsxs("div",{className:"flex items-start gap-6 mb-8",children:[e.jsx("div",{className:"w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold text-white flex-shrink-0",style:{background:`linear-gradient(135deg, ${n}, #6366f1)`},children:t.name.charAt(0)}),e.jsxs("div",{className:"flex-1",children:[e.jsx("h1",{className:"text-3xl font-bold text-white mb-2",children:t.name}),e.jsxs("div",{className:"flex items-center gap-2 mb-3 flex-wrap",children:[e.jsx(at,{status:t.status,size:"md"}),e.jsx("span",{className:"px-3 py-1 rounded-full text-sm border",style:{color:n,borderColor:`${n}40`,background:`${n}15`},children:t.category})]}),e.jsx("p",{className:"text-gray-400",children:t.description})]})]}),e.jsx(Yn,{className:"mb-8",ref:{slug:t.slug,name:t.name,category:t.category,source:"csv"}}),e.jsx("div",{className:"mb-8",children:t.status==="Future"?e.jsxs("div",{className:"rounded-2xl border border-amber-500/20 bg-gradient-to-b from-amber-500/[0.05] to-transparent p-6",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx(Ae,{className:"w-5 h-5 text-amber-400"}),e.jsxs("span",{className:"font-medium text-amber-300",children:[t.name," is coming soon"]})]}),e.jsxs("p",{className:"text-gray-400 leading-relaxed",children:["This tool is listed in our database as an upcoming release. We're preparing a full interactive guide and a live version will appear here once it launches. Meanwhile, explore the ",e.jsx(S,{to:`/category/${t.category.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}`,className:"text-indigo-400 hover:underline",children:t.category})," category for tools you can use right now."]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-2 text-sm mb-4",style:{color:t.status==="Generative"?"#a855f7":"#10b981"},children:[t.status==="Generative"?e.jsx(Rr,{className:"w-4 h-4"}):e.jsx(J,{className:"w-4 h-4"}),e.jsx("span",{className:"font-medium",children:t.status==="Generative"?`Use ${t.name} Online — New AI Tool`:`Use ${t.name} Online — Free Tool`})]}),e.jsx(Ux,{tool:t})]})}),e.jsxs("div",{className:"bg-gradient-to-b from-white/[0.03] to-transparent border border-white/5 rounded-2xl p-6 lg:p-8 space-y-8",children:[e.jsx(gt,{title:`What is ${t.name}?`,children:e.jsx("p",{className:"text-gray-300 leading-relaxed",children:t.description})}),e.jsx(gt,{title:"Category",children:e.jsxs(S,{to:`/category/${t.category.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}`,className:"inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 text-sm hover:bg-indigo-500/20 transition-all",children:[t.category," ",e.jsx(Y,{className:"w-3 h-3"})]})}),t.seoKeywords&&e.jsx(gt,{title:"Keywords",children:e.jsx("div",{className:"flex flex-wrap gap-2",children:t.seoKeywords.split(",").map((o,i)=>e.jsx("span",{className:"px-2 py-1 rounded-lg bg-white/5 text-gray-400 text-xs",children:o.trim()},i))})}),e.jsx(gt,{title:`More in ${t.category}`,children:e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",children:s.slice(0,6).map(o=>e.jsxs(S,{to:`/tools/${o.slug}`,className:"flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/5 hover:bg-indigo-500/5 hover:border-indigo-500/20 transition-all group",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs",style:{background:`linear-gradient(135deg, ${Me(o.category)}, #6366f1)`},children:o.name.charAt(0)}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"text-white text-sm group-hover:text-indigo-400 transition-colors truncate",children:o.name}),e.jsx("div",{className:"text-gray-500 text-xs truncate",children:o.category})]})]},o.slug))})})]})]})})]})]})]})}function gt({title:t,children:s}){return e.jsxs("section",{children:[e.jsxs("h2",{className:"text-xl font-bold text-white mb-4 flex items-center gap-3",children:[e.jsx("span",{className:"w-1 h-6 bg-indigo-500 rounded-full inline-block"}),t]}),s]})}const nr={"how-to-use":{title:"How to Use",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Learn how to use ",t.name," effectively with our step-by-step guide."]}),e.jsx("div",{className:"space-y-6",children:[{step:1,title:"Access the Tool",desc:`Visit the ${t.name} website or open the app on your device.`},{step:2,title:"Create an Account",desc:"Sign up with your email address or log in if you already have an account."},{step:3,title:"Explore the Dashboard",desc:"Take a moment to familiarize yourself with the interface and available options."},{step:4,title:"Configure Settings",desc:"Adjust settings according to your preferences and requirements."},{step:5,title:"Start Using",desc:`Begin using ${t.name} for your ${t.category.toLowerCase()} needs.`}].map(s=>e.jsxs("div",{className:"flex gap-4",children:[e.jsx("div",{className:"w-8 h-8 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 text-sm font-bold flex-shrink-0",children:s.step}),e.jsxs("div",{children:[e.jsx("h4",{className:"text-white font-medium",children:s.title}),e.jsx("p",{className:"text-gray-400 text-sm mt-1",children:s.desc})]})]},s.step))})]})},features:{title:"Features",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:[t.name," offers a range of powerful features for ",t.category.toLowerCase(),"."]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:["User-friendly interface","Fast and reliable performance","Cross-platform support","Secure data handling","Regular updates","24/7 customer support","Integration capabilities","Advanced analytics","Customizable settings","Cloud synchronization","Multi-language support","Export/Import options"].map((s,a)=>e.jsxs("div",{className:"flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx(ta,{className:"w-5 h-5 text-emerald-500 flex-shrink-0"}),e.jsx("span",{className:"text-gray-300 text-sm",children:s})]},a))})]})},problems:{title:"Common Problems",icon:e.jsx(ms,{className:"w-5 h-5 text-red-400"}),content:t=>e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Common issues users face with ",t.name," and how to resolve them."]}),e.jsx("div",{className:"space-y-4",children:[{problem:"Connection issues",solution:"Check your internet connection. Try refreshing the page or clearing your browser cache."},{problem:"Account access problems",solution:'Use the "Forgot Password" option to reset your password. Check your email for verification links.'},{problem:"Slow performance",solution:"Clear browser cache, update to the latest version, or try a different browser."},{problem:"File upload failures",solution:"Check file size limits. Supported formats vary. Try compressing your files."},{problem:"Sync not working",solution:"Ensure you're logged into the same account on all devices. Check your internet connection."}].map((s,a)=>e.jsx("div",{className:"p-4 rounded-xl bg-white/[0.03] border border-white/5",children:e.jsxs("div",{className:"flex items-start gap-3",children:[e.jsx(ms,{className:"w-5 h-5 text-red-400 flex-shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("h4",{className:"text-white font-medium text-sm",children:s.problem}),e.jsxs("p",{className:"text-gray-400 text-sm mt-1",children:["Solution: ",s.solution]})]})]})},a))})]})},solutions:{title:"Solutions",icon:e.jsx(ta,{className:"w-5 h-5 text-emerald-400"}),content:t=>{const s=nr.problems?.content(t);return e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Proven solutions for common ",t.name," issues."]}),s]})}},faq:{title:"FAQ",icon:e.jsx($e,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Frequently asked questions about ",t.name,"."]}),e.jsx("div",{className:"space-y-4",children:[{q:`What is ${t.name}?`,a:`${t.name} is a ${t.category.toLowerCase()} tool that ${t.description.toLowerCase()}`},{q:`Is ${t.name} free?`,a:"Pricing varies. Check the official website for the most up-to-date pricing information."},{q:"How do I get started?",a:"Visit the official website, create an account, and follow the onboarding guide."},{q:"What platforms are supported?",a:"Most online tools work on all major browsers and operating systems."},{q:"Is my data secure?",a:"Always review the privacy policy and security measures on the official website."}].map((s,a)=>e.jsxs("div",{className:"p-4 rounded-xl bg-white/[0.03] border border-white/5",children:[e.jsx("h4",{className:"text-white font-medium text-sm mb-2",children:s.q}),e.jsx("p",{className:"text-gray-400 text-sm",children:s.a})]},a))})]})},alternatives:{title:"Alternatives",icon:e.jsx(G,{className:"w-5 h-5 text-amber-400"}),content:t=>e.jsxs("div",{children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Explore alternatives to ",t.name,"."]}),e.jsxs("div",{className:"text-center py-8 text-gray-500",children:["Browse more tools in the ",e.jsx(S,{to:"/tools",className:"text-indigo-400 hover:underline",children:"Mega Tools"})," section."]})]})},download:{title:"Download",icon:e.jsx(q,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsxs("div",{className:"text-center py-12",children:[e.jsx(q,{className:"w-16 h-16 text-indigo-500 mx-auto mb-4"}),e.jsxs("h3",{className:"text-2xl font-bold text-white mb-2",children:["Download ",t.name]}),e.jsx("p",{className:"text-gray-400 mb-8",children:"Get the latest version from the official source."}),e.jsxs("a",{href:`https://${t.slug}.com/download`,target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-medium hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg shadow-indigo-500/25",children:[e.jsx(q,{className:"w-5 h-5"})," Download Now"]})]})},resources:{title:"Resources",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsxs("div",{className:"space-y-4",children:[e.jsxs("p",{className:"text-gray-300 mb-6",children:["Helpful resources for ",t.name,"."]}),[{title:`Official ${t.name} Website`,type:"website",url:`https://${t.slug}.com`},{title:`${t.name} Documentation`,type:"documentation",url:`https://${t.slug}.com/docs`},{title:`${t.name} Support`,type:"support",url:`https://${t.slug}.com/support`},{title:`${t.name} Blog`,type:"blog",url:`https://${t.slug}.com/blog`}].map((s,a)=>e.jsxs("a",{href:s.url,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/5 hover:bg-indigo-500/5 hover:border-indigo-500/20 transition-all group",children:[e.jsx(A,{className:"w-5 h-5 text-gray-500 group-hover:text-indigo-400"}),e.jsxs("div",{className:"flex-1",children:[e.jsx("div",{className:"text-white text-sm group-hover:text-indigo-400 transition-colors",children:s.title}),e.jsx("span",{className:"text-xs text-gray-500",children:s.type})]}),e.jsx(Z,{className:"w-4 h-4 text-gray-600 group-hover:text-indigo-400"})]},a))]})}},zx={installation:{title:"Installation",icon:e.jsx(q,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Installation"})},setup:{title:"Setup Guide",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Setup"})},login:{title:"Login Guide",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Login"})},signup:{title:"Sign Up Guide",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Sign Up"})},pricing:{title:"Pricing",icon:e.jsx(G,{className:"w-5 h-5 text-amber-400"}),content:t=>e.jsx(W,{tool:t,section:"Pricing"})},templates:{title:"Templates",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Templates"})},"keyboard-shortcuts":{title:"Keyboard Shortcuts",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Keyboard Shortcuts"})},api:{title:"API Reference",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"API"})},automation:{title:"Automation",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Automation"})},integrations:{title:"Integrations",icon:e.jsx(G,{className:"w-5 h-5 text-amber-400"}),content:t=>e.jsx(W,{tool:t,section:"Integrations"})},extensions:{title:"Extensions",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Extensions"})},plugins:{title:"Plugins",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Plugins"})},"error-codes":{title:"Error Codes",icon:e.jsx(ms,{className:"w-5 h-5 text-red-400"}),content:t=>e.jsx(W,{tool:t,section:"Error Codes"})},"pros-cons":{title:"Pros & Cons",icon:e.jsx(G,{className:"w-5 h-5 text-amber-400"}),content:t=>e.jsx(W,{tool:t,section:"Pros and Cons"})},history:{title:"History",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"History"})},"latest-update":{title:"Latest Update",icon:e.jsx($,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Latest Update"})},news:{title:"News",icon:e.jsx(A,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"News"})},reviews:{title:"Reviews",icon:e.jsx(G,{className:"w-5 h-5 text-amber-400"}),content:t=>e.jsx(W,{tool:t,section:"Reviews"})},community:{title:"Community",icon:e.jsx(xe,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Community"})},"official-links":{title:"Official Links",icon:e.jsx(Z,{className:"w-5 h-5 text-indigo-400"}),content:t=>e.jsx(W,{tool:t,section:"Official Links"})}},qx={...nr,...zx};function W({tool:t,section:s}){return e.jsxs("div",{className:"text-center py-12",children:[e.jsx(A,{className:"w-12 h-12 text-indigo-500 mx-auto mb-4"}),e.jsxs("h3",{className:"text-xl font-bold text-white mb-2",children:[s," Guide"]}),e.jsxs("p",{className:"text-gray-400 mb-6 max-w-md mx-auto",children:["Learn more about ",s.toLowerCase()," for ",t.name,". Visit the official website for detailed information."]}),e.jsxs("a",{href:`https://${t.slug}.com`,target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all",children:[e.jsx(Z,{className:"w-4 h-4"})," Visit Official Website"]})]})}function Qx(){const{tool:t,sameCategory:s}=Ot(),{section:a}=_e(),n=a?qx[a]:void 0,o=n?.title||"Overview",i=n?.content(t);return e.jsxs("div",{className:"min-h-screen bg-black",children:[e.jsxs(X,{children:[e.jsxs("title",{children:[o," - ",t.name," | MegatoolsX"]}),e.jsx("meta",{name:"description",content:`${o} guide for ${t.name}. ${t.description}`})]}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs("nav",{className:"flex items-center gap-2 text-sm text-gray-500 mb-8",children:[e.jsx(S,{to:"/",className:"hover:text-indigo-400",children:"Home"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx(S,{to:"/tools",className:"hover:text-indigo-400",children:"Tools"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx(S,{to:`/tools/${t.slug}`,className:"hover:text-indigo-400",children:t.name}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx("span",{className:"text-white",children:o})]}),e.jsxs("div",{className:"flex gap-8",children:[e.jsx("aside",{className:"hidden lg:block w-64 flex-shrink-0",children:e.jsx("div",{className:"sticky top-24",children:e.jsx(Kn,{slug:t.slug})})}),e.jsx("div",{className:"flex-1 min-w-0",children:e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.3},children:[e.jsxs("div",{className:"flex items-center gap-4 mb-8",children:[e.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-lg font-bold text-white flex-shrink-0",children:t.name.charAt(0)}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-bold text-white",children:o}),e.jsxs("p",{className:"text-gray-500 text-sm mt-1",children:[t.name," — Complete Guide & Tutorial"]})]})]}),e.jsx("div",{className:"bg-gradient-to-b from-white/[0.03] to-transparent border border-white/5 rounded-2xl p-6 lg:p-8",children:i||e.jsxs("div",{className:"text-center py-12",children:[e.jsx("h3",{className:"text-xl text-white font-medium mb-2",children:"Content Coming Soon"}),e.jsx("p",{className:"text-gray-500",children:"This section is being updated."})]})}),e.jsxs("div",{className:"mt-8",children:[e.jsxs("h3",{className:"text-lg font-bold text-white mb-4",children:["More in ",t.category]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",children:s.slice(0,6).map(r=>e.jsxs(S,{to:`/tools/${r.slug}`,className:"flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/5 hover:bg-indigo-500/5 hover:border-indigo-500/20 transition-all group",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs",children:r.name.charAt(0)}),e.jsx("div",{className:"text-white text-sm group-hover:text-indigo-400 transition-colors truncate",children:r.name})]},r.slug))})]})]},a)})]})]})]})}function _x(){const{categorySlug:t}=_e(),{csvTools:s,csvCategories:a}=K(),n=a.find(i=>i.slug===t),o=n?s.filter(i=>i.category.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")===t):[];return e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsxs("nav",{className:"flex items-center gap-2 text-sm text-gray-500 mb-8",children:[e.jsx(S,{to:"/",className:"hover:text-indigo-400",children:"Home"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx(S,{to:"/tools",className:"hover:text-indigo-400",children:"Tools"}),e.jsx(Y,{className:"w-4 h-4"}),e.jsx("span",{className:"text-white",children:n?.name||t})]}),e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsx("h1",{className:"text-3xl font-bold text-white mb-2",children:n?.name||t}),e.jsxs("p",{className:"text-gray-400 mb-8",children:[o.length," tools in this category"]})]}),o.length===0?e.jsxs("div",{className:"text-center py-20",children:[e.jsx(Q,{className:"w-12 h-12 text-gray-600 mx-auto mb-4"}),e.jsx("h3",{className:"text-xl text-white font-medium mb-2",children:"Category not found"}),e.jsxs("p",{className:"text-gray-500",children:["Browse all tools from the ",e.jsx(S,{to:"/tools",className:"text-indigo-400 hover:underline",children:"Mega Tools"})," page."]})]}):e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",children:o.map((i,r)=>e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:r*.01},className:"group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 hover:from-indigo-500/5 transition-all",children:[e.jsxs("div",{className:"flex items-start justify-between mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0",style:{background:`linear-gradient(135deg, ${Me(i.category)}, #6366f1)`},children:i.name.charAt(0)}),e.jsx(at,{status:i.status})]}),e.jsx("h3",{className:"text-white font-semibold text-sm mb-1 group-hover:text-indigo-400 transition-colors truncate",children:i.name}),e.jsx("p",{className:"text-gray-500 text-xs mb-4 line-clamp-2",children:i.description}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(S,{to:`/tools/${i.slug}`,className:"flex-1 px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs text-center hover:bg-indigo-500/20 transition-all",children:"Open Guide"}),e.jsx("a",{href:`https://${i.slug}.com`,target:"_blank",rel:"noopener noreferrer",className:"px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 text-xs hover:text-white hover:bg-white/10 transition-all",children:e.jsx(Z,{className:"w-3 h-3"})})]})]},i.slug))})]})}const Kx=Ut((t,s)=>({isAuthenticated:localStorage.getItem("megatoolsx-admin")==="authenticated",tools:[],login:a=>{const n=a==="admin123";return n&&(localStorage.setItem("megatoolsx-admin","authenticated"),t({isAuthenticated:!0})),n},logout:()=>{localStorage.removeItem("megatoolsx-admin"),t({isAuthenticated:!1})},setTools:a=>t({tools:a}),addTool:a=>t(n=>({tools:[...n.tools,a]})),updateTool:(a,n)=>t(o=>({tools:o.tools.map(i=>i.id===a?{...i,...n}:i)})),deleteTool:a=>t(n=>({tools:n.tools.filter(o=>o.id!==a)}))}));function Yx(){const{isAuthenticated:t,login:s,logout:a}=Kx(),n=K().csvTools,o=K().csvCategories,[i,r]=l.useState(""),[c,d]=l.useState(!1);if(!t)return e.jsx("div",{className:"min-h-screen flex items-center justify-center bg-black",children:e.jsxs(k.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},className:"w-full max-w-md p-8 rounded-2xl border border-white/5 bg-white/[0.03]",children:[e.jsxs("div",{className:"text-center mb-8",children:[e.jsx(nn,{className:"w-12 h-12 text-indigo-500 mx-auto mb-4"}),e.jsx("h1",{className:"text-2xl font-bold text-white",children:"Admin Login"}),e.jsx("p",{className:"text-gray-500 text-sm mt-1",children:"Enter password to access dashboard"})]}),e.jsxs("form",{onSubmit:u=>{u.preventDefault(),s(i)||d(!0)},className:"space-y-4",children:[e.jsx("input",{type:"password",value:i,onChange:u=>{r(u.target.value),d(!1)},placeholder:"Enter admin password",className:"w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"}),c&&e.jsx("p",{className:"text-red-400 text-sm",children:"Invalid password"}),e.jsx(H,{type:"submit",className:"w-full",children:"Login"})]})]})});const h=[{label:"Total Tools",value:n.length,icon:sa,color:"text-indigo-400"},{label:"Categories",value:o.length,icon:rn,color:"text-purple-400"},{label:"Total Users",value:"5M+",icon:xe,color:"text-emerald-400"},{label:"Reviews",value:n.reduce((u,f)=>u+(f.reviewCount||0),0).toLocaleString(),icon:G,color:"text-amber-400"}];return e.jsxs("div",{className:"min-h-screen bg-black",children:[e.jsx("div",{className:"border-b border-white/5 bg-white/[0.02]",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(sa,{className:"w-6 h-6 text-indigo-500"}),e.jsx("h1",{className:"text-xl font-bold text-white",children:"Admin Dashboard"})]}),e.jsxs("button",{onClick:a,className:"flex items-center gap-2 px-4 py-2 rounded-xl text-red-400 hover:bg-red-500/10 transition-all",children:[e.jsx(Pr,{className:"w-4 h-4"})," Logout"]})]})})}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 mb-8",children:h.map((u,f)=>e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:f*.1},className:"p-5 rounded-2xl border border-white/5 bg-white/[0.03]",children:[e.jsx(u.icon,{className:z("w-8 h-8 mb-3",u.color)}),e.jsx("div",{className:"text-2xl font-bold text-white",children:u.value}),e.jsx("div",{className:"text-sm text-gray-500",children:u.label})]},u.label))}),e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 mb-8",children:[{label:"Add Tool",icon:Lr,color:"bg-emerald-500/10 text-emerald-400"},{label:"Bulk Import CSV",icon:U,color:"bg-blue-500/10 text-blue-400"},{label:"AI Generation",icon:G,color:"bg-purple-500/10 text-purple-400"},{label:"SEO Manager",icon:nt,color:"bg-amber-500/10 text-amber-400"}].map((u,f)=>e.jsxs("button",{className:z("flex items-center gap-3 p-4 rounded-xl border border-white/5 bg-white/[0.03] hover:bg-white/[0.06] transition-all"),children:[e.jsx("div",{className:z("p-2 rounded-lg",u.color),children:e.jsx(u.icon,{className:"w-5 h-5"})}),e.jsx("span",{className:"text-white text-sm font-medium",children:u.label})]},u.label))}),e.jsxs("div",{className:"rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden",children:[e.jsxs("div",{className:"p-4 border-b border-white/5 flex items-center justify-between",children:[e.jsxs("h2",{className:"text-lg font-semibold text-white",children:["All Tools (",n.length,")"]}),e.jsx("div",{className:"flex items-center gap-2",children:e.jsxs("div",{className:"relative",children:[e.jsx(Q,{className:"absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"}),e.jsx("input",{type:"text",placeholder:"Search tools...",className:"pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"})]})})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b border-white/5 text-left",children:[e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Name"}),e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Category"}),e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Rating"}),e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Pricing"}),e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Platforms"}),e.jsx("th",{className:"p-4 text-gray-500 text-sm font-medium",children:"Actions"})]})}),e.jsx("tbody",{children:n.slice(0,50).map((u,f)=>e.jsxs("tr",{className:"border-b border-white/5 hover:bg-white/[0.02] transition-colors",children:[e.jsx("td",{className:"p-4",children:e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs",children:u.name.charAt(0)}),e.jsx("span",{className:"text-white text-sm",children:u.name})]})}),e.jsx("td",{className:"p-4 text-gray-400 text-sm",children:u.category}),e.jsx("td",{className:"p-4",children:e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx(G,{className:"w-3.5 h-3.5 text-amber-500"}),e.jsx("span",{className:"text-white text-sm",children:u.rating})]})}),e.jsx("td",{className:"p-4",children:e.jsx("span",{className:"px-2 py-0.5 rounded text-xs bg-white/5 text-gray-400",children:u.pricingType})}),e.jsx("td",{className:"p-4",children:e.jsxs("div",{className:"flex gap-1",children:[u.platform.slice(0,2).map(v=>e.jsx("span",{className:"text-xs text-gray-500",children:v},v)),u.platform.length>2&&e.jsxs("span",{className:"text-xs text-gray-600",children:["+",u.platform.length-2]})]})}),e.jsx("td",{className:"p-4",children:e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("button",{className:"p-1.5 rounded-lg text-blue-400 hover:bg-blue-500/10",children:e.jsx(Er,{className:"w-4 h-4"})}),e.jsx("button",{className:"p-1.5 rounded-lg text-red-400 hover:bg-red-500/10",children:e.jsx(Nt,{className:"w-4 h-4"})})]})})]},u.slug||f))})]})})]})]})]})}const Jx=[{value:"2,500+",label:"Mega Tools",icon:de},{value:"30+",label:"AI Tools",icon:$},{value:"16+",label:"Categories",icon:A},{value:"1M+",label:"Monthly Visitors",icon:xe}],Xx=[{title:"Knowledge for All",desc:"Democratizing digital tool knowledge worldwide.",icon:L},{title:"Quality Content",desc:"Accurate, up-to-date guides and tutorials.",icon:ue},{title:"User First",desc:"Everything we build serves our users.",icon:me},{title:"Innovation",desc:"Constantly evolving with the digital landscape.",icon:Ft}];function Zx(){return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"About Us | MegatoolsX"}),e.jsx("meta",{name:"description",content:"Learn about MegatoolsX - the world's largest digital tools knowledge platform."})]}),e.jsxs("section",{className:"relative overflow-hidden py-20 lg:py-28",children:[e.jsx("div",{className:"absolute inset-0 bg-gradient-to-b from-indigo-500/10 via-purple-500/5 to-transparent"}),e.jsx("div",{className:"relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center",children:e.jsxs(k.div,{initial:{opacity:0,y:40},animate:{opacity:1,y:0},children:[e.jsxs("div",{className:"inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm mb-6",children:[e.jsx($,{className:"w-4 h-4"}),e.jsx("span",{children:"Our Story"})]}),e.jsxs("h1",{className:"text-4xl lg:text-6xl font-bold text-white mb-6",children:["The World's Largest",e.jsx("span",{className:"gradient-text",children:" Digital Tools"})," Platform"]}),e.jsx("p",{className:"text-lg text-gray-400 max-w-3xl mx-auto leading-relaxed",children:"MegatoolsX is your ultimate resource for learning how to use any digital tool, AI tool, software, website, app, and browser extension. We provide step-by-step guides, tutorials, and solutions for every tool imaginable."})]})})]}),e.jsx("section",{className:"border-y border-white/5 bg-white/[0.02]",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:e.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-8",children:Jx.map(t=>e.jsxs("div",{className:"text-center",children:[e.jsx(t.icon,{className:"w-6 h-6 text-indigo-500 mx-auto mb-2"}),e.jsx("div",{className:"text-2xl font-bold text-white",children:t.value}),e.jsx("div",{className:"text-sm text-gray-500",children:t.label})]},t.label))})})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-12 items-center",children:[e.jsxs(k.div,{initial:{opacity:0,x:-20},whileInView:{opacity:1,x:0},viewport:{once:!0},children:[e.jsx("h2",{className:"text-3xl font-bold text-white mb-6",children:"Our Mission"}),e.jsx("p",{className:"text-gray-400 leading-relaxed mb-4",children:"In today's digital world, there are thousands of tools available, but finding reliable, comprehensive guides for each one is a challenge. MegatoolsX was created to solve this problem."}),e.jsx("p",{className:"text-gray-400 leading-relaxed mb-4",children:"We curate and create the most comprehensive guides for digital tools of all kinds — from AI-powered platforms to everyday productivity apps. Our database includes detailed information about 2,500+ tools across 16+ categories."}),e.jsx("p",{className:"text-gray-400 leading-relaxed",children:"Whether you're a beginner looking to learn a new tool or an expert seeking advanced tips, MegatoolsX has you covered with step-by-step tutorials, troubleshooting guides, and expert insights."})]}),e.jsxs(k.div,{initial:{opacity:0,x:20},whileInView:{opacity:1,x:0},viewport:{once:!0},className:"rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent p-8",children:[e.jsx("h3",{className:"text-xl font-bold text-white mb-4",children:"What We Offer"}),e.jsx("ul",{className:"space-y-4",children:[{title:"2,500+ Tool Guides",desc:"Comprehensive guides for every tool in our database"},{title:"AI Tools Collection",desc:"Curated collection of 30+ featured AI tools"},{title:"Step-by-Step Tutorials",desc:"Detailed walkthroughs for all skill levels"},{title:"Troubleshooting",desc:"Solutions for common problems and errors"},{title:"Regular Updates",desc:"Content updated regularly to stay current"}].map((t,s)=>e.jsxs("li",{className:"flex items-start gap-3",children:[e.jsx("div",{className:"w-6 h-6 rounded-full bg-indigo-500/10 flex items-center justify-center flex-shrink-0 mt-0.5",children:e.jsx("div",{className:"w-2 h-2 rounded-full bg-indigo-500"})}),e.jsxs("div",{children:[e.jsx("div",{className:"text-white font-medium",children:t.title}),e.jsx("div",{className:"text-sm text-gray-500",children:t.desc})]})]},s))})]})]})})}),e.jsx("section",{className:"py-16 lg:py-24 bg-gradient-to-b from-transparent via-indigo-500/[0.02] to-transparent",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsx("h2",{className:"text-3xl font-bold text-white text-center mb-12",children:"Our Values"}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6",children:Xx.map((t,s)=>e.jsxs(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:s*.1},className:"p-6 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent text-center",children:[e.jsx(t.icon,{className:"w-10 h-10 text-indigo-500 mx-auto mb-4"}),e.jsx("h3",{className:"text-lg font-semibold text-white mb-2",children:t.title}),e.jsx("p",{className:"text-gray-400 text-sm",children:t.desc})]},t.title))})]})}),e.jsx("section",{className:"py-16 lg:py-24",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center",children:e.jsxs("div",{className:"rounded-3xl bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 border border-indigo-500/20 p-12",children:[e.jsx("h2",{className:"text-3xl font-bold text-white mb-4",children:"Start Exploring Tools"}),e.jsx("p",{className:"text-gray-400 text-lg mb-8 max-w-xl mx-auto",children:"Join millions of users who rely on MegatoolsX for their digital tool knowledge."}),e.jsxs("div",{className:"flex items-center justify-center gap-4",children:[e.jsx(S,{to:"/tools",children:e.jsx(H,{size:"lg",children:"Browse Mega Tools"})}),e.jsx(S,{to:"/ai-tools",children:e.jsx(H,{variant:"outline",size:"lg",children:"Explore AI Tools"})})]})]})})})]})}function ep(){const[t,s]=l.useState(!1),[a,n]=l.useState({name:"",email:"",subject:"",message:""}),o=i=>{i.preventDefault(),s(!0),setTimeout(()=>s(!1),3e3)};return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"Contact Us | MegatoolsX"}),e.jsx("meta",{name:"description",content:"Get in touch with the MegatoolsX team. We're here to help!"})]}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center mb-12",children:[e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"Contact Us"}),e.jsx("p",{className:"text-gray-400 text-lg max-w-2xl mx-auto",children:"Have a question, suggestion, or need help? We'd love to hear from you."})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto",children:[e.jsx("div",{className:"space-y-6",children:[{icon:Pt,title:"Email",desc:"hello@megatoolsx.com",action:"Send us an email"},{icon:Ka,title:"Support",desc:"Help Center",action:"Visit help center"},{icon:L,title:"Social",desc:"@megatoolsx",action:"Follow us"}].map((i,r)=>e.jsxs("div",{className:"p-5 rounded-2xl border border-white/5 bg-white/[0.03]",children:[e.jsx(i.icon,{className:"w-6 h-6 text-indigo-500 mb-3"}),e.jsx("h3",{className:"text-white font-semibold mb-1",children:i.title}),e.jsx("p",{className:"text-gray-400 text-sm mb-2",children:i.desc}),e.jsxs("span",{className:"text-indigo-400 text-sm",children:[i.action," →"]})]},r))}),e.jsx("div",{className:"lg:col-span-2",children:e.jsx("div",{className:"rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.03] to-transparent p-6 lg:p-8",children:t?e.jsxs("div",{className:"text-center py-12",children:[e.jsx(rt,{className:"w-16 h-16 text-emerald-500 mx-auto mb-4"}),e.jsx("h3",{className:"text-2xl font-bold text-white mb-2",children:"Message Sent!"}),e.jsx("p",{className:"text-gray-400",children:"We'll get back to you as soon as possible."})]}):e.jsxs("form",{onSubmit:o,className:"space-y-5",children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-5",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm text-gray-400 mb-2",children:"Your Name"}),e.jsx("input",{required:!0,value:a.name,onChange:i=>n({...a,name:i.target.value}),className:"w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50",placeholder:"John Doe"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm text-gray-400 mb-2",children:"Your Email"}),e.jsx("input",{required:!0,type:"email",value:a.email,onChange:i=>n({...a,email:i.target.value}),className:"w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50",placeholder:"john@example.com"})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm text-gray-400 mb-2",children:"Subject"}),e.jsx("input",{required:!0,value:a.subject,onChange:i=>n({...a,subject:i.target.value}),className:"w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50",placeholder:"How can we help?"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm text-gray-400 mb-2",children:"Message"}),e.jsx("textarea",{required:!0,value:a.message,onChange:i=>n({...a,message:i.target.value}),rows:5,className:"w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-y",placeholder:"Tell us more about your inquiry..."})]}),e.jsx(H,{type:"submit",icon:qa,children:"Send Message"})]})})})]})]})]})}const tp=[{icon:ue,title:"Information We Collect",content:"We collect information you provide directly, such as your name and email address when you contact us or subscribe to our newsletter. We also collect anonymous usage data through cookies and analytics to improve our service."},{icon:nn,title:"How We Use Your Information",content:"Your information is used to provide and improve our services, respond to your inquiries, send updates with your consent, and analyze usage patterns to enhance user experience. We never sell your personal information to third parties."},{icon:Te,title:"Data Protection",content:"We implement industry-standard security measures including encryption, secure servers, and regular security audits to protect your data. However, no method of transmission over the internet is 100% secure."},{icon:Fr,title:"Data Storage",content:"Your data is stored on secure servers. We retain your information only as long as necessary to provide our services and comply with legal obligations. You can request deletion of your data at any time."},{icon:Pt,title:"Communication",content:"We may send you service-related emails. You can opt out of marketing communications at any time. We will never ask for sensitive information via email."},{icon:Ir,title:"Cookies",content:"We use essential cookies for site functionality and analytics cookies to understand usage patterns. You can control cookie preferences through your browser settings."}];function sp(){return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"Privacy Policy | MegatoolsX"}),e.jsx("meta",{name:"description",content:"MegatoolsX privacy policy - how we collect, use, and protect your data."})]}),e.jsxs("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"mb-12",children:[e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"Privacy Policy"}),e.jsx("p",{className:"text-gray-400",children:"Last updated: January 2026"}),e.jsx("p",{className:"text-gray-400 mt-4 leading-relaxed",children:"At MegatoolsX, we take your privacy seriously. This policy describes how we collect, use, and protect your personal information when you use our website."})]}),e.jsx("div",{className:"space-y-8",children:tp.map((t,s)=>e.jsx(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:s*.05},className:"p-6 rounded-2xl border border-white/5 bg-white/[0.03]",children:e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center flex-shrink-0",children:e.jsx(t.icon,{className:"w-5 h-5 text-indigo-400"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-xl font-bold text-white mb-2",children:t.title}),e.jsx("p",{className:"text-gray-400 leading-relaxed",children:t.content})]})]})},t.title))}),e.jsxs("div",{className:"mt-12 p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/10",children:[e.jsx("h3",{className:"text-lg font-bold text-indigo-400 mb-2",children:"Contact Us"}),e.jsxs("p",{className:"text-gray-400",children:["If you have questions about this privacy policy, please contact us at ",e.jsx("span",{className:"text-indigo-400",children:"privacy@megatoolsx.com"}),"."]})]})]})]})}const ap=[{icon:O,title:"Acceptance of Terms",content:"By accessing and using MegatoolsX, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you may not use our services."},{icon:St,title:"Use License",content:"Content on MegatoolsX is provided for informational purposes only. You may view, download, and print content for personal, non-commercial use. Redistribution or reproduction of content without permission is prohibited."},{icon:_a,title:"Disclaimer",content:'The information on MegatoolsX is provided "as is" without warranty of any kind. We strive for accuracy but cannot guarantee that all information is complete or current. Tool information may change after publication.'},{icon:rt,title:"User Responsibilities",content:"Users agree to use the website lawfully and not to engage in any activity that could harm the website, its content, or other users. This includes not attempting to access restricted areas or disrupt service."},{icon:L,title:"Third-Party Links",content:"Our website contains links to third-party websites and tools. We are not responsible for the content, privacy practices, or availability of these external sites. Use them at your own risk."},{icon:Dr,title:"Limitation of Liability",content:"MegatoolsX shall not be liable for any damages arising from the use or inability to use our website or the information provided. This includes direct, indirect, incidental, and consequential damages."}];function np(){return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"Terms of Service | MegatoolsX"}),e.jsx("meta",{name:"description",content:"MegatoolsX terms of service - terms and conditions for using our platform."})]}),e.jsxs("div",{className:"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"mb-12",children:[e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"Terms of Service"}),e.jsx("p",{className:"text-gray-400",children:"Last updated: January 2026"}),e.jsx("p",{className:"text-gray-400 mt-4 leading-relaxed",children:"Please read these terms of service carefully before using MegatoolsX."})]}),e.jsx("div",{className:"space-y-8",children:ap.map((t,s)=>e.jsx(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:s*.05},className:"p-6 rounded-2xl border border-white/5 bg-white/[0.03]",children:e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center flex-shrink-0",children:e.jsx(t.icon,{className:"w-5 h-5 text-indigo-400"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-xl font-bold text-white mb-2",children:t.title}),e.jsx("p",{className:"text-gray-400 leading-relaxed",children:t.content})]})]})},t.title))}),e.jsxs("div",{className:"mt-12 p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/10",children:[e.jsx("h3",{className:"text-lg font-bold text-indigo-400 mb-2",children:"Contact"}),e.jsxs("p",{className:"text-gray-400",children:["For questions about these terms, contact us at ",e.jsx("span",{className:"text-indigo-400",children:"legal@megatoolsx.com"}),"."]})]})]})]})}const te=[{title:"The Ultimate Guide to AI Tools in 2026",excerpt:"Discover the best AI tools transforming how we work, create, and solve problems in 2026.",category:"AI Tools",author:"MegatoolsX Team",date:"2026-07-15",readTime:"8 min read",slug:"ultimate-guide-ai-tools-2026",tags:["AI","Tools","Guide"],body:["Artificial intelligence has moved from the future to the present. In 2026, AI tools are not optional — they are essential for staying competitive in almost every field.","Chatbots and language models like ChatGPT and Claude have become the backbone of content creation, customer support, and coding. They can draft emails, write code, summarize documents, and answer questions with human-level fluency.","Image generation tools like Midjourney, DALL-E, and Stable Diffusion have revolutionized design. Marketers, designers, and small business owners now create professional visuals in minutes instead of days.","Video and audio tools such as HeyGen, Synthesia, and ElevenLabs are making it possible to produce studio-quality content without a camera or microphone.","The key to getting value from AI tools is knowing which tool fits which task. That is exactly what MegatoolsX helps you figure out — with step-by-step guides for every tool in our database.","Start by exploring the AI Tools section, pick one tool, and master it. Then expand your toolkit one tool at a time."]},{title:"How to Master Any Digital Tool: A Step-by-Step Framework",excerpt:"Learn our proven framework for mastering any digital tool quickly and effectively.",category:"Guides",author:"MegatoolsX Team",date:"2026-07-10",readTime:"6 min read",slug:"master-any-digital-tool-framework",tags:["Productivity","Framework","Learning"],body:["There are thousands of digital tools, and learning each one from scratch can feel overwhelming. But every tool follows a pattern, and once you learn the pattern, you can master any tool quickly.","Step 1: Understand what the tool does. Read the overview, watch the official demo, and understand the core problem it solves.","Step 2: Set up a sandbox. Create a practice account and explore freely. Do not be afraid to break things — that is how you learn.","Step 3: Learn the 20% that does 80% of the work. Every tool has a handful of features that most people use daily. Master those first.","Step 4: Follow the official documentation. It is the most reliable source of truth for features, shortcuts, and best practices.","Step 5: Build a real project. Applying the tool to an actual task cements your learning better than any tutorial.","Step 6: Teach someone else. The fastest way to deepen your understanding is to explain the tool to another person."]},{title:"Top 10 Productivity Tools Every Professional Needs",excerpt:"Boost your productivity with these essential tools for modern professionals.",category:"Productivity",author:"MegatoolsX Team",date:"2026-07-05",readTime:"5 min read",slug:"top-10-productivity-tools-2026",tags:["Productivity","Work","Essentials"],body:["Productivity is not about doing more — it is about doing the right things efficiently. These ten tools will help you reclaim hours every week.","1. Notion — your all-in-one workspace for notes, docs, wikis, and project management.","2. Slack — streamlined team communication without the email clutter.","3. Todoist — simple, reliable task management that syncs across every device.","4. Zoom — the standard for video meetings and webinars.","5. Google Workspace — docs, sheets, slides, and calendar in one place.","6. Grammarly — catches mistakes and improves your writing everywhere you type.","7. Zapier — automates repetitive tasks between your favorite apps.","8. 1Password — manages all your passwords securely.","9. RescueTime — shows you exactly where your time goes.","10. Obsidian — powerful note-taking for deep thinkers.","Visit the MegatoolsX guide for each of these tools to get started today."]},{title:"Understanding AI: From Chatbots to Image Generation",excerpt:"A comprehensive overview of AI technologies and how they work in everyday tools.",category:"AI",author:"MegatoolsX Team",date:"2026-06-28",readTime:"10 min read",slug:"understanding-ai-chatbots-image-generation",tags:["AI","Education","Technology"],body:["Artificial intelligence is everywhere, but most people do not understand how it actually works. This guide breaks it down without the jargon.","At the core of modern AI is the neural network — a mathematical system inspired by the human brain that learns patterns from massive amounts of data.","Large language models (LLMs) like GPT and Claude are trained on vast text corpora. They predict the next word in a sequence, which is how they generate coherent paragraphs.","Image generation models learn from millions of images paired with text descriptions. When you type a prompt, the model reconstructs an image that matches the description.","Speech tools like ElevenLabs learn the patterns of human voices and can generate realistic speech in any voice you provide.","The best way to understand AI is to use it. Explore the AI tools section of MegatoolsX and try one today."]},{title:"Security Best Practices for Online Tools",excerpt:"Stay safe online with these essential security practices for using digital tools.",category:"Security",author:"MegatoolsX Team",date:"2026-06-20",readTime:"7 min read",slug:"security-best-practices-online-tools",tags:["Security","Privacy","Best Practices"],body:["Every online tool you use is a potential entry point for attackers. Following these practices dramatically reduces your risk.","Use a password manager. Never reuse passwords across sites. Generate strong, unique passwords for every service.","Enable two-factor authentication (2FA) wherever it is available — especially for email, banking, and social media.","Review connected apps and revoke access you no longer use. Many breaches happen through forgotten third-party connections.","Keep your software updated. Updates fix security holes that attackers exploit.","Be skeptical of unsolicited links and attachments, even from people you know. Verify through a separate channel.","Check privacy settings on each tool and limit data sharing to what is necessary."]},{title:"The Future of Digital Tools: Trends to Watch",excerpt:"Explore the emerging trends shaping the future of digital tools and technology.",category:"Trends",author:"MegatoolsX Team",date:"2026-06-15",readTime:"6 min read",slug:"future-digital-tools-trends",tags:["Trends","Future","Technology"],body:["The pace of change in digital tools has never been faster. Here are the trends that will define the next few years.","AI everywhere: artificial intelligence is moving into every category — from design and writing to finance and healthcare.","Agentic workflows: tools are evolving from assistants that answer questions to agents that complete multi-step tasks on your behalf.","Privacy by default: as regulations tighten, tools that protect user data will win trust and market share.","Cross-platform convergence: expect your data and workflows to move seamlessly between desktop, mobile, and cloud.","No-code and low-code: more non-developers will build their own tools and automations without writing code.","MegatoolsX will keep adding guides for the newest tools as they launch. Check the Latest Update section of each tool page for the freshest information."]}];function rp(){const{csvTools:t}=K();return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"Blog - Guides & Tutorials | MegatoolsX"}),e.jsx("meta",{name:"description",content:"Latest guides, tutorials, and articles about digital tools, AI, and technology."})]}),e.jsx("section",{className:"py-16 lg:py-20",children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center",children:[e.jsxs("div",{className:"inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm mb-6",children:[e.jsx(A,{className:"w-4 h-4"}),e.jsx("span",{children:"Blog & Tutorials"})]}),e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"Latest Articles"}),e.jsx("p",{className:"text-gray-400 text-lg max-w-2xl mx-auto",children:"Guides, tutorials, and insights about digital tools, AI, and technology."})]})})}),e.jsx("section",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12",children:e.jsx(S,{to:`/blog/${te[0].slug}`,children:e.jsx(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"relative group rounded-3xl overflow-hidden border border-white/5 bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 p-8 lg:p-12 hover:border-indigo-500/30 transition-all",children:e.jsxs("div",{className:"relative",children:[e.jsx("span",{className:"text-xs px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20",children:te[0].category}),e.jsx("h2",{className:"text-3xl lg:text-4xl font-bold text-white mt-4 mb-4 group-hover:text-indigo-400 transition-colors",children:te[0].title}),e.jsx("p",{className:"text-gray-400 text-lg mb-6 max-w-2xl",children:te[0].excerpt}),e.jsxs("div",{className:"flex items-center gap-4 text-sm text-gray-500 mb-6",children:[e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx(on,{className:"w-4 h-4"}),te[0].author]}),e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx(Ct,{className:"w-4 h-4"}),te[0].date]}),e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx(Ae,{className:"w-4 h-4"}),te[0].readTime]})]}),e.jsxs("span",{className:"inline-flex items-center gap-1 text-indigo-400 font-medium",children:["Read Article ",e.jsx(Lt,{className:"w-4 h-4"})]})]})})})}),e.jsx("section",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 lg:pb-24",children:e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:te.slice(1).map((s,a)=>e.jsx(k.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{delay:a*.05},children:e.jsxs(S,{to:`/blog/${s.slug}`,className:"block group p-6 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 hover:from-indigo-500/5 transition-all h-full",children:[e.jsx("span",{className:"text-xs px-2 py-1 rounded-full bg-indigo-500/10 text-indigo-400",children:s.category}),e.jsx("h3",{className:"text-lg font-bold text-white mt-3 mb-2 group-hover:text-indigo-400 transition-colors",children:s.title}),e.jsx("p",{className:"text-gray-400 text-sm mb-4 line-clamp-3",children:s.excerpt}),e.jsxs("div",{className:"flex items-center gap-3 text-xs text-gray-500",children:[e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx(Ct,{className:"w-3 h-3"}),s.date]}),e.jsxs("span",{className:"flex items-center gap-1",children:[e.jsx(Ae,{className:"w-3 h-3"}),s.readTime]})]})]})},s.slug))})}),e.jsx("section",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 lg:pb-24",children:e.jsxs("div",{className:"rounded-3xl bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 border border-indigo-500/20 p-12 text-center",children:[e.jsxs("h2",{className:"text-3xl font-bold text-white mb-4",children:["Explore ",t.length,"+ Tools"]}),e.jsx("p",{className:"text-gray-400 text-lg mb-8 max-w-xl mx-auto",children:"Our database has comprehensive guides for every tool you can imagine."}),e.jsx(S,{to:"/tools",children:e.jsx(H,{size:"lg",icon:$,children:"Browse All Tools"})})]})})]})}function op(){const{slug:t}=_e(),s=te.find(n=>n.slug===t);if(!s)return e.jsx("div",{className:"min-h-screen flex items-center justify-center px-4",children:e.jsxs("div",{className:"text-center max-w-lg",children:[e.jsx("div",{className:"text-8xl font-bold gradient-text mb-4",children:"404"}),e.jsx("h1",{className:"text-2xl font-bold text-white mb-4",children:"Post Not Found"}),e.jsx("p",{className:"text-gray-400 mb-8",children:"This article doesn't exist or has been moved."}),e.jsx(S,{to:"/blog",children:e.jsx(H,{icon:aa,children:"Back to Blog"})})]})});const a=te.filter(n=>n.slug!==s.slug&&n.category===s.category).concat(te.filter(n=>n.slug!==s.slug&&n.category!==s.category)).slice(0,3);return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsxs("title",{children:[s.title," | MegatoolsX Blog"]}),e.jsx("meta",{name:"description",content:s.excerpt}),e.jsx("link",{rel:"canonical",href:`https://megatoolsx.com/blog/${s.slug}`}),e.jsx("meta",{property:"og:title",content:s.title}),e.jsx("meta",{property:"og:description",content:s.excerpt}),e.jsx("meta",{property:"og:type",content:"article"}),e.jsx("meta",{property:"og:url",content:`https://megatoolsx.com/blog/${s.slug}`}),e.jsx("meta",{name:"twitter:card",content:"summary_large_image"}),e.jsx("script",{type:"application/ld+json",children:JSON.stringify({"@context":"https://schema.org","@type":"BlogPosting",headline:s.title,description:s.excerpt,datePublished:s.date,author:{"@type":"Organization",name:"MegatoolsX"},publisher:{"@type":"Organization",name:"MegatoolsX"},mainEntityOfPage:`https://megatoolsx.com/blog/${s.slug}`})})]}),e.jsxs("div",{className:"max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20",children:[e.jsxs(S,{to:"/blog",className:"inline-flex items-center gap-2 text-sm text-gray-500 hover:text-indigo-400 mb-8 transition-colors",children:[e.jsx(aa,{className:"w-4 h-4"})," Back to Blog"]}),e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},children:[e.jsx("span",{className:"text-xs px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20",children:s.category}),e.jsx("h1",{className:"text-3xl lg:text-4xl font-bold text-white mt-4 mb-6 leading-tight",children:s.title}),e.jsxs("div",{className:"flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-8",children:[e.jsxs("span",{className:"flex items-center gap-1.5",children:[e.jsx(on,{className:"w-4 h-4"}),s.author]}),e.jsxs("span",{className:"flex items-center gap-1.5",children:[e.jsx(Ct,{className:"w-4 h-4"}),s.date]}),e.jsxs("span",{className:"flex items-center gap-1.5",children:[e.jsx(Ae,{className:"w-4 h-4"}),s.readTime]})]}),e.jsx("div",{className:"flex flex-wrap gap-2 mb-8",children:s.tags.map(n=>e.jsxs("span",{className:"inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/5 text-gray-400 text-xs",children:[e.jsx(rn,{className:"w-3 h-3"}),n]},n))})]}),e.jsx(k.article,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1},className:"space-y-6",children:s.body.map((n,o)=>e.jsx("p",{className:"text-gray-300 leading-relaxed text-lg",children:n},o))}),e.jsxs("div",{className:"mt-12 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.04] to-transparent p-8 text-center",children:[e.jsx(A,{className:"w-8 h-8 text-indigo-500 mx-auto mb-3"}),e.jsxs("h3",{className:"text-xl font-bold text-white mb-2",children:["Explore ",te.length," Articles & 2,500+ Tool Guides"]}),e.jsx("p",{className:"text-gray-400 mb-6",children:"Get step-by-step guides for every digital tool."}),e.jsxs("div",{className:"flex items-center justify-center gap-4",children:[e.jsx(S,{to:"/tools",children:e.jsx(H,{icon:$,children:"Browse Tools"})}),e.jsx(S,{to:"/ai-tools",children:e.jsx(H,{variant:"outline",children:"AI Tools"})})]})]}),e.jsxs("div",{className:"mt-12",children:[e.jsx("h2",{className:"text-2xl font-bold text-white mb-6",children:"Related Articles"}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:a.map(n=>e.jsxs(S,{to:`/blog/${n.slug}`,className:"block group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.06] to-transparent hover:border-indigo-500/20 transition-all",children:[e.jsx("span",{className:"text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400",children:n.category}),e.jsx("h3",{className:"text-white font-semibold text-sm mt-2 group-hover:text-indigo-400 transition-colors line-clamp-2",children:n.title}),e.jsx("p",{className:"text-gray-500 text-xs mt-2 line-clamp-2",children:n.excerpt})]},n.slug))})]})]})]})}function ip(){const{compare:t,clearCompare:s,toggleCompare:a,getRating:n}=Vt(),{csvTools:o}=K(),i=t.map(c=>{if(c.source==="ai")return{ref:c,name:c.name,category:c.category,description:"AI tool",path:`/ai-tools/${c.slug}`};const d=o.find(h=>h.slug===c.slug);return{ref:c,name:d?.name||c.name,category:d?.category||c.category,description:d?.description||"CSV tool",path:`/tools/${c.slug}`}}),r=[{label:"Category",get:c=>c.category},{label:"Your Rating",get:c=>{const d=n(c.ref.slug);return d?`${d}/5`:"—"}},{label:"Type",get:c=>c.ref.source==="ai"?"AI Tool":"Mega Tool"},{label:"Description",get:c=>c.description}];return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"Compare Tools | MegatoolsX"}),e.jsx("meta",{name:"description",content:"Compare your favorite tools side by side on MegatoolsX."})]}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center mb-10",children:[e.jsxs("div",{className:"inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm mb-6",children:[e.jsx(St,{className:"w-4 h-4"}),e.jsx("span",{children:"Compare Tools"})]}),e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"Tool Comparison"}),e.jsxs("p",{className:"text-gray-400 text-lg max-w-2xl mx-auto",children:["Compare up to 4 tools side by side. Use the ",e.jsx("strong",{children:"Compare"})," button on any tool page to add it here."]})]}),i.length===0?e.jsxs("div",{className:"text-center py-20",children:[e.jsx(St,{className:"w-16 h-16 text-gray-600 mx-auto mb-4"}),e.jsx("h3",{className:"text-xl text-white font-medium mb-2",children:"No tools selected"}),e.jsx("p",{className:"text-gray-500 mb-8",children:'Browse tools and click "Compare" on any tool page to add it here.'}),e.jsxs("div",{className:"flex items-center justify-center gap-4",children:[e.jsx(S,{to:"/tools",children:e.jsx(H,{children:"Browse Mega Tools"})}),e.jsx(S,{to:"/ai-tools",children:e.jsx(H,{variant:"outline",children:"Browse AI Tools"})})]})]}):e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"flex items-center justify-end mb-4",children:e.jsxs("button",{onClick:s,className:"inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-red-400 transition-colors",children:[e.jsx(Nt,{className:"w-4 h-4"})," Clear All"]})}),e.jsx("div",{className:"overflow-x-auto rounded-2xl border border-white/5",children:e.jsxs("table",{className:"w-full text-sm",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b border-white/5",children:[e.jsx("th",{className:"w-40 p-4 text-left text-gray-500 font-medium",children:"Property"}),i.map(c=>e.jsx("th",{className:"p-4 text-left min-w-[200px]",children:e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs flex-shrink-0",style:{background:`linear-gradient(135deg, ${Qn(c.category)}, #6366f1)`},children:c.name.charAt(0)}),e.jsxs("div",{className:"min-w-0",children:[e.jsx(S,{to:c.path,className:"text-white font-semibold hover:text-indigo-400 transition-colors",children:c.name}),e.jsxs("button",{onClick:()=>a(c.ref),className:"block mt-1 inline-flex items-center gap-1 text-xs text-gray-500 hover:text-red-400 transition-colors",children:[e.jsx(Be,{className:"w-3 h-3"})," Remove"]})]})]})},c.ref.slug))]})}),e.jsxs("tbody",{children:[r.map((c,d)=>e.jsxs("tr",{className:d%2===0?"bg-white/[0.02]":"",children:[e.jsx("td",{className:"p-4 text-gray-500 font-medium border-t border-white/5",children:c.label}),i.map(h=>e.jsx("td",{className:"p-4 text-gray-300 border-t border-white/5",children:c.get(h)},h.ref.slug))]},c.label)),e.jsxs("tr",{children:[e.jsx("td",{className:"p-4 text-gray-500 font-medium border-t border-white/5",children:"Open"}),i.map(c=>e.jsx("td",{className:"p-4 border-t border-white/5",children:e.jsxs(S,{to:c.path,className:"inline-flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition-colors",children:["View Guide ",e.jsx(Z,{className:"w-3 h-3"})]})},c.ref.slug))]})]})]})}),e.jsxs("p",{className:"text-sm text-gray-600 mt-6",children:["Compare up to ",4," tools. Add more from any tool page with the ",e.jsx("strong",{children:"Compare"})," button."]})]})]})]})}const lp=[{key:"bookmarks",label:"Bookmarks",icon:Et},{key:"favorites",label:"Favorites",icon:me},{key:"recent",label:"Recently Viewed",icon:Ae}];function cp(){const[t,s]=l.useState("bookmarks"),{bookmarks:a,favorites:n,recent:o,toggleBookmark:i,toggleFavorite:r}=Vt(),{csvTools:c}=K(),d=t==="bookmarks"?a:t==="favorites"?n:o,h=u=>u==="ai"?"/ai-tools":"/tools";return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"My Tools | MegatoolsX"}),e.jsx("meta",{name:"description",content:"Your bookmarks, favorites, and recently viewed tools on MegatoolsX."}),e.jsx("meta",{name:"robots",content:"noindex,nofollow"})]}),e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20",children:[e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center mb-10",children:[e.jsx("h1",{className:"text-4xl lg:text-5xl font-bold text-white mb-4",children:"My Tools"}),e.jsx("p",{className:"text-gray-400 text-lg",children:"Your saved tools, stored locally in your browser."})]}),e.jsx("div",{className:"flex items-center justify-center gap-2 mb-10",children:lp.map(u=>e.jsxs("button",{onClick:()=>s(u.key),className:`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm transition-all ${t===u.key?"bg-indigo-500/10 border-indigo-500/30 text-indigo-400":"bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10"}`,children:[e.jsx(u.icon,{className:"w-4 h-4"}),u.label,e.jsx("span",{className:"text-xs opacity-70",children:d.length})]},u.key))}),d.length===0?e.jsxs("div",{className:"text-center py-20",children:[e.jsx(Et,{className:"w-16 h-16 text-gray-600 mx-auto mb-4"}),e.jsx("h3",{className:"text-xl text-white font-medium mb-2",children:"Nothing here yet"}),e.jsxs("p",{className:"text-gray-500 mb-8",children:["Save tools with the ",e.jsx("strong",{children:"Save"}),", ",e.jsx("strong",{children:"Like"}),", or ",e.jsx("strong",{children:"Compare"})," buttons on any tool page."]}),e.jsx(S,{to:"/tools",className:"inline-flex px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium hover:from-indigo-700 hover:to-purple-700 transition-all",children:"Browse Tools"})]}):e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",children:d.map((u,f)=>{const v=u.source==="csv"?c.find(j=>j.slug===u.slug):null;return e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:f*.03},className:"group p-5 rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.08] to-transparent hover:border-indigo-500/20 transition-all",children:[e.jsxs("div",{className:"flex items-start justify-between mb-3",children:[e.jsx(S,{to:`${h(u.source)}/${u.slug}`,children:e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0",style:{background:`linear-gradient(135deg, ${Qn(u.category)}, #6366f1)`},children:u.name.charAt(0)})}),e.jsxs("div",{className:"flex items-center gap-1",children:[t==="bookmarks"&&e.jsx("button",{onClick:()=>i(u),title:"Remove bookmark",className:"p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-white/5 transition-all",children:e.jsx(Nt,{className:"w-4 h-4"})}),t==="favorites"&&e.jsx("button",{onClick:()=>r(u),title:"Remove favorite",className:"p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-white/5 transition-all",children:e.jsx(Nt,{className:"w-4 h-4"})})]})]}),e.jsx(S,{to:`${h(u.source)}/${u.slug}`,children:e.jsx("h3",{className:"text-white font-semibold mb-0.5 group-hover:text-indigo-400 transition-colors",children:u.name})}),e.jsx("span",{className:"text-xs text-indigo-400",children:u.category}),v&&e.jsx("p",{className:"text-gray-500 text-xs mt-2 line-clamp-2",children:v.description})]},u.slug)})})]})]})}function dp(){const{csvTools:t}=K();return e.jsxs("div",{children:[e.jsxs(X,{children:[e.jsx("title",{children:"404 - Page Not Found | MegatoolsX"}),e.jsx("meta",{name:"description",content:"The page you're looking for doesn't exist. Browse 2500+ tools at MegatoolsX."}),e.jsx("meta",{name:"robots",content:"noindex,nofollow"})]}),e.jsx("div",{className:"min-h-[80vh] flex items-center justify-center px-4",children:e.jsxs(k.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center max-w-lg",children:[e.jsx("div",{className:"text-9xl font-bold gradient-text mb-4",children:"404"}),e.jsx("h1",{className:"text-3xl font-bold text-white mb-4",children:"Page Not Found"}),e.jsxs("p",{className:"text-gray-400 mb-8 leading-relaxed",children:["The page you're looking for doesn't exist or has been moved. But don't worry — we have ",t.length.toLocaleString(),"+ tools waiting for you!"]}),e.jsxs("div",{className:"flex items-center justify-center gap-4",children:[e.jsx(S,{to:"/",children:e.jsx(H,{icon:Or,children:"Go Home"})}),e.jsx(S,{to:"/tools",children:e.jsx(H,{variant:"outline",icon:Q,children:"Browse Tools"})})]}),e.jsx("div",{className:"mt-12",children:e.jsxs(S,{to:"/ai-tools",className:"inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors text-sm",children:[e.jsx($,{className:"w-4 h-4"}),"Or explore our AI Tools collection"]})})]})})]})}function up(){return e.jsxs(Ho,{children:[e.jsxs(F,{element:e.jsx(Hl,{}),children:[e.jsx(F,{path:"/",element:e.jsx(ql,{})}),e.jsx(F,{path:"/tools",element:e.jsx(pt,{})}),e.jsx(F,{path:"/category/:categorySlug",element:e.jsx(_x,{})}),e.jsxs(F,{path:"/tools/:toolName",element:e.jsx(Wl,{}),children:[e.jsx(F,{index:!0,element:e.jsx(Vx,{})}),["overview","how-to-use","features","problems","solutions","faq","alternatives","download","resources","installation","setup","login","signup","pricing","templates","keyboard-shortcuts","api","automation","integrations","extensions","plugins","error-codes","pros-cons","history","latest-update","news","reviews","community","official-links"].map(t=>e.jsx(F,{path:t,element:e.jsx(Qx,{})},t))]}),e.jsx(F,{path:"/ai-tools",element:e.jsx(ec,{})}),e.jsxs(F,{path:"/ai-tools/:aiToolSlug",element:e.jsx(uc,{}),children:[e.jsx(F,{index:!0,element:e.jsx(mc,{})}),["how-to-use","download","installation","features","pricing","pros-cons","alternatives","faq","security","tips","play"].map(t=>e.jsx(F,{path:t,element:e.jsx(xc,{})},t))]}),e.jsx(F,{path:"/categories",element:e.jsx(gc,{})}),e.jsx(F,{path:"/trending",element:e.jsx(pt,{})}),e.jsx(F,{path:"/new-tools",element:e.jsx(pt,{})}),e.jsx(F,{path:"/popular",element:e.jsx(pt,{})}),e.jsx(F,{path:"/about",element:e.jsx(Zx,{})}),e.jsx(F,{path:"/contact",element:e.jsx(ep,{})}),e.jsx(F,{path:"/privacy",element:e.jsx(sp,{})}),e.jsx(F,{path:"/terms",element:e.jsx(np,{})}),e.jsx(F,{path:"/blog",element:e.jsx(rp,{})}),e.jsx(F,{path:"/blog/:slug",element:e.jsx(op,{})}),e.jsx(F,{path:"/compare",element:e.jsx(ip,{})}),e.jsx(F,{path:"/my-tools",element:e.jsx(cp,{})}),e.jsx(F,{path:"*",element:e.jsx(dp,{})})]}),e.jsx(F,{path:"/admin",element:e.jsx(Yx,{})})]})}const hp=new Ki({defaultOptions:{queries:{staleTime:1e3*60*5,retry:1,refetchOnWindowFocus:!1}}});ir.createRoot(document.getElementById("root")).render(e.jsx(l.StrictMode,{children:e.jsx(Un,{children:e.jsx(Ji,{client:hp,children:e.jsx(ui,{children:e.jsx(Cl,{children:e.jsx(up,{})})})})})}));
